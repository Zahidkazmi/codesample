<?php
session_start();
include_once("config.php");
$conf = new config();
include_once($conf->absolute_path."Controller/ActivityController.php");
$actlogPointer = new ActivityController( );
$browserAgent = $actlogPointer->getBrowser();
$actlogPointer->destroy_ActivityController();


    function base()
    {
      return str_replace("index.php","",$_SERVER['PHP_SELF']);
    }

    $Route = explode("/",$_SERVER['QUERY_STRING']);
   
    if($Route[0] == '' || $Route[0] == 'index'|| $Route[0] == 'login')
    {
      require_once("Views/login.php");
    }
    else if(file_exists("Views/".$Route[0].".php"))
    {
       //define query string check here..
       if(isset($Route[1]) && $Route[1]!='')
       {
         $_GET['id']= $Route[1];
       }
       $accessFile = $Route[0];
       require_once("Views/".$Route[0].".php");
    }
    else{
      require_once("Views/404.php");
    }
?>
