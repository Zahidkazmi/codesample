<?php
session_start();
include_once('../config.php');
$conf = new config();
include_once($conf->absolute_path."Controller/AdminOrganizationController.php");
$OrganizationPointer = new AdminOrganizationController();
if($OrganizationPointer->AddOrganization())
{
    echo '1';
}
echo '';
?>