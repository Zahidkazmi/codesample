<?php
	include_once($conf->absolute_path."Controller/AdminLoginController.php");
	$LoginObj=new AdminLoginController();
	include_once($conf->absolute_path."Controller/encryption.php"); 
	$EncryptionPointer = new rc4crypt();
	if(($LoginObj->is_logged_in())== null){
		$redirect = base()."login";
		echo"<meta http-equiv='refresh' content='0; URL=".$redirect."'>"; 
	  //header("Location: ".$redirect);
	  exit;
	}
?>	