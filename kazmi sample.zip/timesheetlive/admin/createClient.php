<?php
session_start();
include_once('../config.php');
$conf = new config();
include_once($conf->absolute_path."Controller/AdminClientController.php");
$ClientPointer = new AdminClientController();
if($ClientPointer->AddClient())
{
    echo '1';
}
echo '';
?>