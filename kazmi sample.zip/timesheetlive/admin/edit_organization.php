<?php 
session_start();
include_once("../config.php");
$conf = new config();
include_once($conf->absolute_path."Controller/AdminOrganizationController.php");
$OrganizationPointer = new AdminOrganizationController();
$pkgs = NULL;
$pkgs = $OrganizationPointer->getpakage();
$done = $update = 0;
if($OrganizationPointer->updateSelectedOrganization())
{
    $update = 1;
}
if(($data = $OrganizationPointer->getSelectedOrganization())!=null)
{
    $done = 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/fontawesome.css">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/icofont.css">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/themify.css">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/flag-icon.css">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/feather-icon.css">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/style.css">
<link id="color" rel="stylesheet" href="<?php echo $conf->site_url;?>assets/css/color-1.css" media="screen">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/responsive.css">
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/bootstrap.css">
</head>
<?php if($update && $OrganizationPointer->SuccessMsg){?>
    <div class="alert alert-success dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-up"></i>
        <p> <?php echo $OrganizationPointer->SuccessMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<?php if($OrganizationPointer->ErrorMsg !=''){?>
    <div class="alert alert-danger dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-down"></i>
        <p> <?php echo $OrganizationPointer->ErrorMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<div class="modal-body">
    <form method="post" id="Organizations" action="<?php echo $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];?>">
        <div class="row">                             
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Name</label>
                    <input type="text" id="organization_name" class="form-control" placeholder="Enter Name" name="organization_name" value="<?php echo $data[0]['organization_name'];?>" required >
                </div>
            </div>
                
          
            <div class="col-sm-6 mt-2">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Package</label>
                    <select name="package_id" id="package_id" class="form-control">
                        <option>Select package</option>
                        <?php foreach($pkgs as $pkg){?>
                            <option <?php if($data[0]['package_id'] == $pkg['package_id']){echo "selected";}?> value="<?php echo $pkg['package_id']?>"><?php echo $pkg['package_name']?></option>
                        <?php }?>
                    </select>
                </div>
            </div>
            
        
            <div class="col-sm-6 mt-2">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Status</label>
                    <select name="organization_status" id="organization_status" class="form-control">
                        <option>Select Status</option>
                        <option <?php if($data[0]['organization_status'] == 'Active'){echo "selected";}?> value="Active">Active</option>
                        <option <?php if($data[0]['organization_status'] == 'Inactive'){echo "selected";}?> value="Inactive">Inactive</option>
                    </select>
                </div>
            </div> 
            <div class="col-sm-12 mt-3">
                <div class="from-group mt-3 justify-content-right">
                    <button type="button" <?php if($update){?>onClick="window.parent.closeModal('#editModal',1)"<?php }else{?>onClick="window.parent.closeModal('#editModal',0)"<?php }?> class="btn btn-warning">Close</button>
                    <button type="submit" name="update" value="UPDATE" id="submit" class="btn btn-primary">Update</button>
                </div>                        
            </div>
        </div>
    </form>
</div>
<script src="<?php echo $conf->site_url;?>assets/js/jquery-3.5.1.min.js"></script>
<!-- Bootstrap js-->
<script src="<?php echo $conf->site_url;?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
</html>