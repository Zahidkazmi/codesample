<?php 
session_start();
include_once("../config.php");
$conf = new config();
include_once($conf->absolute_path."Controller/AdminProjectController.php");
$TeamPointer = new AdminProjectController();
 if($Route[1]!='' && $Route[2] !='')
 {
    $_GET['team_id']=$Route[1];
    $_GET['project_id']=$Route[2]; 
 }
$done =0;
if($_POST)
{
    $TeamPointer->assignTeamRights();

}
if(($data = $TeamPointer->getTeamRights())!=null)
{
    $done = 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/fontawesome.css">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/icofont.css">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/themify.css">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/flag-icon.css">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/feather-icon.css">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/style.css">
<link id="color" rel="stylesheet" href="<?php echo $conf->site_url;?>assets/css/color-1.css" media="screen">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/responsive.css">
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/bootstrap.css">
</head>

<?php if($TeamPointer->ErrorMsg !=''){?>
    <div class="alert alert-danger dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-down"></i>
        <p> <?php echo $TeamPointer->ErrorMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<div class="modal-body">
<table class="table" id="basic-1" >
    <thead>
        <tr>
            <th>Member Name</th>
            <th class="text-center">Create Task</th>
            <th class="text-center">Edit Task</th>
            <th class="text-center">Delete Task</th>
            <th class="text-center">Approve Task</th>
        </tr>
    </thead>
        <tbody>
        <form method="POST" action="<?php echo base()?>EditTeamRights/<?php echo $Route[1]?>/<?php echo $Route[2]?>">
        <?php foreach($data as $row){
            $User_Rights = $TeamPointer->getUserRights($row['user_id'],$_GET['project_id']);
        ?>
            <tr>
                <td><input type="hidden" name="user_id[]" id="user_id" value="<?php echo $row['user_id']?>"><?php echo $row['first_name']." ".$row['last_name'];?></td>
                <td class="text-center"><input type="checkbox" name="add_record_<?php echo $row['user_id']?>" id="add_record" value="1" <?php if($User_Rights[0]['add_record'] == '1'){ echo "checked";}?>></td>
                <td class="text-center"><input type="checkbox" name="edit_record_<?php echo $row['user_id']?>" id="edit_record" value="1" <?php if($User_Rights[0]['edit_record'] == '1'){ echo "checked";}?>></td>
                <td class="text-center"><input type="checkbox" name="delete_record_<?php echo $row['user_id']?>" id="delete_record" value="1" <?php if($User_Rights[0]['delete_record'] == '1'){ echo "checked";}?>></td>
                <td class="text-center"><input type="checkbox" name="approve_record_<?php echo $row['user_id']?>" id="approve_record" value="1" <?php if($User_Rights[0]['approve_record'] == '1'){ echo "checked";}?>></td>                                  
            </tr>
        <?php }?>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td class="text-center"><button class="btn btn-primary" name="submit" type="submit" value="Assign Rights">Save Rights</button></td>
            </tr>
        </form>
        </tbody>
</table>
<!-- <div class="col-sm-12 mt-3">
                <div class="from-group mt-3 justify-content-right">
                    <button type="button" <?php if($update){?>onClick="window.parent.closeModal('#ViewModal',1)"<?php }else{?>onClick="window.parent.closeModal('#ViewModal',0)"<?php }?> class="btn btn-warning">Close</button>
                </div>                        
            </div> -->
</div>
<script src="<?php echo $conf->site_url;?>assets/js/jquery-3.5.1.min.js"></script>
<!-- Bootstrap js-->
<script src="<?php echo $conf->site_url;?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
</html>