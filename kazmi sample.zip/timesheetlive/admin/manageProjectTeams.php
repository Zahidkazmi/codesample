<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/AdminProjectController.php");
    $ProjectPointer = new AdminProjectController();
    if(isset($Route[1]))
    {
        $_GET['page']=$Route[1] ;
        $current_page=$Route[1];
    }
    else{
        $current_page = 1;
        $_GET['page']=1;
    }
    if(isset($_POST)){
       // $ProjectPointer->AssignProjectToTeam();
       // unset($_POST['project_id'],$_POST['team_id'],$_POST['submit']);
    }
    $data = $ProjectPointer->getProjectTeams();
    $params='';
    $thispage= base()."manageProjectTeams";
    $total_pages = $ProjectPointer->total_pages;    
    
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Manage Project Teams</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>dashboard"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Projects</li>
                    <li class="breadcrumb-item active">Manage Project Teams</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                    
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>Organization</th>
                                    <th>P.Code</th>
                                    <th>Project</th>
                                    <th>Team</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($data as $row){?>
                                    <tr>
                                        <td><?php echo $row['organization_name'];?></td>
                                        <td><?php echo $row['project_code'];?></td>
                                        <td><?php echo $row['project_name'];?></td>
                                        <td><?php echo $row['team_name'];?></td>
                                        <td>
                                            <a href="javascript:void(0);" onClick="openModal('<?php echo base()?>EditTeamRights/<?php echo $row['team_id']?>/<?php echo $row['project_id']?>','#editModal','ifEdit')" title="Edit User Rights"> <i class="fa fa-wrench"></i></a>   
                                        </td>
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            </div>
                            <div class="text-center mt-5 mb-5">
                                    <nav>
                                        <ul class="pagination justify-content-center pagination-primary">
                                            <?php echo($ProjectPointer->getPageMenu($total_pages, $current_page, $thispage, $params));?>
                                        </ul>
                                    </nav>
                                
                            </div>
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
<script> 

function openModal(frameSrc,modalID,SrcID)
{ 
    document.getElementById(SrcID).src = frameSrc;
    $(modalID).modal('show');
}

function closeModal(modalID,pgref)
{
    $('#editModal').modal('hide');
    if(pgref == 1){
    if(window.top==window) {
        // you're not in a frame so you reload the site
        window.setTimeout('location.reload()', 1000); //reloads after 3 seconds
    }
    }
} 
$(document).ready(function() {
    $('#basic-1').DataTable({
        "order": [[ 1, "desc" ]],
        "paging": false
    });



<?php if($ProjectPointer->SuccessMsg){?>
    swal({
            title: "Success!",
            text: "<?php echo $ProjectPointer->SuccessMsg?>",
            type: "success"
    }, function() {
        window.location = "<?php echo base()?>manageProjectTeams";
    }); 
<?php }?>
<?php if($ProjectPointer->ErrorMsg){?>
    swal({
            title: "Error!",
            text: "<?php echo $ProjectPointer->ErrorMsg?>",
            type: "error"
    }); 
<?php }?>

});

</script>  


<!--model start-->
<div class="modal fade bd-example-modal-lg" id="editModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">Edit Team Rights</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <iframe id="ifEdit" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--model end-->
</body>
</html>