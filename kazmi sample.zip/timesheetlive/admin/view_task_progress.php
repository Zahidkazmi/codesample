<?php 
include_once($conf->absolute_path."Controller/AdminProjectController.php");
$TaskPointer = new AdminProjectController();
 if($Route[1]!='' && $Route[2]!='')
 {
     $_GET['project_id']=$Route[1];
     $_GET['task_id']=$Route[2]; 
 }

$done =0;
if(($data = $TaskPointer->getSelectedTaskDetail())!=null)
{
    $done = 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/fontawesome.css">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/icofont.css">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/themify.css">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/flag-icon.css">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/feather-icon.css">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/style.css">
<link id="color" rel="stylesheet" href="<?php echo $conf->site_url;?>assets/css/color-1.css" media="screen">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/responsive.css">
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/bootstrap.css">

<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/datatables.css">
</head>

<?php if($TaskPointer->ErrorMsg !=''){?>
    <div class="alert alert-danger dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-down"></i>
        <p> <?php echo $TaskPointer->ErrorMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<div class="modal-body">
<table class="table" id="basic-1" >
    <thead>
        <tr>
            <th>Start</th>
            <th>End</th>
            <th>Time</th>
            <th>Status</th>
            <th>Description</th>
        </tr>
    </thead>
        <tbody>
        <?php foreach($data as $row){?>
            <tr>
                <td><?php echo date('d-M-Y',strtotime($row['start_date']));?></td>
                <td><?php echo date('d-M-Y',strtotime($row['end_date']));?></td>
                <td><?php echo $row['hour_spend'];?> Hrs</td>
                <td><?php echo $row['task_status'];?></td>
                <td><?php echo $row['description'];?></td>                                  
            </tr>
        <?php }?>
        </tbody>
</table>

</div>
<script src="<?php echo $conf->site_url;?>assets/js/jquery-3.5.1.min.js"></script>
<!-- Bootstrap js-->
<script src="<?php echo $conf->site_url;?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
<script src="<?php echo $conf->site_url;?>assets/js/datatable/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $conf->site_url;?>assets/js/datatable/datatables/datatable.custom.js"></script>
</html>