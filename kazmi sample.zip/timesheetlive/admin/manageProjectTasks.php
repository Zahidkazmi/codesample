<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/AdminProjectController.php");
    $ProjectPointer = new AdminProjectController();
    if(isset($Route[1]) && $Route[1] !='')
    {
        $_GET['project_id'] = $Route[1]; 
    }
    //insert funtion
    if(isset($_POST)){
            $ProjectPointer->CreateProjectTask();
            unset($_POST['module_id'],$_POST['phase_id'],$_POST['resource_id'],$_POST['estimated_hours'],$_POST['task_description']);
    }
    $data = $ProjectPointer->getProjectTaskList();
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Manage <?php echo $ProjectPointer->getSelectedProjectName();?> Tasks</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>dashboard">Home</a></li>
                    <li class="breadcrumb-item">Projects</li>
                    <li class="breadcrumb-item"><a href="<?php echo base()?>manageProject">Manage Projects</li></a>
                    <li class="breadcrumb-item active">Manage Project Tasks</li>
                </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6">
                        <div class="text-end">
                            <div class="form-group mb-0 me-0">

                            </div>
                            <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-original-title="" title="" href="projectcreate.html" data-bs-original-title="" title=""> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line></svg>Create New Task</a>

                    
                        </div>
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>Task</th>
                                    <th>Estimated Hours</th>
                                    <th>Hours Spent</th>
                                    <th>Module</th>
                                    <th>Phase</th>
                                    <th>Resource</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($data as $row){ 
                                    if($row['task_status']=="Completed"){ $class= "bg-success";}
                                    else if($row['task_status']=="Pending"){ $class= "bg-primary";}
                                    else if($row['task_status']=="Inprogress"){ $class= "bg-warning";}
                                    else if($row['task_status']=="On Hold"){ $class= "bg-danger";}
                                    else{
                                        $class="font-info";
                                    }   
                                ?>
                                    <tr>
                                        <td><?php echo $row['task_description'];?></td>
                                        <td><?php echo $row['estimated_hours'];?></td>
                                        <td><?php echo $ProjectPointer->getTotalSpendHours($row['task_id']);?></td>
                                        <td><?php echo $row['module_name'];?></td>
                                        <td><?php echo $row['phase_type'];?></td>
                                        <td><?php echo $row['first_name']." ".$row['last_name'];?></td>
                                        <td class="<?php echo $class;?>"><?php echo $row['task_status'];?></td>
                                        <td><a href="javascript:void(0);" onClick="openModal('<?php echo base()?>edit_project_task/<?php echo $row['task_id']?>/<?php echo $Route[1]?>','#editModal','ifEdit')" title="Edit"><i class="fa fa-wrench"></i></a> | <a href="javascript:void(0);" onClick="openModal('<?php echo base()?>view_task_progress/<?php echo $row['project_id']?>/<?php echo $row['task_id']?>','#viewModal','ifView')" title="View Task Activities"><i class="fa fa-eye"></i></a> <?php if($row['task_status'] == 'Lead Approval'){?>| <a href="javascript:void(0);" class="approve" id="<?php echo $row['task_id']?>" title="Approve Completion"><i class="fa fa-check"></i></a><?php }?></td>
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            </div>
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
<script> 

function openModal(frameSrc,modalID,SrcID)
{ 
    document.getElementById(SrcID).src = frameSrc;
    $(modalID).modal('show');
}

function closeModal(modalID,pgref)
{
    $('#editModal').modal('hide');
    if(pgref == 1){
    if(window.top==window) {
        // you're not in a frame so you reload the site
        window.setTimeout('location.reload()', 1000); //reloads after 3 seconds
    }
    }
} 

$(document).ready(function() {
<?php if($ProjectPointer->SuccessMsg){?>
    swal({
            title: "Success!",
            text: "<?php echo $ProjectPointer->SuccessMsg?>",
            type: "success"
    }, function() {
        window.location = "<?php echo base()?>manageProjectTasks/<?php echo $Route[1]?>";
    }); 
<?php }?>
<?php if($ProjectPointer->ErrorMsg){?>
    swal({
            title: "Error!",
            text: "<?php echo $ProjectPointer->ErrorMsg?>",
            type: "error"
    }); 
<?php }?>

});

$('a.approve').click(function() {
    var id = $(this).attr('id');
    var formData = {
        'task_id': id,
        'task_status': "Completed"
    }
    bootbox.confirm({
        message: "<p class='text-semibold text-main'>Approve Task Status</p><p>Are you sure you want to approve?</p>",
        buttons: {
            confirm: {
                label: "Yes"
            }
        },
        callback: function(result) {
            //Callback function here
            if (result) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base()?>update_task_status",
                    data: formData,
                    cache: false,
                    success: function(response) {
                        
                        //var cartsummary = JSON.parse(JSON.stringify(response));
                          
                            swal({
                                title: "Success!",
                                text: "Task approved successfully",
                                type: "success"
                                }, function() {
                                window.location = "<?php echo base()?>projectlist/<?php echo $Route[1];?>";
                            });
                            
                        
                        setTimeout(function() {
                            bootbox.hideAll();
                        }, 2000);
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        setTimeout(function() {
                            bootbox.hideAll();
                        }, 2000);
                        swal({
                                title: "Error!",
                                text: textStatus + '! ' + errorThrown,
                                type: "error"
                                });
                    }
                });
            }

        }
    });
});
</script>    
<!--model start-->
<div class="modal fade bd-example-modal-lg" id="add-modal-data" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Create New Task</h4>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" id="projecttask" action="<?php echo base()?>manageProjectTasks/<?php echo $Route[1]?>">
                    <div class="row">                             
                        <div class="col-sm-6">
                             <div class="form-group">
                                    <label class="w-100 d-flex justify-content-start" >Modules</label>
                                    <select name="module_id" id="module_id" class="form-control" required>
                                        <option>Select Module</option>
                                        <?php 
                                        $Modules = $ProjectPointer->getModule(); 
                                        foreach($Modules as $module){?>
                                            <option value="<?php echo $module['module_id']?>"><?php echo $module['module_name']?></option>
                                        <?php }?>
                                    </select>
                                </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                                    <label class="w-100 d-flex justify-content-start" >Phase</label>
                                    <select name="phase_id" id="phase_id" class="form-control" required>
                                        <option>Select Phase</option>
                                        <?php
                                        $Phases = $ProjectPointer->getPhase(); 
                                            foreach($Phases as $phase){?>
                                            <option value="<?php echo $phase['phase_id']?>"><?php echo $phase['phase_type']?></option>
                                        <?php }?>
                                    </select>
                                </div>
                        </div>

                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Resource</label>
                                <select name="resource_id" id="resource_id" class="form-control" required>
                                    <option>Select Resource</option>
                                    <?php 
                                    $Users = $ProjectPointer->getProjectResource(); 
                                    foreach($Users as $user){?>
                                        <option value="<?php echo $user['user_id']?>"><?php echo $user['first_name']." ".$user['last_name']?></option>
                                    <?php }?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Estimated Hours</label>
                                <input type="number" min="1" name="estimated_hours" class="form-control" id="estimated_hours" required>
                            </div>
                        </div>
                        <div class="col-sm-12 mt-3">
                            <div class="from-group">
                                <label class="w-100 d-flex justify-content-start" >Task Description</label>
                                <textarea name="task_description" id="task_description" class="form-control" placeholder="Task Description"></textarea>
                            </div>
                            <div class="from-group mt-3 justify-content-right">
                                <button type="button" data-bs-dismiss="modal" class="btn btn-warning">Close</button>
                                <button type="submit" name="createTask" id="createTask" value="CreateTask" class="btn btn-primary">Create Task</button>
                            </div>                        
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-lg" id="editModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">Edit Task</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <iframe id="ifEdit" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--model end-->
<!--view team model start-->
<div class="modal fade-up bd-example-modal-lg" id="viewModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">View Task Progress</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <iframe id="ifView" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--view team modal-->
</body>
</html>