<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/AdminTeamController.php");
    $TeamPointer = new AdminTeamController();
    $done = 0;
    if(isset($_POST['CreateTeam']) && $_POST['CreateTeam'] == 'Create')
    {
        if($TeamPointer->AddTeam()){
            $done = 1;
        }
    }
    $data = $TeamPointer->getTeamLists();
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Team List </h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="manageorganization"><i data-feather="monitor"></i></a></li>
                    <li class="breadcrumb-item">Team</li>
                    <li class="breadcrumb-item active">Team List</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6">
                        <div class="text-end">
                            <div class="form-group mb-0 me-0">

                            </div>
                            <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-original-title="" title="" href="javascript:void(0)" data-bs-original-title="" title=""> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line></svg>Create New Team</a>

                    
                        </div>
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>Team Name</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($data as $row){?>
                                    <tr>
                                        <td><?php echo $row['team_name'];?></td>
                                        <td><?php if($row['team_status'] ==1) { echo "Active";}else{ echo "Inactive";}?></td>
                                        <td><?php echo $row['created_at'];?></td>
                                        <td>
                                            <a href="javascript:void(0);" onClick="openModal('edit_team.php?team_id=<?php echo $row['team_id']?>','#editModal','ifEdit')" title="Edit"> <i class="fa fa-wrench"></i></a> |  
                                            <a href="javascript:void(0);" onClick="openModal('view_team.php?team_id=<?php echo $row['team_id']?>','#viewModal','ifView')" title="View"> <i class="fa fa-eye"></i> </a>
                                       </td>
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            </div>
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
    <!-- Select2 -->
<script src="<?php echo $conf->site_url;?>assets/js/select2/select2.full.min.js"></script>
<script src="<?php echo $conf->site_url;?>assets/js/select2/select2-custom.js"></script>
<script> 

function openModal(frameSrc,modalID,SrcID)
{ 
    document.getElementById(SrcID).src = frameSrc;
    $(modalID).modal('show');
}

function closeModal(modalID,pgref)
{
    $('#editModal').modal('hide');
    if(pgref == 1){
    if(window.top==window) {
        // you're not in a frame so you reload the site
        window.setTimeout('location.reload()', 1000); //reloads after 3 seconds
    }
    }
} 

$(document).ready(function(){
    /*$('#teams').on("submit", function(event)
    { 
        var formData = {        
            'team_name': $('#team_name').val(),
            'lead_id': $('#lead_id').val(),
            'member_id': $("#member_id").val()
        }
        alert("team_name="+formData.team_name+' lead_id='+formData.lead_id+' member_ids='+formData.member_id); 
        event.preventDefault();  
        $.ajax({  
            url:"<?php //echo base()?>createteam",  
            method:"POST",  
            data: formData,             
            success:function(response)
            {
                $('#teams')[0].reset();  
                $('#add-modal-data').modal('hide');
                swal({
                        title: "Success!",
                        text: "New Team has been added successfully.",
                        type: "success"
                }, function() {
                    window.location = "<?php //echo base()?>manageteam";
                }); 
            } 
        });  
    });*/
<?php if($TeamPointer->SuccessMsg && $done){?>
    swal({
            title: "Success!",
            text: "<?php echo $TeamPointer->SuccessMsg?>",
            type: "success"
    }, function() {
        window.location = "<?php echo base()?>manageteam";
    }); 
<?php }?>
<?php if($TeamPointer->ErrorMsg){?>
    swal({
            title: "Error!",
            text: "<?php echo $TeamPointer->ErrorMsg?>",
            type: "error"
    }); 
<?php }?>


});
</script>  


<!--model start-->
<div class="modal fade bd-example-modal-lg" id="add-modal-data"  role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" data-backdrop="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Add New Team</h4>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" id="teams" action="<?php echo base()?>manageteam">
                    <div class="row">                             
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Team Name</label>
                                <input type="text" id="team_name" class="form-control" placeholder="Enter team Name" name="team_name" required >
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Organization</label>
                                <select name="organization_id" id="organization_id" class="form-control" required onchange="GetAjaxLead(this.value)">
                                    <option value="">Select Organization *</option>
                                    <?php $Organization = NULL;
                                    $Organization = $TeamPointer->getOrganization();
                                    if($Organization){ foreach($Organization as $arr){?>
                                        <option value="<?php echo $arr['organization_id']?>"><?php echo $arr['organization_name']?></option>
                                    <?php }}?>
                                </select>
                            </div>
                        </div>
                        <?php 
                            $users = NULL;
                            $users = $TeamPointer->getuser();

                        ?>
                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Team Lead</label>
                                <select name="lead_id" id="lead_id" class="form-control" onchange="GetAjaxMembers(this.value)">
                                    
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Team Member</label>
                                <select name="member_id[]" id="member_id" class="form-control" multiple="multiple">
                                    
                                </select>
                            </div>
                        </div>
                        
                       
                        <div class="d-flex flex-row-reverse">
                            <div class="from-group mt-3">
                                <button type="button" data-bs-dismiss="modal" class="btn btn-warning">Close</button>
                                <button type="submit" name="CreateTeam" id="CreateTeam" value="Create" class="btn btn-primary">Create</button>
                            </div> 
                        </div> 
                    </div> 
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-lg" id="editModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">Edit Team</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <iframe id="ifEdit" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--model end-->

<!--view team model start-->
<div class="modal fade-up bd-example-modal-lg1" id="viewModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">View Team</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <iframe id="ifView" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--view team modal-->
<script> 
 $(document).ready(function() {
    $("#member_id").select2({
            //minimumInputLength: 1,
            dropdownParent: $("#add-modal-data"),
        });
 });
 function GetAjaxLead(id)
    {
     $(document).ready(function() {
            var formData = {
                'organization_id': id
            };
            $.ajax({
                type: "POST",
                url: "get_ajax_users.php",
                data: formData
            }).done(function(users) {
                $("#lead_id").html('');
                $("#lead_id").html(users);
            });
        });
    }

    function GetAjaxMembers(id)
    {
     $(document).ready(function() {
            var formData = {
                'organization_id': $('#organization_id :selected').val(),
                'user_id': id
            };
            $.ajax({
                type: "POST",
                url: "get_ajax_members.php",
                data: formData
            }).done(function(users) {
                $("#member_id").html('');
                $("#member_id").html(users);
            });
        });
    }
 </script>
</body>
</html>