<?php 
session_start();
include_once("../config.php");
$conf = new config();
include_once($conf->absolute_path."Controller/AdminClientController.php");
$ClientPointer = new AdminClientController();
$done = $update = 0;
if($ClientPointer->updateSelectedClient())
{
    $update = 1;
}
if(($data = $ClientPointer->getSelectedClient())!=null)
{
    $done = 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/fontawesome.css">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/icofont.css">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/themify.css">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/flag-icon.css">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/feather-icon.css">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/style.css">
<link id="color" rel="stylesheet" href="<?php echo $conf->site_url;?>assets/css/color-1.css" media="screen">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/responsive.css">
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/bootstrap.css">
</head>
<?php if($update && $ClientPointer->SuccessMsg){?>
    <div class="alert alert-success dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-up"></i>
        <p> <?php echo $ClientPointer->SuccessMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<?php if($ClientPointer->ErrorMsg !=''){?>
    <div class="alert alert-danger dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-down"></i>
        <p> <?php echo $ClientPointer->ErrorMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<div class="modal-body">
    <form method="post" id="clients" action="<?php echo $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];?>">
        <div class="row">                             
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Organization</label>
                    <select name="organization_id" id="organization_id" class="form-control" required>
                                    <option value="">Select Organization *</option>
                                    <?php $Organization = NULL;
                                    $Organization = $ClientPointer->getOrganization();
                                    if($Organization){ foreach($Organization as $arr){?>
                                        <option <?php if($data[0]['organization_id'] == $arr['organization_id']){echo "selected";}?> value="<?php echo $arr['organization_id']?>"><?php echo $arr['organization_name']?></option>
                                    <?php }}?>
                                </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Name</label>
                    <input type="text" id="client_name" class="form-control" placeholder="Enter Name" name="client_name" value="<?php echo $data[0]['client_name'];?>" required >
                </div>
            </div>
            <div class="col-sm-6 mt-2">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Email</label>
                    <input type="Email" id="client_email" class="form-control" placeholder="Enter Name" name="client_email" value="<?php echo $data[0]['client_email'];?>" required>
                </div>
            </div>
            <div class="col-sm-6 mt-2">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Contact Person</label>
                    <input type="tel" id="contact_person" class="form-control" placeholder="Enter Contact No" name="contact_person" value="<?php echo $data[0]['contact_person'];?>" required >
                </div>
            </div>
            <div class="col-sm-6 mt-2">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Status</label>
                    <select name="client_status" id="status" class="form-control">
                        <option>Select Status</option>
                        <option <?php if($data[0]['client_status'] == 'Active'){echo "selected";}?> value="Active">Active</option>
                        <option <?php if($data[0]['client_status'] == 'Inactive'){echo "selected";}?> value="Inactive">Inactive</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-12 mt-3">
                <div class="from-group">
                    <label class="w-100 d-flex justify-content-start" >Address</label>
                    <textarea name="client_address" id="address" class="form-control" placeholder="Client Address"><?php echo $data[0]['client_address'];?></textarea>
                </div>
                <div class="from-group mt-3 justify-content-right">
                    <button type="button" <?php if($update){?>onClick="window.parent.closeModal('#editModal',1)"<?php }else{?>onClick="window.parent.closeModal('#editModal',0)"<?php }?> class="btn btn-warning">Close</button>
                    <button type="submit" name="update" value="UPDATE" id="submit" class="btn btn-primary">Update</button>
                </div>                        
            </div>
        </div>
    </form>
</div>
<script src="<?php echo $conf->site_url;?>assets/js/jquery-3.5.1.min.js"></script>
<!-- Bootstrap js-->
<script src="<?php echo $conf->site_url;?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
</html>