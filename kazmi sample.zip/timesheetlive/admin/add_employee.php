<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/AdminEmployeeController.php");
    $employeePointer = new AdminEmployeeController();
    if(isset($Route[1]))
    {
      $_GET['id'] = $Route[1];
    }
    $country = $employeePointer->getCountries();
    $city = $employeePointer->getCities();
    $company = $employeePointer->getCompanies();
    $designation = $employeePointer->getDesignations();
    
     if (isset($_POST['submit'])) 
     {
       
        $employeePointer->addEmployee(); 
     }
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Create User</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="manageclient"><i data-feather="user"></i></a></li>
                    <li class="breadcrumb-item">Users</li>
                    <li class="breadcrumb-item active">Create New User</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-sm-4 offset-4">
            <div class="form-group">
            
            </div>
            </div>
            </div>
          <div class="edit-profile">
              <div class="row">
                <div class="col-xl-4">
                  <div class="card">
                    <div class="card-header">
                      <h4 class="card-title mb-0">My Profile</h4>
                      <div class="card-options"><a class="card-options-collapse" href="#" data-bs-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a><a class="card-options-remove" href="#" data-bs-toggle="card-remove"><i class="fe fe-x"></i></a></div>
                    </div>
                    <div class="card-body">
                      <form method="POST" action="<?php echo base()?>add_employee" enctype="multipart/form-data">

                        <div class="row mb-5">
                          <div class="col-auto"><img class="img-100 rounded-circle" id="previewImg" alt=""></div>
                          
                        </div>

                  <div class="mb-2">
                  <input type="file" name="image" class="form-control" onchange="loadFile(event)" value="">
                  </div>

                    </div>

                  </div>

                </div>

                <div class="col-xl-8">
                  

                    <div class="card-header">
                      <h4 class="card-title mb-0">Create Profile</h4>
                      <div class="card-options"><a class="card-options-collapse" href="#" data-bs-toggle="card-collapse"><i class="fe fe-chevron-up"></i></a><a class="card-options-remove" href="#" data-bs-toggle="card-remove"><i class="fe fe-x"></i></a></div>
                    </div>

                    <div class="card-body">
                      <div class="row">
                      <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Company</label>
                            <select class="form-control btn-square" name="company">
                              <?php foreach($company as $companies){?>
                              <option  value="<?php echo $companies['organization_id']?>"> <?php echo $companies['organization_name']; ?> </option>
                              <?php }?>
                            </select>
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input class="form-control" name="username" type="text"  placeholder="Username">
                          </div>
                        </div>

                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Email address</label>
                            <input class="form-control" name="email"  type="email" placeholder="Email">
                          </div>
                        </div>

                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input class="form-control" name="password"  type="password" placeholder="****">
                          </div>
                        </div>

                        <div class="col-sm-6 col-md-6">
                            <label class="form-label">Status</label>
                            <select name="status" id="status" class="form-control" required>
                            <option  value="Active">Active</option>
                            <option  value="Block">Block</option>
                          </select>
                        </div>

                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input class="form-control" name="first_name" type="text"  placeholder="first name" required>
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input class="form-control" name="last_name" type="text"  placeholder="Last Name" required>
                          </div>
                        </div>

                        <div class="col-sm-6 col-md-6">
                          <label class="form-label">Mobile</label>
                          <input class="form-control" name="mobile"  placeholder="Mobile Number">
                        </div>
                        
                        <div class="col-sm-6 col-md-6">
                            <label class="form-label">Gender</label>
                            <select name="gender" id="status" class="form-control" required>
                            <option  value="Male">Male</option>
                            <option  value="Female">Female</option>
                          </select>
                        </div>

                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Designation</label>
                            <select class="form-control btn-square" name="designation_id" id="designation_id" required>
                              <option> Select Designation </option>
                              <?php foreach($designation as $desig){?>
                              <option  value="<?php echo $desig['designation_id']?>"> <?php echo $desig['designation']; ?> </option>
                              <?php }?>
                            </select>
                          </div>
                        </div>
                        
                        <div class="col-md-4">
                          <div class="mb-3">
                            <label class="form-label">Salary</label>
                            <input class="form-control" name="salary" type="text"  placeholder="Salary">
                          </div>
                        </div>

                        <div class="col-md-4">
                          <div class="mb-3">
                            <label class="form-label">Rate Per Hour</label>
                            <input class="form-control" name="rate_per_hour" type="text"  placeholder="Rate Per Hour">
                          </div>
                        </div>

                        <div class="col-md-4">
                          <div class="mb-3">
                            <label class="form-label">Over Heads</label>
                            <input class="form-control" name="over_heads" type="text"  placeholder="Over Heads">
                          </div>
                        </div>

                        <div class="col-md-12">
                          <div class="mb-3">
                            <label class="form-label">Address</label>
                            <input class="form-control" name="address_line1" type="text"  placeholder="Home Address">
                          </div>
                        </div>

                        <div class="col-md-12">
                          <div class="mb-3">
                            <label class="form-label">Permanent Address</label>
                            <input class="form-control" name="address_line2" type="text"  placeholder="Permanent Address">
                          </div>
                        </div>
                        
                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Country</label>
                            <select class="form-control btn-square" name="country">
                              <?php foreach($country as $arr){?>
                              <option  value="<?php echo $arr['country_id']?>"> <?php echo $arr['country_name']; ?> </option>
                              <?php }?>
                            </select>
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">City</label>
                            <select class="form-control btn-square" name="city">
                              <?php foreach($city as $cities){?>
                              <option  value="<?php echo $cities['city_ID']?>"> <?php echo $cities['city_name']; ?> </option>
                              <?php }?>
                            </select>
                          </div>
                        </div>




                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Postal Code</label>
                            <input class="form-control" name="zipcode"  type="number" placeholder="ZIP Code">
                          </div>
                        </div>


                        <div class="col-sm-6 col-md-6">

                            <label class="form-label">Employment Status</label>
                            <select name="estatus" id="estatus" class="form-control">
                            
                            <option  value="Probation">Probation</option>
                            <option  value="internship">internship</option>
                            <option  value="Permanent">Permanent</option>
                          </select>

                        </div>
                        
                        <div class="col-md-12">
                          <div>
                            <label class="form-label">About Me</label>
                            <textarea class="form-control" rows="5" name="description" placeholder="Enter About your description"></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="card-footer">
                      <button class="btn btn-primary" name="submit" value="submit" type="submit">Save</button>
                     
                      <!-- <?php //if($employeePointer->SuccessMsg){?>
                <div class="alert alert-success dark alert-dismissible fade show text-start mt-3" role="alert"><i data-feather="thumbs-up"></i>
                      <p> <?php //echo $employeePointer->SuccessMsg;?></p>
                    <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                    <?php //}?> -->
                    </div>
                  </form>
                </div>
                
              </div>
            </div>

          <!-- Container-fluid Ends-->
        </div>
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->

      </div>
    </div>
    <?php include_once("js.php");?>

    <script>
    
    $(document).ready(function(){
      <?php if($employeePointer->SuccessMsg){?>
      swal({
              title: "Success!",
              text: "<?php echo $employeePointer->SuccessMsg;?>",
              type: "success"
            }, function() {
                window.location = "<?php echo base()?>manageemployees";
      });
    
      <?php }?>

      <?php if($employeePointer->ErrorMsg){?>
      swal({
              title: "Error!",
              text: "<?php echo $employeePointer->ErrorMsg;?>",
              type: "error"
          });
      
      <?php }?>  
    });

  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('previewImg');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };

</script> 

</body>
</html>