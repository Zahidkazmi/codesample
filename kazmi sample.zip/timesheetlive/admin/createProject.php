<?php
session_start();
include_once('../config.php');
$conf = new config();
include_once($conf->absolute_path."Controller/AdminProjectController.php");
$ProjectPointer = new AdminProjectController();
if($ProjectPointer->AddNewProject())
{
    echo '1';
}
echo '';
?>