<?php
session_start();
$session_id = session_id();
include_once("../config.php");
$conf = new config();
include_once($conf->absolute_path . "Controller/AdminTeamController.php");
$teamPointer = new AdminTeamController();
$where = $data = null; 


if((isset($_POST['organization_id']) && $_POST['organization_id'] !=''))
{
    $where = "organization_id ='".$_POST['organization_id']."' AND user_id != '".$_POST['user_id']."' AND status ='Active'";
}
$query="SELECT user_id,first_name,last_name FROM tblusers
WHERE
    ".$where."
ORDER BY
    first_name";
if(($rs_users = $teamPointer->CustomQuery($query))!=null)
{ ?>
    <option value="">Select Members *</option>
<?php
    foreach ($rs_users as $arr){
        ?>
        <option value="<?php echo $arr['user_id'];?>"><?php echo $arr['first_name']." ".$arr['last_name'];?></option>
        <?php
        
    }
}
?>