<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/AdminPackageController.php");
    $PackagePointer = new AdminPackageController();
    $data = $PackagePointer->getPackageLists();
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Packages List</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="managePackage"><i data-feather="package"></i></a></li>
                    <li class="breadcrumb-item">Packages</li>
                    <li class="breadcrumb-item active">Packages List</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6">
                        <div class="text-end">
                            <div class="form-group mb-0 me-0">

                            </div>
                            <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-original-title="" title="" href="javascript:void(0)" data-bs-original-title="" title=""> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line></svg>Create New Package</a>

                    
                        </div>
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>PKG Type</th>
                                    <th>PKG Price</th>
                                    <th>Total users</th> 
                                    <th>Status</th>
                                    
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($data as $row){?>
                                    <tr>
                                        <td><?php echo $row['package_name'];?></td>
                                        <td><?php echo $row['pkg_type'];?></td>
                                        <td><?php echo $row['pkg_price'];?></td>
                                        <td><?php echo $row['num_of_users'];?></td>
                                        <td><?php echo $row['package_status'];?></td>
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            </div>
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
<script> 

function openModal(frameSrc,modalID,SrcID)
{ 
    document.getElementById(SrcID).src = frameSrc;
    $(modalID).modal('show');
}

function closeModal(modalID,pgref)
{
    $('#editModal').modal('hide');
    if(pgref == 1){
    if(window.top==window) {
        // you're not in a frame so you reload the site
        window.setTimeout('location.reload()', 1000); //reloads after 3 seconds
    }
    }
} 

$(document).ready(function(){
    $('#packages').on("submit", function(event)
    { 
        var formData = {        
            'package_name': $('#package_name').val(),
            'pkg_type': $('#pkg_type').val(),
            'pkg_price': $('#pkg_price').val(),
            'num_of_users': $('#num_of_users').val(),
            'package_status': $('#package_status').val()        } 
        event.preventDefault();  
        $.ajax({  
            url:"createPackage.php",  
            method:"POST",  
            data: formData,  
            
            success:function(response)
            {
                $('#packages')[0].reset();  
                $('#add-modal-data').modal('hide');
                swal({
                        title: "Success!",
                        text: "package has been added successfully.",
                        type: "success"
                }, function() {
                    window.location = "<?php echo base()?>managepackage";
                }); 
               
            } 
        });  
    });
});
</script>  


<!--model start-->
<div class="modal fade bd-example-modal-lg" id="add-modal-data" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Add New package</h4>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" id="packages">
                    <div class="row">                             
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" > &nbsp;&nbsp;Name</label>
                                <input type="text" id="package_name" class="form-control" placeholder="Enter package Name" name="package_name" required >
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" > &nbsp;&nbsp;PKG Type</label>
                                <input name="pkg_type" id="pkg_type" class="form-control" placeholder="Enter pkg type" required>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >&nbsp;&nbsp;PKG Price</label>
                                <input type="number" id="pkg_price" min="0" class="form-control" placeholder="Enter price" name="pkg_price" required >
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >&nbsp;&nbsp;Total users</label>
                                <input type="number" id="num_of_users" min="1" class="form-control" placeholder="Enter No of users" name="num_of_users" required >
                            </div>
                        </div>
                   
                         <!-- 03_month_price
                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Status</label>
                                <select name="package_status" id="package_status" class="form-control">
                                    <option>Select Status</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                            </div>
                        </div> -->
                        <div class="col-sm-12 mt-3">
                            <div class="from-group mt-3 justify-content-right">
                                <button type="button" data-bs-dismiss="modal" class="btn btn-warning">Close</button>
                                <button type="submit" name="submit" id="submit" class="btn btn-primary">Create</button>
                            </div>                        
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-lg" id="editModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">Edit package</h5>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <iframe id="ifEdit" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--model end-->
</body>
</html>