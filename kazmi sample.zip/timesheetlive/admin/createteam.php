<?php
session_start();
include_once('../config.php');
$conf = new config();
include_once($conf->absolute_path."Controller/AdminTeamController.php");
$TeamPointer = new AdminTeamController();
if($TeamPointer->AddTeam())
{
    echo '1';
}
echo '';
?>