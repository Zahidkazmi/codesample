<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/AdminProjectController.php");
    $ProjectPointer = new AdminProjectController();
    $done = 0;
    if($ProjectPointer->AddNewProject())
    {
      $done = 1;
      unset($_POST['project_code'],$_POST['project_name'],$_POST['client_id'],$_POST['project_description'],$_POST['project_priority'],$_POST['project_size'],$_POST['project_value'],$_POST['project_type'],$_POST['starting_date'],$_POST['ending_date'],$_POST['organization_id'],$_POST['phase_status']);
    }
?>
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/date-picker.css">
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Create New Project</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>index">                                       <i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Projects</li>
                    <li class="breadcrumb-item"><a href="<?php echo base()?>manageProject">Manage Projects</a></li>
                    <li class="breadcrumb-item active">Create New Project</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-body">
                    <div class="form theme-form">
                      <form method="POST" id="projects" action="<?php echo base()?>CreateNewProject">
                        <div class="row">
                          <div class="col-sm-6">
                            <div class="mb-3">
                              <label>Organization</label>
                              <select name="organization_id" id="organization_id" class="form-control" required onchange="GetAjaxClients(this.value)">
                                <option>Select Organization *</option>
                              <?php $Organization = NULL;
                              $Organization = $ProjectPointer->getOrganization();
                              if($Organization){ foreach($Organization as $arr){?>
                                <option value="<?php echo $arr['organization_id']?>"><?php echo $arr['organization_name']?></option>
                              <?php }}?>
                              </select>
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="mb-3">
                              <label>Client name</label>
                              <select name="client_id" id="client_id" class="form-control" required>
                              
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Code</label>
                              <input class="form-control" type="text" name="project_code" id="project_code" placeholder="Project code *" required>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Title</label>
                              <input class="form-control" type="text" name="project_name" id="project_name" placeholder="Project name *" required>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Phase</label>
                              <select name="phase_status" id="phase_status" class="form-control" required>
                                <option>Select Project Phase *</option>
                              <?php $Phase = NULL;
                              $Phase = $ProjectPointer->getPhases();
                              if($Phase){ foreach($Phase as $arr){?>
                                <option value="<?php echo $arr['phase_type']?>"><?php echo $arr['phase_type']?></option>
                              <?php }}?>
                              </select>
                            </div>
                          </div>
                        </div>
                        
                        <div class="row">
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Rate</label>
                              <input class="form-control" type="number" min="0" name="project_value" id="project_value" placeholder="Enter project Rate">
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Type</label>
                              <select class="form-select" name="project_type" id="project_type">
                                <option>Select Type</option>
                                <option value="T&M">T&M</option>
                                <option value="Fixed Cost">Fixed Cost</option>
                                <option value="Services">Services</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Priority</label>
                              <select class="form-select" name="project_priority" id="project_priority" required>
                                <option>Select Priority</option>
                                <option value="Low">Low</option>
                                <option value="Medium">Medium</option>
                                <option value="High">High</option>
                                <option value="Urgent">Urgent</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Size</label>
                              <select class="form-select" name="project_size" id="project_size">
                                <option>Select Size</option>
                                <option value="Small">Small</option>
                                <option value="Medium">Medium</option>
                                <option value="Big">Big</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Starting date</label>
                              <input class="datepicker-here form-control" type="text" name="starting_date" id="starting_date" data-language="en">
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Ending date</label>
                              <input class="datepicker-here form-control" type="text" name="ending_date" id="ending_date" data-language="en">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="mb-3">
                              <label>Enter some Details</label>
                              <textarea class="form-control" id="project_description" name="project_description" rows="3"></textarea>
                            </div>
                          </div>
                        </div>
                        <div class="row justify-content-right">
                          <div class="col">
                            <button type="reset" class="btn btn-warning">Cancel</button>
                            <button type="submit" name="submit" id="submit" value="New Project" class="btn btn-primary">Create</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
    <script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.en.js"></script>
    <script>
    $(document).ready(function(){
      <?php if($ProjectPointer->SuccessMsg){?>
      swal({
              title: "Success!",
              text: "<?php echo $ProjectPointer->SuccessMsg;?>",
              type: "success"
            }, function() {
                window.location = "<?php echo base()?>manageProject";
      });
    
      <?php }?>
      <?php if($ProjectPointer->ErrorMsg){?>
      swal({
              title: "Error!",
              text: "<?php echo $ProjectPointer->ErrorMsg;?>",
              type: "error"
          });
      
      <?php }?>  
    });
    
    function GetAjaxClients(id)
    {
     $(document).ready(function() {
            var formData = {
                'organization_id': id
            };
            $.ajax({
                type: "POST",
                url: "get_ajax_clients.php",
                data: formData
            }).done(function(users) {
                $("#client_id").html('');
                $("#client_id").html(users);
            });
        });
    }
</script>  
  </body>
</html>