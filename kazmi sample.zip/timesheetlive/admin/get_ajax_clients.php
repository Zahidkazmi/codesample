<?php
session_start();
$session_id = session_id();
include_once("../config.php");
$conf = new config();
include_once($conf->absolute_path . "Controller/AdminProjectController.php");
$projectPointer = new AdminProjectController();
$where = $data = null; 


if((isset($_POST['organization_id']) && $_POST['organization_id'] !=''))
{
    $where = "organization_id ='".$_POST['organization_id']."' AND client_status ='Active'";
}
$query="SELECT client_id,client_name FROM tblclients
WHERE
    ".$where."
ORDER BY
    client_name";
if(($rs_users = $projectPointer->CustomQuery($query))!=null)
{ ?>
    <option value="">Select Client *</option>
<?php
    foreach ($rs_users as $arr){
        ?>
        <option value="<?php echo $arr['client_id'];?>"><?php echo $arr['client_name'];?></option>
        <?php
        
    }
}
?>