<?php session_start();
include_once("config.php");
$conf= new config(); 
include_once($conf->absolute_path."functions/general.php"); 
include_once($conf->absolute_path."Controller/AdminLoginController.php");
$logPointer = new AdminLoginController();


//$logPointer->LogoutSession();
unset($_SESSION['admin_ID']);
unset($_SESSION['email']);
unset($_SESSION['username']);
unset($_SESSION['user_image']);
unset($_SESSION['mobile']);
unset($_SESSION['name']);
unset($_SESSION['User_Type']);

session_destroy();
$redirect = base()."login";
header("Refresh: 1; URL=".$redirect);
//header("Refresh: 1; URL=../index.php");
?>