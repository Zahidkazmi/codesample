<?php
session_start();
include_once('../config.php');
$conf = new config();
include_once($conf->absolute_path."Controller/AdminPhaseController.php");
$PhasePointer = new AdminPhaseController();
if($PhasePointer->AddPhase())
{
    echo '1';
}
echo '';
?>