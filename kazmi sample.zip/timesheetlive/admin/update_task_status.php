<?php 
include_once($conf->absolute_path."Controller/AdminProjectController.php");
$TaskPointer = new AdminProjectController();
$done = 0;
if($TaskPointer->UpdateTaskStatus())
{
    echo "Task Status Updated";
    $done=1;
}
?>