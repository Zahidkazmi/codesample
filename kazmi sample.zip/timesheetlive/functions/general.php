<?php 

	$crypt_key = "oru-9(£20fjasdiofewfqwfh;klncsahei223gfpaoeighew";

	//Encrypt Function
	function doEncrypt($encrypt)
	{
		global $crypt_key;
		
		$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND);
		$passcrypt = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $crypt_key, $encrypt, MCRYPT_MODE_ECB, $iv);
		$encode = base64_encode($passcrypt);
		
		return $encode;
	}

	//Decrypt Function
	function doDecrypt($decrypt)
	{
		global $crypt_key;
		
		$decoded = base64_decode($decrypt);
		$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND);
		$decrypted = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $crypt_key, $decoded, MCRYPT_MODE_ECB, $iv);
		
		return str_replace("\\0", '', $decrypted);
	}
//password generation
function genpassword($length){

	$password = NULL;
	srand((double)microtime()*1000000);
	
    $vowels = array("a", "e", "i", "o", "u");
    $cons = array("b", "c", "d", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s", "t", "u", "v", "w", "tr",
    "cr", "br", "fr", "th", "dr", "ch", "ph", "wr", "st", "sp", "sw", "pr", "sl", "cl");

    $num_vowels = count($vowels);
    $num_cons = count($cons);
	for($i = 0; $i < $length; $i++)
	{
		if($password == NULL)
		{
			$password = $cons[rand(0, $num_cons - 1)] . $vowels[rand(0, $num_vowels - 1)];	
		}else{
			$password .= $cons[rand(0, $num_cons - 1)] . $vowels[rand(0, $num_vowels - 1)];
		}		
	}
	return substr($password, 0, $length);
}

//generate the numeric code randomly
function genNumericCode($length){

    srand((double)microtime()*1000000);
	$password='';
    $vowels = array("1", "3", "5", "7", "9");
    $cons = array("0", "2", "4", "6", "8", "15", 
	"46", "85", "05", "03", "92", "33", "41", 
	"68", "51", "53", "55", "56", "97");

    $num_vowels = count($vowels);
    $num_cons = count($cons);

    for($i = 0; $i < $length; $i++){
        $password .= $cons[rand(0, $num_cons - 1)] . $vowels[rand(0, $num_vowels - 1)];
    }

    return substr($password, 0, $length);
}

//function for random no generation seeding
function make_seed() {
    list($usec, $sec) = explode(' ', microtime());
    return (float) $sec + ((float) $usec * 100000);
}

//seeding the above function
function new_pass()
{
    $nums=array('6','7','8','9','10','11','12');
    srand(make_seed());
    $randval = rand();
    $randval = $randval % 7;
    return genpassword($nums[$randval]);
}

//function to generate email
function SendEmail($mTo,$mFrom,$mSubject,$mMessage)
{//TODO*/ enable it
    mail($mTo, $mSubject, $mMessage, "MIME-Version: 1.0\r\nContent-type: text/html; charset=iso-8859-1\r\nFrom: $mFrom\r\nX-Priority: 3 (High)" );
}

//function for check email syntax
function emailsyntax_is_valid($email) 
{
	if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
		//if valid email then
		return true;
	} 
	else 
	{
		//if not valid email
		return false;
	}
}

/* This function accepts a credit card number and, optionally, a code for
* a credit card name. If a Name code is specified, the number is checked
* against card-specific criteria, then validated with the Luhn Mod 10
* formula. Otherwise it is only checked against the formula. Valid name
* codes are:
*
*    mcd - Master Card
*    vis - Visa
*    amx - American Express
*    dsc - Discover
*    dnc - Diners Club
*    jcb - JCB */

function CCVal($Num, $Name = 'n/a') {

//  Innocent until proven guilty
    $GoodCard = true;

//  Get rid of any non-digits
    $Num = ereg_replace("[^[:digit:]]", "", $Num);

//  Perform card-specific checks, if applicable
    switch ($Name) {

    case "mcd" :
      $GoodCard = ereg("^5[1-5].{14}$", $Num);
      break;

    case "vis" :
      $GoodCard = ereg("^4.{15}$|^4.{12}$", $Num);
      break;

    case "amx" :
      $GoodCard = ereg("^3[47].{13}$", $Num);
      break;

    case "dsc" :
      $GoodCard = ereg("^6011.{12}$", $Num);
      break;

    case "dnc" :
      $GoodCard = ereg("^30[0-5].{11}$|^3[68].{12}$", $Num);
      break;

    case "jcb" :
      $GoodCard = ereg("^3.{15}$|^2131|1800.{11}$", $Num);
      break;
    }

//  The Luhn formula works right to left, so reverse the number.
    $Num = strrev($Num);

    $Total = 0;

    for ($x=0; $x<strlen($Num); $x++) {
      $digit = substr($Num,$x,1);


//    If it's an odd digit, double it
      if ($x/2 != floor($x/2)) {
        $digit *= 2;

//    If the result is two digits, add them
        if (strlen($digit) == 2)
          $digit = substr($digit,0,1) + substr($digit,1,1);
      }

//    Add the current digit, doubled and added if applicable, to the Total
      $Total += $digit;
    }

//  If it passed (or bypassed) the card-specific check and the Total is
//  evenly divisible by 10, it's cool!
    if ($GoodCard && $Total % 10 == 0) return true; else return false;
}

//function to check login name validation
function invalids($login)
{
	if(preg_match('/[^a-zA-Z\d]/', $login))
	{
		return true;
	}
	return false;
}

function invalids_category($login)
{
    $i=0;
    while ($login[$i]!=''){
	    if($login[$i]=='@'||$login[$i]=='!'||$login[$i]=='`'||$login[$i]=='/'||$login[$i]==','||$login[$i]=='.'||$login[$i]=='<'||$login[$i]=='>'||$login[$i]=='?'||$login[$i]=='"'||$login[$i]==':'||$login[$i]==';'||$login[$i]=='='||$login[$i]=='+'||$login[$i]=='-'||$login[$i]=='_'||$login[$i]==')'||$login[$i]=='('||$login[$i]=='*'||$login[$i]=='^'||$login[$i]=='%'||$login[$i]=='$'||$login[$i]=='#'||$login[$i]=='@'||$login[$i]=='['||$login[$i]==']'||$login[$i]=='{'||$login[$i]=='}'){
	        return true;
	        break;
	    }
	    $i+=1;
	}
return false;//no error found
}

//checking for email mx records
function checkMxRecord($email)
{
	$domain = substr(strstr($email, '@'), 1);
    //$x = getmxrr($domain, $mxs);
    
    #$mxs[0] will return the first (or only) MX record
    #of the domain. If $mxs[0] has a value, the email
    #address is good, if $mxs[0] comes up empty, the
    #domain has no MX record(s) and cannot receive mail.
    
    if ($mxs[0]=='') {
    	return false;
    }
    
    return true;
}

//get student password encypted
function encStudentPass($pass)
{
	//first encrpting the password
	$pass=md5($pass);
	
	//now trimiming the paaword
	//ecece$pass=substr($pass,0,$trimChar);
	
	//return password
	return $pass;
}

//function to validate some html text area format
function htmlFormat($text)
{
	$msg=nl2br(stripslashes(strip_tags($text, '<b><i><u><center><img><a><hr><p>')));	
	return $msg;
}

//function to add,subtract date and time
define("ADD","add",false);
define("SUB","sub",false);
/**
 * @return date
 * @param day day
 * @param month month
 * @param year year
 * @param sec = null second
 * @param min = null minutes
 * @param hr = null hours
 * @param to_day = null to add/subtract days
 * @param to_month = null to add/subtract month
 * @param to_year = null to add/subtract year
 * @param to_sec = null to add/subtract second
 * @param to_min = null to add/subtract minutes
 * @param to_hr = null to add/subtract hours
 * @param Flag ADD | SUB
 * @param format format of the returned date
 * @desc Date Processor
 */
function ProcessDate($day,$month,$year,$sec=0,$min=0,$hr=0,$to_day=0,$to_month=0,$to_year=0,$to_sec=0,$to_min=0,$to_hr=0,$Flag,$format)
{
	if($Flag==ADD)
	{
		$form_D= mktime ($hr+$to_hr,$min+$to_min,$sec+$to_sec,$month+$to_month,$day+$to_day,$year+$to_year);		
	}
	elseif ($Flag==SUB)
	{
		$form_D= mktime ($hr-$to_hr,$min-$to_min,$sec-$to_sec,$month-$to_month,$day-$to_day,$year-$to_year);
	}
	
	return date($format,$form_D);
}

//function to upload images--can be used to upload other files
//with little modifications
/*
returned values
-1=file size increased
-2=file type does not match
-3=unknown upload error

$myFile=uploaded successfully and returns file name
0=file not set

type=0 means just to validate file not to upload
type=1 means to validate and upload
*/
function nowUpload($name,$dir,$size,$type=1)
{
	//valid and active images types
	$cert1 = "image/pjpeg"; //Jpeg type 1
	$cert2 = "image/jpeg"; //Jpeg type 2
	$cert3 = "image/gif"; //Gif type
	//$cert4 = "text/plain"; //Ief type
	$cert5 = "image/png"; //Png type
	$cert6 = "image/tiff"; //Tiff type
	$cert7 = "image/bmp"; //Bmp Type
	/*$cert8 = "application/msword"; //Wbmp type---
	//$cert9 = "application/mspowerpoint"; //Ras type---power point
	//$cert10 = "application/vnd.ms-powerpoint"; //Pnm type--ppt
	//$cert11 = "application/vnd.ms-powerpoint"; //Pbm type--ppt
	//$cert12 = "application/powerpoint"; //Pgm type--ppt
	//$cert13 = "application/x-mspowerpoint"; //Ppm type---ppt
	//$cert14 = "application/pdf"; //Rgb type---pdf
	//$cert15 = "application/x-bzip2"; //Xbm type--zip
	$cert16 = "application/x-bzip"; //Xpm type---zip
	$cert17 = "application/x-gtar"; //Xpm type---zip
	$cert18 = "multipart/x-gzip"; //Xpm type---zip
	$cert19 = "application/x-compressed"; //Xpm type---zip
	$cert20 = "application/x-zip-compressed"; //Xpm type---zip
	$cert21 = "application/zip"; //Xpm type---zip
	$cert22 = "multipart/x-zip"; //Xpm type---zip
	$cert23 = "text/csv";
	$cert24 = "text/comma-separated-values";
	$cert25 = "application/csv";
	$cert26 = "application/excel";
	$cert27 = "application/vnd.ms-excel";
	$cert28 = "application/vnd.msexcel";
	$cert29 = "text/anytext";
	$cert30 = "application/octet-stream";
	$cert31 = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	$cert32 = "application/vnd.openxmlformats-officedocument.presentationml.presentation ";
	$cert33 = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
	$cert34 = "text/html";*/
	//link: http://www.webmaster-toolkit.com/mime-types.shtml 
	//checking that if the file name exists
	
	if(isset($_FILES[$name]['name']) && !empty($_FILES[$name]['name']))
	{//upload checks				
		
		//checking for the valid file size
		if($_FILES[$name]['size']>$size || $_FILES[$name]['size']<=0)
		{//not valid
			
			//echo "Max size increased ".$_FILES[$name]['size'];
			return -1;
			
		}
		
		//checking for valid file type
		if(($_FILES[$name]['type']==$cert1) || ($_FILES[$name]['type']==$cert2) 
		|| ($_FILES[$name]['type']==$cert3) || ($_FILES[$name]['type']==$cert5) 
		|| ($_FILES[$name]['type']==$cert6) || ($_FILES[$name]['type']==$cert7) 
		 )
		{}else
		{
			//echo "file type not supported".$_FILES[$name]['type'];
			return -2;
		}
		
		//checking if the file already exists
		$copy="";
		$n=0;
		
		//spliting the extension and name
		$arr=explode(".",$_FILES[$name]['name']);
		//$path = $_FILES[$name]['name'];
		//$ext = pathinfo($path, PATHINFO_EXTENSION);
		
		//storing file name
		$myFile=$arr[0];
		
		//storing extension
		$myExtension=".".$arr[1];
		
		//comparing the existance and renaming new file
		while(file_exists($dir.$myFile.$copy.$myExtension)) {
			$copy = "_copy" . $n;
			$n++;
		}
		
		//storing the new file name
		$myFile = $myFile.$copy.$myExtension;
		
		//setting up the directory variable
		$uploaddir = $dir;
		
		//print "<pre>";

		//checking condition of 'type'
		if($type==1)
		{//valid type
		//echo 'Name: '.$_FILES[$name]['tmp_name']." path: ".$uploaddir.$myFile;exit;
			//uploading here
			if (move_uploaded_file($_FILES[$name]['tmp_name'], $uploaddir.$myFile)) {
				
				//successful upload
			    //print_r($_FILES);
				
			    return $myFile;
			    
			} else {//failed to upload--unknown reason
			  // print "Possible file upload attack!  Here's some debugging info:\n";
			  //  print_r($_FILES);
			    return -3;
			}
		} else 
			return true;
	
	}
	
	//file not set
	return 0;
}

function UploadContactSheet($name,$dir,$size,$type=1)
{
	//valid and active file types
	$cert1 = "text/csv";
	$cert2 = "text/comma-separated-values";
	$cert3 = "application/csv";
	$cert4 = "application/vnd.ms-excel";
	//link: http://www.webmaster-toolkit.com/mime-types.shtml 
	//checking that if the file name exists
	
	if(isset($_FILES[$name]['name']) && !empty($_FILES[$name]['name']))
	{//upload checks				
		//checking for the valid file size
		if($_FILES[$name]['size']>$size || $_FILES[$name]['size']<=0)
		{//not valid
			//echo "Max size increased ".$_FILES[$name]['size'];
			return -1;
		}
		
		//checking for valid file type
		if(($_FILES[$name]['type']==$cert1) || ($_FILES[$name]['type']==$cert2) || ($_FILES[$name]['type']==$cert3) || ($_FILES[$name]['type']==$cert4) )
		{}else
		{
			//echo "file type not supported".$_FILES[$name]['type'];
			return -2;
		}
		
		//checking if the file already exists
		$copy="";
		$n=0;
		
		//spliting the extension and name
		$arr=explode(".",$_FILES[$name]['name']);
		//$path = $_FILES[$name]['name'];
		//$ext = pathinfo($path, PATHINFO_EXTENSION);
		
		//storing file name
		$myFile=$arr[0];
		
		//storing extension
		$myExtension=".".$arr[1];
		
		//comparing the existance and renaming new file
		while(file_exists($dir.$myFile.$copy.$myExtension)) {
			$copy = "_copy" . $n;
			$n++;
		}
		
		//storing the new file name
		$myFile = $myFile.$copy.$myExtension;
		
		//setting up the directory variable
		$uploaddir = $dir;
		
		//print "<pre>";

		//checking condition of 'type'
		if($type==1)
		{//valid type
		
			//uploading here
			if (move_uploaded_file($_FILES[$name]['tmp_name'], $uploaddir . $myFile)) {
				
				//successful upload
			    //print_r($_FILES);
				
			    return $myFile;
			    
			} else {//failed to upload--unknown reason
			  // print "Possible file upload attack!  Here's some debugging info:\n";
			    //print_r($_FILES);
			    return -3;
			}
		} else 
			return true;
	}
	
	//file not set
	return 0;
}

function FileUpload($fname,$fsize,$ftype,$fTmpName,$dir,$size,$type=1)
{
	//valid and active images and file types
	$cert1 = "image/pjpeg"; //Jpeg type 1
	$cert2 = "image/jpeg"; //Jpeg type 2
	$cert3 = "image/gif"; //Gif type
	$cert4 = "text/plain"; //Ief type
	$cert5 = "image/png"; //Png type
	$cert6 = "image/tiff"; //Tiff type
	$cert7 = "image/bmp"; //Bmp Type
	$cert8 = "application/msword"; //Wbmp type---
	$cert9 = "application/mspowerpoint"; //Ras type---power point
	$cert10 = "application/vnd.ms-powerpoint"; //Pnm type--ppt
	$cert11 = "application/vnd.ms-powerpoint"; //Pbm type--ppt
	$cert12 = "application/powerpoint"; //Pgm type--ppt
	$cert13 = "application/x-mspowerpoint"; //Ppm type---ppt
	$cert14 = "application/pdf"; //Rgb type---pdf
	$cert15 = "application/x-bzip2"; //Xbm type--zip
	$cert16 = "application/x-bzip"; //Xpm type---zip
	$cert17 = "application/x-gtar"; //Xpm type---zip
	$cert18 = "multipart/x-gzip"; //Xpm type---zip
	$cert19 = "application/x-compressed"; //Xpm type---zip
	$cert20 = "application/x-zip-compressed"; //Xpm type---zip
	$cert21 = "application/zip"; //Xpm type---zip
	$cert22 = "multipart/x-zip"; //Xpm type---zip
	$cert23 = "text/csv";
	$cert24 = "text/comma-separated-values";
	$cert25 = "application/csv";
	$cert26 = "application/excel";
	$cert27 = "application/vnd.ms-excel";
	$cert28 = "application/vnd.msexcel";
	$cert29 = "text/anytext";
	$cert30 = "application/octet-stream";
	$cert31 = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	$cert32 = "application/vnd.openxmlformats-officedocument.presentationml.presentation ";
	$cert33 = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
	$cert34 = "application/vnd.openxmlformats-officedocument.wordprocessingml.template";
	$cert35 = "application/vnd.ms-word.document.macroEnabled.12";
	$cert36 = "text/html";
	$cert37 = "text/plain";
	//link: http://www.webmaster-toolkit.com/mime-types.shtml 
	//checking that if the file name exists
	
	if(isset($fname) && !empty($fname))
	{//upload checks				
		
		//checking for the valid file size
		if($fsize > $size || $fsize <= 0)
		{//not valid
			
			//echo "Max size increased ".$_FILES[$name]['size'];
			return -1;
			
		}
		
		//checking for valid file type
		if(($ftype==$cert1) || ($ftype==$cert2) 
		|| ($ftype==$cert3) || ($ftype==$cert5) 
		|| ($ftype==$cert6) || ($ftype==$cert7)
		|| ($ftype==$cert8) || ($ftype==$cert9) 
		|| ($ftype==$cert10) || ($ftype==$cert11) 
		|| ($ftype==$cert12) || ($ftype==$cert13)
		|| ($ftype==$cert14) || ($ftype==$cert15)
		|| ($ftype==$cert16) || ($ftype==$cert17)
		|| ($ftype==$cert18) || ($ftype==$cert19)
		|| ($ftype==$cert20) || ($ftype==$cert21)
		|| ($ftype==$cert22) || ($ftype==$cert23)
		|| ($ftype==$cert24) || ($ftype==$cert25)
		|| ($ftype==$cert26) || ($ftype==$cert27)
		|| ($ftype==$cert28) || ($ftype==$cert29)
		|| ($ftype==$cert30) || ($ftype==$cert31)
		|| ($ftype==$cert32) || ($ftype==$cert33)
		|| ($ftype==$cert34) || ($ftype==$cert35)
		|| ($ftype==$cert36) || ($ftype==$cert37)
		 )
		{}else
		{
			echo "file type not supported".$ftype;
			return -2;
		}
		
		//checking if the file already exists
		$copy="";
		$n=0;
		
		//spliting the extension and name
		$arr=split("\.",$fname);
		
		//storing file name
		$myFile=$arr[0];
		
		//storing extension
		$myExtension=".".$arr[1];
		
		//comparing the existance and renaming new file
		while(file_exists($dir.$myFile.$copy.$myExtension)) {
			$copy = "_copy" . $n;
			$n++;
		}
		
		//storing the new file name
		$myFile = $myFile.$copy.$myExtension;
		
		//setting up the directory variable
		$uploaddir = $dir;
		
		//print "<pre>";

		//checking condition of 'type'
		if($type==1)
		{//valid type
		
			//uploading here
			if ($myFile) {
				
				//successful upload
			    //print_r($_FILES);
				
			    return $myFile;
			    
			} else {//failed to upload--unknown reason
			  // print "Possible file upload attack!  Here's some debugging info:\n";
			    //print_r($_FILES);
			    return -3;
			}
		} else 
			return true;
	
	}
	
	//file not set
	return 0;
}


//function to maintain the state
/**
 * @return void
 * @param $name colname
 * @param $state state-1=dropdown--state-2=radio--state-3=textarea--no-state=textfield
 * @param $val value
 * @desc post method has more periority :-)
 */
function State($name,$state=0,$val=null)
{
	if(isset($_POST[$name]) && !empty($_POST[$name]))
	{
		if($state==1 && $val==$_POST[$name])
			echo "selected";
		elseif ($state==2 && $val==$_POST[$name])
			echo "checked";
		elseif($state==3)
			echo stripslashes($_POST[$name]);//added stripslashes function
		else
			echo "value=\"".$_POST[$name]."\"";
	} 
	else if(isset($_GET[$name]) && !empty($_GET[$name]))
	{
		if($state==1 && $val==$_GET[$name])
			echo "selected";
		elseif ($state==2 && $val==$_GET[$name])
			echo "checked";
		elseif($state==3)
			echo $_GET[$name];
		else
			echo "value=\"".$_GET[$name]."\"";
	} 
}

//this is the similar function as above but with little modification
//that is used to handle the categories in autoselect
function State2($name,$state=0,$val=null)
{
	if(isset($_POST[$name]) && !empty($_POST[$name]))
	{
		if($state==1 && $val==$_POST[$name])
			return "selected";
		/*elseif ($state==2 && $val==$_POST[$name])
			echo "checked";
		elseif($state==3)
			echo $_POST[$name];
		else
			echo "value=\"".$_POST[$name]."\"";*/
	} 
	else if(isset($_GET[$name]) && !empty($_GET[$name]))
	{
		if($state==1 && $val==$_GET[$name])
			return "selected";
		/*elseif ($state==2 && $val==$_GET[$name])
			echo "checked";
		elseif($state==3)
			echo $_GET[$name];
		else
			echo "value=\"".$_GET[$name]."\"";*/
	} 
}

//function to maintain the state
/**
 * @return void
 * @param $name colname
 * @param $state state-1=dropdown--state-2=radio--state-3=textarea--no-state=textfield
 * @param $val value
 * @desc post method has more periority :-)
 *///just returns instead of echo
function State3($name,$state=0,$val=null)
{
	if(isset($_POST[$name]) && !empty($_POST[$name]))
	{
		if($state==1 && $val==$_POST[$name])
			return "selected";
		elseif ($state==2 && $val==$_POST[$name])
			return "checked";
		elseif($state==3)
			return $_POST[$name];
		else
			return "value=\"".$_POST[$name]."\"";
	} 
	else if(isset($_GET[$name]) && !empty($_GET[$name]))
	{
		if($state==1 && $val==$_GET[$name])
			return "selected";
		elseif ($state==2 && $val==$_GET[$name])
			return "checked";
		elseif($state==3)
			return $_GET[$name];
		else
			echo "value=\"".$_GET[$name]."\"";
	} 
	
}
	

	function mailkaro ($toaddress, $body, $sub) 
	{
		
		require_once '../PHPMailerAutoload.php';
		
		//Create a new PHPMailer instance
		$mail = new PHPMailer;
		//Tell PHPMailer to use SMTP
		$mail->isSMTP();
		//Enable SMTP debugging
		// 0 = off (for production use)
		// 1 = client messages
		// 2 = client and server messages
		$mail->SMTPDebug = 0;
		//Ask for HTML-friendly debug output
		$mail->Debugoutput = 'html';
		//Set the hostname of the mail server
			
		$mail->Host = "smtp.office365.com";
		//Whether to use SMTP authentication
		$mail->SMTPAuth = TRUE;
	
		/* Set the encryption system. */
		$mail->SMTPSecure = 'tls';
	
		/* SMTP authentication username. */
		$mail->Username = 'timesheet@viltco.com';
			
		/* SMTP authentication password. */
		$mail->Password = 'Hello@3221';
	
		//Set the SMTP port number - likely to be 25, 465 or 587
		$mail->Port = 465;
		
		//Set who the message is to be sent from
		$mail->setFrom('timesheet@viltco.com', 'Timesheet Admin');
		//Set an alternative reply-to address
		//$mail->addReplyTo('timesheet@viltco.com', 'Timesheet Admin');
	
		//Set who the message is to be sent to
		$mail->addAddress($toaddress, '');
		//Set the subject line
		$mail->Subject = $sub;
		//Read an HTML message body from an external file, convert referenced images to embedded,
		//convert HTML into a basic plain-text alternative body
		//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
		$mail->msgHTML($body);
		//Replace the plain text body with one created manually
		//$mail->Body = $body;
		//Attach an image file
		//$mail->addAttachment('images/phpmailer_mini.png');
		
		//send the message, check for errors
		if (!$mail->send()) {
			return 0;
		   // echo "Mailer Error: " . $mail->ErrorInfo;
		} else {
			return 1;
			//echo "Message sent!";
		}
		
	}
	
	function mailwithAttachment ($toaddress, $body, $sub, $pdfslip) 
	{
		/*
		MAIL_DRIVER=smtp
		MAIL_HOST=smtp.office365.com
		MAIL_PORT=587
		mail_username=timesheet@viltco.com
		MAIL_PASSWORD=Hello@3221
		MAIL_ENCRYPTION=tls
		MAIL_FROM_NAME='TImesheet Admin'
		mail_from_address='timesheet@viltco.com' 
		*/
		
		require_once '../PHPMailerAutoload.php';
		
		//Create a new PHPMailer instance
		$mail = new PHPMailer;
		//Tell PHPMailer to use SMTP
		$mail->isSMTP();
		//Enable SMTP debugging
		// 0 = off (for production use)
		// 1 = client messages
		// 2 = client and server messages
		$mail->SMTPDebug = 0;
		//Ask for HTML-friendly debug output
		$mail->Debugoutput = 'html';
		//Set the hostname of the mail server
			
		$mail->Host = "smtp.office365.com";
		//Whether to use SMTP authentication
		$mail->SMTPAuth = TRUE;
	
		/* Set the encryption system. */
		$mail->SMTPSecure = 'tls';
	
		/* SMTP authentication username. */
		$mail->Username = 'timesheet@viltco.com';
			
		/* SMTP authentication password. */
		$mail->Password = 'Hello@3221';
	
		//Set the SMTP port number - likely to be 25, 465 or 587
		$mail->Port = 465;
		
		//Set who the message is to be sent from
		$mail->setFrom('timesheet@viltco.com', 'Admin');
		//Set an alternative reply-to address
		//$mail->addReplyTo('info@viltco.com', 'ETA Admin');
	
		//Set who the message is to be sent to
		$mail->addAddress($toaddress, '');
	
		//Set who the message is to be sent in bcc.
		//$mail->addBCC("zahid.kazmi@viltco.com", "Syed Zahid Manzoor Kazmi");
	
		//Set the subject line
		$mail->Subject = $sub;
	
		//Read an HTML message body from an external file, convert referenced images to embedded,
		//convert HTML into a basic plain-text alternative body
		//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
		$mail->msgHTML($body);
	
		//Replace the plain text body with one created manually
		//$mail->Body = $body;
	
	
		//Attach a file
		$mail->addAttachment('../pdffiles/'.$pdfslip);
		
		//send the message, check for errors
		if (!$mail->send()) {
			return 0;
		   // echo "Mailer Error: " . $mail->ErrorInfo;
		} else {
			return 1;
			//echo "Message sent!";
		}
		
	}	
	
	function dbDateFormat($inputDate){ // 05/20/2021
		$dateParts=explode("/", $inputDate);
		$dbDate=$dateParts[2].'-'.$dateParts[0].'-'.$dateParts[1];
		return $dbDate;
	}

	function dbDateForRange($inputDate){
		$dateParts=explode("/", $inputDate);
		$dbDate=$dateParts[2].'-'.$dateParts[0].'-'.$dateParts[1];
		return $dbDate;
	}
	
	function AppDateFormat($inputDate){//2019-05-01 13-05-2019
		$dateParts=explode("-", $inputDate);
		$AppDate=$dateParts[1].'/'.$dateParts[2].'/'.$dateParts[0];
		$AppDate = date('m/d/Y',strtotime($AppDate));
		return $AppDate;
	}

	function test_input($data) 
	{
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
  	}
?>