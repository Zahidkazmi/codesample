<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/SubAdminReportController.php");
    $ActivityReportPointer = new SubAdminReportController();
    if(isset($Route[1]) && $Route[1] == 'explore'){unset($_SESSION['admin_query']);}
    $Employees = $Projects = NULL;
    $Employees = $ActivityReportPointer->getOrganizationEmployees();
    $Projects = $ActivityReportPointer->getOrganizationProjects();
    $data = $ActivityReportPointer->getActivityReportLists();
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("adminsidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Activity List </h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>dashboard"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Reports</li>
                    <li class="breadcrumb-item active">Activity Reports</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                <div class="row">
                    <div class="col-md-12" id="AdvSearch">
                        <form role="form" action="<?php echo base()?>activityreport" class="px-4 py-3" name="SearchItem" method="post">
                            <div class="row d-flex align-items-center">
                                <div class="col-md-12 text-left mb-3">
                                    <b>Advanced Search Filters</b>
                                </div>
                                
                                <div class="col-md-4 text-left pr-lg-0 mt-1">
                                    <div class="form-group m-0">
                                        <select class="form-control" id="user_id" name="user_id" onchange="GetUserProject(this.value);">
                                              <option value="">Select Employee</option>
                                          <?php if($Employees){ foreach($Employees as $arr){ ?>    
                                              <option value="<?php echo $arr['user_id']; ?>"><?php echo $arr['first_name']." ".$arr['last_name']; ?></option>
                                          <?php }} ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 text-left mt-1">
                                    <div class="form-group m-0">
                                    <select class="form-control" id="project_id" name="project_id">
                                              <option value="">Select Project</option>
                                            <?php if($Projects){ foreach($Projects as $arr){ ?>       
                                              <option value="<?php echo $arr['project_id']; ?>"><?php echo $arr['project_name']; ?></option>
                                          <?php }} ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 text-right">
                                    <button type="submit" name="search_record" value="Search" class="btn btn-primary btn-sm"><i class="fa fa-search pr-2"></i>Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-12 f-right">
                      <a href="#" data-toggle="collapse" id="show_hide" data-target="#AdvSearch" class="btn btn-primary btn-sm mr-2"><i class="fa fa-sliders"></i> Show / Hide Advanced Search</a>
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="example">
                        
                                <thead>
                                <tr>
                                    <th>Employee Name</th>
                                    <th>Project</th>
                                    <th>Module</th>
                                    <th>Task</th>
                                    <th>Phase</th>
                                    <th>Estimated Time</th>
                                    <th>Created Date</th>
                                    <th>Spend Time</th>
                                    <th>Start Date</th>
                                    <th>Ending Date</th>
                                    <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                  <?php foreach($data as $row){ 

                                  $x = $ActivityReportPointer->getTaskActivityDetail($row['task_id']);

                                    if($row['task_status']=="Completed"){ $class= "bg-success";}
                                    else if($row['task_status']=="Pending"){ $class= "bg-primary";}
                                    else if($row['task_status']=="Inprogress"){ $class= "bg-warning";}
                                    else if($row['task_status']=="On Hold"){ $class= "bg-danger";}
                                    else if($row['task_status']=="Lead Approval"){ $class= "bg-info";}
                                    else{
                                        $class="font-info";
                                    }   
                                ?>
                                    <tr>
                                        <td><?php echo $row['first_name']." ".$row['last_name']?></td>
                                        <td><?php echo $row['project_name'];?></td>
                                        <td><?php echo $row['module_name'];?></td>
                                        <td><?php echo $row['task_description'];?></td>
                                        <td><?php echo $row['phase_type'];?></td>
                                        <td><?php echo $row['estimated_hours'];?></td>
                                        <td><?php echo $row['created_at'];?></td>
                                        <td><?php $x = $ActivityReportPointer->getTaskActivityDetail($row['task_id']); echo $x[0]['hour_spend'] ?></td>
                                        <td><?php $x = $ActivityReportPointer->getTaskActivityDetail($row['task_id']); echo $x[0]['start_date']?></td>
                                        <td><?php $x = $ActivityReportPointer->getTaskActivityDetail($row['task_id']); echo $x[0]['end_Date']?></td>
                                        <td class="<?php echo $class;?>"><?php echo $row['task_status'];?></td>
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            </div>
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
    <script>
      // slide search div.
      $(document).ready(function(){
          $("#AdvSearch").hide();
          $("#show_hide").show();

          $('#show_hide').click(function(){
              $("#AdvSearch").slideToggle();
          });
      });

    function GetUserProject(id)
    {
     $(document).ready(function() {
            var formData = {
                'user_id': id
            };
            $.ajax({
                type: "POST",
                url: "<?php echo base()?>getuser_ajax_projects",
                data: formData
            }).done(function(projects) {
                $("#project_id").html('');
                $("#project_id").html(projects);
            });
        });
    }
    </script>
</body>
</html>