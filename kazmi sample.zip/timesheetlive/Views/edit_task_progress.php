<?php 
include_once($conf->absolute_path."Controller/EmployeeController.php");
$EmployeePointer = new EmployeeController();
$done = $update = $lead = 0;
if(isset($Route[1]) && isset($Route[2]) && isset($Route[3]))
{
    $_GET['project_id'] = $Route[1];
    $_GET['task_id'] = $Route[2];
    $_GET['module_id'] = $Route[3];
    $_GET['phase_id'] = $Route[4];
    $estimated_hours = $Route[5];
    $_GET['id'] = $Route[1];
}
if($EmployeePointer->IsProjectLead())
{
    $lead=1;
}
if($EmployeePointer->UpdateTaskProgress())
{
    $update = 1;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/fontawesome.css">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/icofont.css">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/themify.css">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/flag-icon.css">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/feather-icon.css">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/style.css">
<link id="color" rel="stylesheet" href="<?php echo $conf->site_url;?>assets/css/color-1.css" media="screen">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/date-picker.css">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/responsive.css">
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/bootstrap.css">
</head>
<?php if($update && $EmployeePointer->SuccessMsg){?>
    <div class="alert alert-success dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-up"></i>
        <p> <?php echo $EmployeePointer->SuccessMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<?php if($EmployeePointer->ErrorMsg !=''){?>
    <div class="alert alert-danger dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-down"></i>
        <p> <?php echo $EmployeePointer->ErrorMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<div class="modal-body">
    <div class="row"><div class="col-sm-12"><h3>Task Estimated Hours: <?php echo $estimated_hours;?></h3><hr></div></div>
    <form method="post" id="task_progress" action="<?php echo base()."edit_task_progress/".$_GET['project_id']."/".$_GET['task_id']."/".$_GET['module_id']."/".$_GET['phase_id']."/";?>">
        <div class="row">                             
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Start Date</label>
                    <input class="datepicker-here form-control" type="text" name="start_date" id="start_date" data-language="en" placeholder="Date" required>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >End Date</label>
                    <input class="datepicker-here form-control" type="text" name="end_date" id="end_date" data-language="en" placeholder="Date" required>
                </div>
            </div>
            <div class="col-sm-6 mt-2">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Hour Spend</label>
                    <input class="form-control" type="number" min="0" name="hour_spend" id="hour_spend" placeholder="1" required>
                </div>
            </div>
            <div class="col-sm-6 mt-2">
                <div class="form-group">
                    <label class="w-100 d-flex justify-content-start" >Status</label>
                    <select name="task_status" id="task_status" class="form-control" required>
                        <option value="">Select Status</option>
                        <option value="Pending">Pending</option>
                        <option value="On Hold">On Hold</option>
                        <option value="Inprogress">Inprogress</option>
                        <option value="Lead Approval">Lead Approval</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-12 mt-3">
                <div class="from-group">
                    <label class="w-100 d-flex justify-content-start" >Comments</label>
                    <textarea name="description" id="description" class="form-control" placeholder="Your comments" required></textarea>
                </div>
                <div class="from-group mt-3 justify-content-right">
                    <button type="button" <?php if($update){?>onClick="window.parent.closeModal('#editModal',1)"<?php }else{?>onClick="window.parent.closeModal('#editModal',0)"<?php }?> class="btn btn-warning">Close</button>
                    <button type="submit" name="update" value="UPDATE" id="submit" class="btn btn-primary">Update</button>
                </div>                        
            </div>
        </div>
    </form>
</div>
<script src="<?php echo $conf->site_url;?>assets/js/jquery-3.5.1.min.js"></script>
<!-- Bootstrap js-->
<script src="<?php echo $conf->site_url;?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
<script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.js"></script>
<script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.en.js"></script>

<!-- js form validator -->
<script src="<?php echo $conf->site_url;?>assets/js/validate/jquery.validate.min.js"></script>


<script>
$(document).ready(function(){

$('form[id="task_progress"]').validate({
        rules: {
            start_date: {
              required: true,
            },
            end_date: {
              required: true,
            },
            hour_spend:{
               required: true
            },
            task_status:{
              required: true
            },
            description:{
              required: true
            }
        },
        messages: {
            start_date: {
              required: "Please choose starting date."
            },
            end_date: {
              required: "Please choose ending date."
            },
            hour_spend: {
              required: "Please enter spending hours."
            },
            task_status: {
              required: "Please select task status."
            },
            description: {
              required: "Please enter description."
            }
        },
        //onsubmit: false,
        submitHandler: function(form) {
          form.submit();
        }
        
});

})
</script>


</html>