<?php
session_start();
include_once('../config.php');
$conf = new config();
include_once($conf->absolute_path."Controller/SubAdminClientController.php");
$ClientPointer = new SubAdminClientController();
if($ClientPointer->AddClient())
{
    echo '1';
}
echo '';
?>