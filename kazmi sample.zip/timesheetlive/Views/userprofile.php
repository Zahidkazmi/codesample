<?php include_once("header.php");
include_once($conf->absolute_path . "Controller/EmployeeProfileController.php");
$employeeProfilePointer = new EmployeeProfileController();
$updateprofile = $changepass = $update_security = 0;


$country = $employeeProfilePointer->getCountries();
$city = $employeeProfilePointer->getCities();
$company = $employeeProfilePointer->getCompanies();
$question = $employeeProfilePointer->getSecurityQuestions();
if (isset($_POST['ChangePicture']) && $_POST['ChangePicture'] == "ChangePicture") {
  $employeeProfilePointer->UploadMyPicture();
}

if (isset($_POST['UpdatePersonal']) && $_POST['UpdatePersonal'] == "UpdatePersonal") {

  $employeeProfilePointer->UpdateMyProfile();
  $updateprofile = 1;
}
if (isset($_POST['ChangePassword']) && $_POST['ChangePassword'] == "ChangePassword") {
  if ($employeeProfilePointer->change_password()) {
    if (isset($_SESSION['reset_code'])) {
      unset($_SESSION['reset_code']);
    }
    $changepass = 1;
    $update = 1;
  }
}
if (isset($_POST['ChangeSecurity']) && $_POST['ChangeSecurity'] == "ChangeSecurity") {
  $employeeProfilePointer->SetSecurityQuestion();
  $update_security = 1;
}
$data = $employeeProfilePointer->ShowEmployeePersonal();
?>

<!-- tap on top starts-->
<div class="tap-top"><i data-feather="chevrons-up"></i></div>
<!-- tap on tap ends-->
<!-- page-wrapper Start-->
<div class="page-wrapper compact-sidebar" id="pageWrapper">
  <!-- Page Header Start-->
  <?php include_once("topmenu.php"); ?>
  <!-- Page Header Ends -->
  <!-- Page Body Start-->
  <div class="page-body-wrapper compact-wrapper box-layout">
    <!-- Page Sidebar Start-->

    <?php
    $designation = $_SESSION['designation'];

    if ($designation == 'Admin' || $designation == 'admin' || $designation == 'ADMIN') {
      include_once("adminsidebar.php");
    } else {
      include_once("sidebar.php");
    }
    ?>
    <!-- Page Sidebar Ends-->
    <div class="page-body">
      <div class="container-fluid">
        <div class="page-title">
          <div class="row">
            <div class="col-6">
              <h3>Dashboard</h3>
            </div>
            <div class="col-6">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0);"><i data-feather="home"></i></a></li>
                <li class="breadcrumb-item active">Dashboard</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <!-- Container-fluid starts-->
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-4">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title mb-0">My Profile</h4>
                <div class="card-options"><a class="card-options-collapse" href="#" data-bs-toggle="card-collapse" data-bs-original-title="" title=""><i class="fe fe-chevron-up"></i></a><a class="card-options-remove" href="#" data-bs-toggle="card-remove" data-bs-original-title="" title=""><i class="fe fe-x"></i></a>
                </div>
              </div>
              <form method="POST" action="<?php echo base() . "userprofile"; ?>" enctype="multipart/form-data">
                <div class="row mb-2">
                  <div class="col-auto" id="profile_pic" style="height: 90px; width:90px; left:2%;"><img id="preViewImage" class="photo img-70 rounded-circle" alt="" src="<?php echo $conf->site_url; ?>assets/images/user/<?php echo $data[0]['image']; ?>">
                    <input type="file" name="image" id="image" class="form-control" value="" style=" display:none;">
                    <label for="image" id="UploadbBtn" style="transform: translate(-2px, -16px); width: 73px; display:none; "><i data-feather="camera" id="show" class="w-100 text-primary"></i> </label>
                  </div>
                  <div class="col">
                    <h3 class="mb-1"> <?php echo $data[0]['first_name']; ?> </h3>
                    <h3 class="mb-4"> <?php echo $data[0]['last_name']; ?> </h3>
                  </div>
                </div>
                <div class="mb-2">
                </div>
                <div class="mb-2">
                  <div class="text-center p-4">
                    <button style="display:none;" class="btn btn-primary" id="btn" name="ChangePicture" value="ChangePicture" type="submit">Update Image</button>
                  </div>
                </div>
              </form>
            </div>
            <h5 class="text-primary">Official Information</h5>
            <div class="card-body my-4">
              <div class="mb-3 row">
                <label class="col-sm-3 col-form-label"><b>Company</b>:</label>
                <div class="col-sm-9">
                  <p class="mt-2"> <?php echo $company[0]['organization_name']; ?> </p>
                </div>
              </div>
              <div class="mb-3 row">
                <label class="col-sm-3 col-form-label"><b>Designation</b>:</label>
                <div class="col-sm-9">
                  <p class="mt-2"><?php echo $data[0]['designation']; ?></p>
                </div>
              </div>

              <div class="mb-3 row">
                <label class="col-sm-3 col-form-label"><b>Address</b></label>
                <div class="col-sm-9">
                  <p class="mt-2"> <?php echo $data[0]['address_Line1']; ?></p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-8">
            <div class="card-header">
              <h4 class="card-title mb-0">Edit Profile</h4>
              <div class="card-options"><a class="card-options-collapse" href="#" data-bs-toggle="card-collapse" data-bs-original-title="" title=""><i class="fe fe-chevron-up"></i></a><a class="card-options-remove" href="#" data-bs-toggle="card-remove" data-bs-original-title="" title=""><i class="fe fe-x"></i></a></div>
            </div>
            <div class="card-body">
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item"><a class="nav-link <?php if (!isset($Route[1]) && $updateprofile == 0 && $update_security == 0 && $changepass == 0) {echo 'active';} ?> " id="about-tab" data-bs-toggle="tab" href="#about" role="tab"aria-controls="About"aria-selected="false" data-bs-original-title="" title="">Details</a></li>
                <li class="nav-item"><a class="nav-link  <?php if ($updateprofile == 1 && $update_security == 0 && $changepass == 0) { echo'active'; } ?>" id="personal-tabs" data-bs-toggle="tab" href="#personal" role="tab" aria-controls="Personal"aria-selected="false" data-bs-original-title="" title="">Edit Details</a></li> 
                <li class="nav-item"><a class="nav-link  <?php if (isset($Route[1])  && ($Route[1] == "RP") || ( $updateprofile == 0 && $update_security == 0 && $changepass == 1)) { echo 'active'; } ?> " id="password-tabs" data-bs-toggle="tab" href="#password" role="tab" aria-controls="Password" aria-selected="false">Change Password</a></li>
                <li class="nav-item"><a class="nav-link  <?php if (isset($Route[1])  && ($Route[1] == "SC") || ($updateprofile == 0 && $update_security == 1 && $changepass == 0)) {  echo'active';} ?>" id="question-tab" data-bs-toggle="tab" href="#security-settings" role="tab" aria-controls="Question" aria-selected="true" data-bs-original-title="" title="">Password Recovery</a></li>
              </ul>
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade <?php if (!isset($Route[1]) && $updateprofile == 0 && $update_security == 0 && $changepass == 0) { echo 'active show';} ?>" id="about" role="tabpanel" aria-labelledby="about-tab">
                  <h4 class="text-primary mt-2"> About Me </h4>
                  <div class="card-body">
                    <?php echo $data[0]['description']; ?>
                    </p>
                  </div>
                  <hr>
                  <h5 class="text-primary">Personal Information</h5>
                  <div class="mb-3 row">
                    <label class="col-sm-3 col-form-label" for="inputPassword3"><b>Name:</b></label>
                    <div class="col-sm-9 mt-2">
                      <?php echo $data[0]['first_name'] . " " . $data[0]['last_name'] ?>
                    </div>
                  </div>
                  <div class="mb-3 row">
                    <label class="col-sm-3 col-form-label" for="inputEmail3"><b>Email:</b></label>
                    <div class="col-sm-9  mt-2">
                      <?php echo $data[0]['email']; ?>
                    </div>
                  </div>
                  <div class="mb-3 row">
                    <label class="col-sm-3 col-form-label" for="inputPassword3"><b>Contact Number</b></label>
                    <div class="col-sm-9  mt-2">
                      <?php echo $data[0]['mobile']; ?>
                    </div>
                  </div>
                  <div class="mb-3 row">
                    <label class="col-sm-3 col-form-label" for="inputPassword3"><b>Gender</b></label>
                    <div class="col-sm-9  mt-2">
                      <?php echo $data[0]['gender']; ?>
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade <?php if ($updateprofile == 1 && $update_security == 0 && $changepass==0 && $about == 0) { echo 'active show'; } ?>" id="personal" role="tabpanel" aria-labelledby="personal-tab">
                  <div class="card-body">
                    <form method="POST" name="edit_details" id="edit_details" action="<?php echo base() . "userprofile"; ?>">
                      <div class="row">
                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input class="form-control" type="text" name="first_name" id="first_name" value="<?php echo $data[0]['first_name']; ?>" data-bs-original-title="">
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input class="form-control" type="text" name="last_name" id="last_name" value="<?php echo $data[0]['last_name']; ?>" data-bs-original-title="">
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-6">
                          <label class="form-label">Mobile</label>
                          <input class="form-control" name="mobile" id="mobile" value="<?php echo $data[0]['mobile']; ?>">
                        </div>
                        <div class="col-sm-6 col-md-6">
                          <label class="form-label">Gender</label>
                          <select name="gender" id="gender" class="form-control">
                            <option value="">Please select gender</option>
                            <option <?php if ($data[0]['gender'] == 'Male') {
                                      echo "selected";
                                    } ?> value="Male">Male</option>
                            <option <?php if ($data[0]['gender'] == 'Female') {
                                      echo "selected";
                                    } ?> value="Female">Female</option>
                          </select>
                        </div>
                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Country</label>
                            <select class="form-control btn-square" name="country_id" id="country_id">
                              <option value="">Please select country</option>
                              <?php foreach ($country as $arr) { ?>
                                <option <?php if ($arr['country_name'] == $data[0]['country_name']) {  echo 'selected';  } ?> value="<?php echo $arr['country_ID'] ?>"> <?php echo $arr['country_name']; ?> </option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">City</label>
                            <select class="form-control btn-square" name="city_id" id="city_id">
                              <option value="">Please select city</option>
                              <?php foreach ($city as $cities) { ?>
                                <option <?php if ($cities['city_name'] == $data[0]['city_name']) {
                                          echo 'selected';
                                        } ?> value="<?php echo $cities['city_ID'] ?>"> <?php echo $cities['city_name']; ?> </option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-12">
                          <div>
                            <label class="form-label">About Me</label>
                            <textarea class="form-control" rows="5" name="description" id="description" placeholder="Enter About your description"><?php echo $data[0]['description']; ?></textarea>
                          </div>
                        </div>
                        <div class="text-start mt-2">
                          <button class="btn btn-primary" name="UpdatePersonal" value="UpdatePersonal" type="submit" data-bs-original-title="" title="">Update Personal info</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div class="tab-pane fade <?php if (isset($Route[1])  && ($Route[1] == "RP") ||( $updateprofile == 0 && $update_security == 0 && $changepass == 1)) {  echo 'active show';  } ?>" id="password" role="tabpanel" aria-labelledby="password-tab">
                  <div class="card-body">
                    <?php if (isset($Route[1]) && ($Route[1] == "RP")) { ?>
                      <h5 class="absolute-text mb-3 alert alert-danger"><img class="mr-3 absolute-text" src="<?php echo $conf->site_url; ?>assets/images/no-secret.png" height="20px" width="20px" style="object-fit:cover;" alt="Reset account password"><span class="mb-2">Account recovered.<span><br /><br /> <span class="ml-5 mt-3">Please reset your password now in old password field please use</span> <br /> <i class="fa fa-hand-o-right ml-5 mt-3 mb-3"></i> <?php echo $_SESSION['reset_code'] ?><br /> <span class="ml-5">and generate a new password.</span></h5>
                    <?php } ?>
                    <form method="POST" id="changepassword" id="changepassword" action="<?php echo base() . "userprofile"; ?>">
                      <div class="row">
                        <div class="col-sm-12 col-md-12">
                          <div class="mb-3">
                            <label class="form-label">Old Password</label>
                            <input class="form-control" name="password" id="password" type="password" placeholder="Old Password">
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input class="form-control" name="new_pass" id="new_pass" type="password" placeholder="New Password">
                          </div>
                        </div>
                        <div class="col-sm-6 col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input class="form-control" name="new_pass2" id="new_pass2" type="password" placeholder="Confirm Password">
                          </div>
                        </div>
                        <div class="text-start">
                          <button class="btn btn-primary" name="ChangePassword" value="ChangePassword" type="submit" data-bs-original-title="" title="">Update Password</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div id="security-settings" class="tab-pane fade <?php if (isset($Route[1])  && ($Route[1] == "SC") || ($updateprofile == 0 && $update_security == 1 && $changepass == 0)) {  echo 'active show';} ?>">
                  <div class="pt-3">
                    <?php if ($data[0]['security_id'] != '') { ?>
                      <h5 class="text-capitalize absolute-text mb-3 alert alert-success"><img class="mr-3 absolute-text" src="<?php echo $conf->site_url; ?>assets/images/secret.png" height="20px" width="20px" style="object-fit:cover;" alt="Account Secret is enabled">Your account recovery secret is enabled.</h5>
                    <?php } else { ?>
                      <h5 class="text-capitalize absolute-text mb-3 alert alert-secondary"><img class="mr-3 absolute-text" src="<?php echo $conf->site_url; ?>assets/images/no-secret.png" height="20px" width="20px" style="object-fit:cover;" alt="Account Secret not enable">Your account recovery secret is not enabled.</h5>
                    <?php } ?>
                    <div class="settings-form">
                      <form action="<?php echo base() . "userprofile"; ?>" id="Secret" name="Secret" method="post">
                        <div class="form-row mt-3">
                          <p class="text-body">
                          <h3 class="text-dark text-capitalize mb-3">Tips to complete account recovery steps</h3>
                          <ul class="alert alert-info col-12 ml-1">
                            Use a familiar device & location If possible:
                            <li><i class="fa fa-hand-o-right mt-3"></i> Use a computer, phone, or tablet where you frequently sign in</li>
                            <li><i class="fa fa-hand-o-right"></i> Use the same browser (like Chrome or Safari) that you usually do</li>
                            <li><i class="fa fa-hand-o-right"></i> Be in a location where you usually sign in, like at home or at office</li>
                          </ul>
                          <h3 class="text-dark text-capitalize mb-1 mt-3">Be exact with passwords & answer to security questions</h3>
                          <ul class="mt-3 alert alert-info col-12 ml-1">
                            Details matter, so avoid typs and pay attention to UPPERCASE and lowercase letters.
                            <li><i class="fa fa-hand-o-right mt-3"></i> If don't Remember your last password</li>
                            <li><i class="fa fa-hand-o-right"></i> Answer to security Questions</li>
                            <li><i class="fa fa-hand-o-right"></i> Consider a different variation of the answer. For example, try "PK" instead of "Pakistan" or "VT" instead of "Viltco Technology."</li>
                          </ul>
                          </p>
                        </div>
                        <hr>
                        <div class="mt-4 col-lg-12">
                          <h4 class="text-dark text-capitalize mb-1 mt-3">Choose one of the following question and save your secret <span class="text-danger">*</span></h4>
                          <label for="Security_ID" class="error text-capitalize mb-3" style="display:none;">Please Choose one of the following question.</label>

                          <?php foreach ($question as $qarr) { ?>
                            <div class="form-check flex-grow-1 radio-group">
                              <input type="radio" id="radio<?php echo $qarr['security_id'] ?>" name="security_id" value="<?php echo $qarr['security_id'] ?>">
                              <label class="radio-green" for="radio<?php echo $qarr['security_id'] ?>"> <?php echo $qarr['question'] ?> ?</label>
                            </div>
                          <?php } ?>
                          <!-- <label id="radio-error" class="error" for="radio">Please choose any one.</label> -->
                          <p id="question_error_text" class="text-danger"></p>
                        </div>
                        <div class="form-row">
                          <div class="form-group col-lg-12">
                            <label class="text-label">Your Secret <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="security_answer" name="security_answer" placeholder="Enter your secret..." required>
                          </div>
                        </div>
                          <button class="btn btn-primary my-4" type="submit" name="ChangeSecurity" value="ChangeSecurity" onclick="return getData()">Update Secret</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Container-fluid Ends-->
            </div>
            <!-- footer start-->
            <?php include_once("footer.php"); ?>
            <!-- footer end-->
          </div>
        </div>
      </div>
      <?php include_once("js.php"); ?>
     
      <script>
        //work about profile pic profile image select by click on camera icon. 
        var imgDiv = document.querySelector('#profile_pic');
        var img = document.querySelector('.photo');
        var file = document.querySelector('#image');
        var UploadBtn = document.querySelector('#UploadbBtn');
        //if user hover on profile then show icon.
        imgDiv.addEventListener('mouseenter', function() {
          UploadBtn.style.display = "block";
        });
        //if hove out from img div
        imgDiv.addEventListener('mouseleave', function() {
          UploadBtn.style.display = "none";
        });
        //img showing functionality
        // for priviewe
        $("#preViewImage").click(function(e) {
          $("#image").click();
        });

        function fasterPreview(uploader) {
          if (uploader.files && uploader.files[0]) {
            $('#preViewImage').attr('src',
              window.URL.createObjectURL(uploader.files[0]));
          }
        }
        $("#image").change(function() {
          fasterPreview(this);
          $("#btn").show()
        });
      </script>
      <script>
        $(document).ready(function() {
          <?php if ($employeeProfilePointer->SuccessMsg) { ?>
            swal({
              title: "Success!",
              text: "<?php echo $employeeProfilePointer->SuccessMsg; ?>",
              type: "success"
            });
          <?php $employeeProfilePointer->SuccessMsg = null;
          } ?>
          <?php if ($employeeProfilePointer->ErrorMsg) { ?>
            swal({
              title: "Error!",
              text: "<?php echo $employeeProfilePointer->ErrorMsg; ?>",
              type: "error"
            });
          <?php } ?>
        });
        $("#image").change(function() {
          var fileExtension = ['jpeg', 'jpg', 'png'];
          if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
            swal({
              title: "Warning!",
              text: "Image should be jpeg, jpg or png format only",
              type: "warning"
            }, function() {
              window.location = "<?php echo base() ?>userprofile";
            });
          }
        });
        $(document).ready(function() {
          $('form[id="edit_details"]').validate({
            rules: {
              first_name: {
                required: true,
                minlength: 3
              },
              last_name: {
                required: true,
                minlength: 3
              },
              mobile: {
                required: true
              },
              gender: {
                required: true
              },
              country_id: {
                required: true
              },
              city_id: {
                required: true
              }
            },
            messages: {
              first_name: {
                required: "Please enter first name.",
                minlength: "Please enter at least 3 characters"
              },
              last_name: {
                required: "Please enter last name.",
                minlength: "Please enter at least 3 characters"
              },
              mobile: {
                required: "Please enter mobile number."
              },
              gender: {
                required: "Please select gender."
              },
              country_id: {
                required: "Please select country."
              },
              city_id: {
                required: "Please select city."
              }

            },
            //onsubmit: false,
            submitHandler: function(form) {
              form.submit();
            }

          });
        });
        $(document).ready(function() {
          $('form[id="changepassword"]').validate({
            rules: {
              password: {
                required: true

              },
              new_pass: {
                required: true,
                minlength: 7,
                maxlength: 15
              },
              new_pass2: {
                equalTo: "#new_pass",
                minlength: 7
              }
            },
            messages: {
              password: {
                required: "Old Password is required."
              },
              new_pass: {
                required: "Please enter new password.",
                minlength: "Please enter at least min 7 characters",
                maxnlength: "Please enter at least max 15 characters"
              },
              new_pass2: {
                equalTo: "Password & Confirm Password does not match",
                minlength: "Please enter at least 7 characters"
              }
            },
            //onsubmit: false,
            submitHandler: function(form) {
              form.submit();
            }
          });
        });
        $(document).ready(function() {
          $('form[id="Secret"]').validate({
            rules: {
              security_id: {
                required: true
              },
              security_answer: {
                required: true
              }
            },
            messages: {
              security_id: {
                required: ""
              },
              security_answer: {
                required: "Please enter your secret Answer"
              },
            },
            //onsubmit: false,
            submitHandler: function(form) {
              form.submit();
            },
            invalidHandler: function(submit, security_id) {
              document.getElementById('question_error_text').innerHTML = "Please choose any one.";
            }
          });
        });
      </script>
      </body>

      </html>