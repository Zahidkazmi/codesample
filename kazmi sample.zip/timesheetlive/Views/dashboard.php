<?php include_once("header.php");
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->

          <?php
          $designation = $_SESSION['designation'];
                    
           if ($designation=='Admin' || $designation=='admin' || $designation=='ADMIN') 
           {
            include_once($conf->absolute_path."Controller/SubAdminDashboardController.php");
            $DashboardPointer = new SubAdminDashboardController();
            include_once("adminsidebar.php"); 
           }
           else {
            include_once("sidebar.php");
           }
          ?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Dashboard</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0);"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
          
            <div class="row">
              <?php if ($designation=='Admin' || $designation=='admin' || $designation=='ADMIN') 
              {?>
                  <div class="col-sm-6 col-xl-3 col-lg-6">
                  <a href="<?php echo base()?>manageclient">
                    <div class="card o-hidden">
                      <div class="bg-primary b-r-4 card-body">
                        <div class="media static-top-widget">
                          <div class="align-self-center text-center"><i data-feather="thumbs-up"></i></div>
                          <div class="media-body"><span class="m-0">Total Clients</span>
                            <h4 class="mb-0 counter"><?php echo $DashboardPointer->getCountOfClients();?></h4><i class="icon-bg" data-feather="thumbs-up"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a>
                  </div>
                  <div class="col-sm-6 col-xl-3 col-lg-6">
                  <a href="<?php echo base()?>manageProject">
                    <div class="card o-hidden">
                      <div class="bg-primary b-r-4 card-body">
                        <div class="media static-top-widget">
                          <div class="align-self-center text-center"><i data-feather="database"></i></div>
                          <div class="media-body"><span class="m-0">Total Projects</span>
                            <h4 class="mb-0 counter"><?php echo $DashboardPointer->getCountOfProjects();?></h4><i class="icon-bg" data-feather="database"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a>
                  </div>
                  <div class="col-sm-6 col-xl-3 col-lg-6">
                  <a href="<?php echo base()?>manageemployees">
                    <div class="card o-hidden">
                      <div class="bg-secondary b-r-4 card-body">
                        <div class="media static-top-widget">
                          <div class="align-self-center text-center"><i data-feather="users"></i></div>
                          <div class="media-body"><span class="m-0">Total Employees</span>
                            <h4 class="mb-0 counter"><?php echo $DashboardPointer->getCountOfUsers();?></h4><i class="icon-bg" data-feather="users"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                    </a>
                  </div>
                  <div class="col-sm-6 col-xl-3 col-lg-6">
                    <a href="<?php echo base()?>manageteam">
                      <div class="card o-hidden">
                        <div class="bg-warning b-r-4 card-body">
                          <div class="media static-top-widget">
                            <div class="align-self-center text-center"><i data-feather="user-check"></i></div>
                            <div class="media-body"><span class="m-0">Total Teams</span>
                              <h4 class="mb-0 counter"><?php echo $DashboardPointer->getCountOfTeams();?></h4><i class="icon-bg" data-feather="user-check"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                </div>

                <div class="col-xl-10 xl-50 box-col-12">
                <div class="card">
                  <div class="card-header card-no-border">
                    <h5>Projects Tasks Statuses</h5>
                  </div>
                  <div class="card-body pt-0 card-scroll" >
                    <div class="our-product">
                      <div class="table-responsive">
                        <table class="table table-bordernone">
                          <thead>
                            <th>Project</th>
                            <th>Pending</th>
                            <th>InProgress</th>
                            <th>On Hold</th>
                            <th>Lead Approval</th>
                            <th>Completed</th>
                          </thead>
                          <tbody class="f-w-500">
                            <?php 
                            $Projects = NULL;
                            $Projects = $DashboardPointer->getProject();
                            if($Projects){foreach($Projects as $arr){?>
                            <tr>
                              <td>
                                <a href="<?php echo base()?>manageProjectTasks/<?php echo $arr['project_id'];?>">
                                  <div class="media">
                                    <div class="media-body"><span><?php echo $arr['project_name']?></span>
                                      <p class="font-roboto"><?php echo $arr['project_code']?></p>
                                    </div>
                                  </div>
                                </a>
                              </td>
                              <td class="text-center">
                                <span class="badge rounded-pill badge-primary"><?php echo $DashboardPointer->getProjectTasksStats($arr['project_id'],"Pending");?></span>
                              </td>
                              <td class="text-center">
                              <span class="badge rounded-pill badge-warning"><?php echo $DashboardPointer->getProjectTasksStats($arr['project_id'],"Inprogress");?></span>
                              </td>
                              <td class="text-center">
                              <span class="badge rounded-pill badge-danger"><?php echo $DashboardPointer->getProjectTasksStats($arr['project_id'],"On Hold");?></span>
                              </td>
                              <td class="text-center">
                              <span class="badge rounded-pill badge-info"><?php echo $DashboardPointer->getProjectTasksStats($arr['project_id'],"Lead Approval");?></span>
                              </td>
                              <td class="text-center">
                              <span class="badge rounded-pill badge-success"><?php echo $DashboardPointer->getProjectTasksStats($arr['project_id'],"Completed");?></span>
                              </td>
                            </tr>
                            <?php }}?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php }else{?>
                <div class="col-sm-6 col-xl-3 col-lg-6">
                  <div class="card o-hidden">
                    <div class="bg-primary b-r-4 card-body">
                      <div class="media static-top-widget">
                        <div class="align-self-center text-center"><i data-feather="database"></i></div>
                        <div class="media-body"><span class="m-0">Allocated tasks</span>
                          <h4 class="mb-0 counter"><?php echo $EmployeePointer->getCountOfAllocatedTasks();?></h4><i class="icon-bg" data-feather="database"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-xl-3 col-lg-6">
                  <div class="card o-hidden">
                    <div class="bg-secondary b-r-4 card-body">
                      <div class="media static-top-widget">
                        <div class="align-self-center text-center"><i data-feather="activity"></i></div>
                        <div class="media-body"><span class="m-0">Inprogress Tasks</span>
                          <h4 class="mb-0 counter"><?php echo $EmployeePointer->getCountOfMemberProgressTasks('Inprogress');?></h4><i class="icon-bg" data-feather="activity"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-xl-3 col-lg-6">
                  <div class="card o-hidden">
                    <div class="bg-warning b-r-4 card-body">
                      <div class="media static-top-widget">
                        <div class="align-self-center text-center"><i data-feather="watch"></i></div>
                        <div class="media-body"><span class="m-0">Pending Tasks</span>
                          <h4 class="mb-0 counter"><?php echo $EmployeePointer->getCountOfMemberProgressTasks('Pending');?></h4><i class="icon-bg" data-feather="watch"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 col-xl-3 col-lg-6">
                  <div class="card o-hidden">
                    <div class="bg-primary b-r-4 card-body">
                      <div class="media static-top-widget">
                        <div class="align-self-center text-center"><i data-feather="thumbs-up"></i></div>
                        <div class="media-body"><span class="m-0">Completed Tasks</span>
                          <h4 class="mb-0 counter"><?php echo $EmployeePointer->getCountOfMemberProgressTasks('Completed');?></h4><i class="icon-bg" data-feather="thumbs-up"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              <?php }?>
            </div>

          <!-- Container-fluid Ends-->
        </div>
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
  </body>
</html>