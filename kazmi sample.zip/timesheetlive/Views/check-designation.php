<?php
// include_once("../config.php");
// $conf= new config();
include_once($conf->absolute_path . "Controller/SubAdminEmployeeController.php");
$DesignationPointer = new SubAdminEmployeeController();
$where = $data = null; 


if((isset($_POST['designation']) && $_POST['designation'] !=''))
{
    $where = "designation ='".$_POST['designation']."'";
}

$query="SELECT designation_id  ,designation FROM tbldesignation
WHERE
    ".$where." AND organization_id = '".$_SESSION['organization_id']."'
ORDER BY
designation";
    //echo $query;
if(($data = $DesignationPointer->CustomQuery($query))!=null)
{ 
    echo 'false';
}else{
    echo 'true';
}
?>