<?php
//session_start();
//$session_id = session_id();
//include_once("../config.php");
//$conf = new config();
include_once($conf->absolute_path . "Controller/SubAdminProjectController.php");
$projectPointer = new SubAdminProjectController();
$where = $data = null; 


if((isset($_POST['organization_id']) && $_POST['organization_id'] !=''))
{
    $where = "organization_id ='".$_POST['organization_id']."' AND team_status ='1'";
}
$query="SELECT team_id,team_name FROM tblteam
WHERE
    ".$where."
ORDER BY
    team_name";
if(($rs_users = $projectPointer->CustomQuery($query))!=null)
{ ?>
    <option value="">Select Team *</option>
<?php
    foreach ($rs_users as $arr){
        ?>
        <option value="<?php echo $arr['team_id'];?>"><?php echo $arr['team_name'];?></option>
        <?php
        
    }
}
?>