<?php
session_start();
include_once('../config.php');
$conf = new config();
include_once($conf->absolute_path."Controller/SubAdminDesignationController.php");
$DesignationPointer = new SubAdminDesignationController();
if(($DesignationPointer->AddDesignation())!=NULL)
{
    echo '1';
}
echo '';
?>