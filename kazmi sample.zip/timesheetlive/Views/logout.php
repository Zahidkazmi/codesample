<?php 
unset($_SESSION['user_id']);
unset($_SESSION['email']);
unset($_SESSION['username']);
unset($_SESSION['user_image']);
unset($_SESSION['gender']);
unset($_SESSION['FullName']);
unset($_SESSION['organization_id ']);
unset($_SESSION['employment_status']);
unset($_SESSION['designation']);
session_destroy();
header("Refresh: 1; URL=".base()."login");
?>