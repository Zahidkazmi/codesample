 <!-- latest jquery-->
 <script src="<?php echo $conf->site_url;?>assets/js/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap js-->
    <script src="<?php echo $conf->site_url;?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
    <!-- feather icon js-->
    <?php //if($accessFile!='managephase'){?>
    <script src="<?php echo $conf->site_url;?>assets/js/icons/feather-icon/feather.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/icons/feather-icon/feather-icon.js"></script>
    <?php //}?>
    
    <!-- scrollbar js-->
    <script src="<?php echo $conf->site_url;?>assets/js/scrollbar/simplebar.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/scrollbar/custom.js"></script>
    <!-- Sidebar jquery-->
    <script src="<?php echo $conf->site_url;?>assets/js/config.js"></script>
    <!-- Plugins JS start-->
    <script src="<?php echo $conf->site_url;?>assets/js/sidebar-menu.js"></script>
    <?php if($accessFile=='manageemployees' || $accessFile=='managedesignation' || $accessFile=='manageteam' || $accessFile=='manageclient' || $accessFile=='managephase' || $accessFile=='manageprojectmodule' || $accessFile=='manageProjectTasks' || $accessFile=='activityreport' || $accessFile=='employereport' || $accessFile=='teamtasksheet' || $accessFile=='progressreport'){?>
    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatables/jquery.dataTables.min.js"></script>

    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatable-extension/dataTables.buttons.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatable-extension/buttons.html5.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatable-extension/buttons.print.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatable-extension/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatable-extension/jszip.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatable-extension/pdfmake.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatable-extension/vfs_fonts.js"></script>

    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatables/datatable.custom.js"></script>
    <?php }?>
    <?php if($accessFile=='tasksheet' || $accessFile=='projectlist' || $accessFile=='manageProject' || $accessFile=='manageProjectTeams'){?>
    <script src="<?php echo $conf->site_url;?>assets/js/datatable/datatables/jquery.dataTables.min.js"></script>
    <?php }?>
    <?php if($accessFile=='dashboard'){?>
    <script src="<?php echo $conf->site_url;?>assets/js/notify/bootstrap-notify.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/dashboard/default.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/notify/index.js"></script>
    <?php }?>

    <script src="<?php echo $conf->site_url;?>assets/js/bootbox/bootbox.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/sweetalert/sweetalert.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/tooltip-init.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/validate/jquery.validate.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datepicker/daterange-picker/moment.min.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datepicker/daterange-picker/daterangepicker.js"></script>
    <!-- Plugins JS Ends-->
    <!-- Theme js-->
    <script src="<?php echo $conf->site_url;?>assets/js/script.js"></script>
   <!-- <script src="assets/js/theme-customizer/customizer.js"></script>
     login js-->
    <!-- Plugin used-->