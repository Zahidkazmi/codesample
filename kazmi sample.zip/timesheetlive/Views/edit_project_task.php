<?php 
session_start();
include_once("../config.php");
$conf = new config();
include_once($conf->absolute_path."Controller/EmployeeController.php");
$TaskPointer = new EmployeeController();
if(isset($Route[1]) && $Route[1] !='')
{
    $_GET['task_id'] = $Route[1];
    $_GET['project_id'] = $Route[2];
    $_GET['id'] = $Route[2];
}

    if (isset($_POST['updatetask'])) {
    
        $done = $update = 0;
        
        if($TaskPointer->updateSelectedTask())
        {
            $update = 1;
            unset($_POST['module_id'],$_POST['phase_id'],$_POST['resource_id'],$_POST['estimated_hours'],$_POST['task_description'],$_POST['createTask'],$_POST['due_date']);
        }

    }

if(($data = $TaskPointer->getSelectedTask())!=null)
{
    $done = 1;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/fontawesome.css">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/icofont.css">

<!-- date time picker -->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/date-picker.css">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/themify.css">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/flag-icon.css">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/feather-icon.css">
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/style.css">
<link id="color" rel="stylesheet" href="<?php echo $conf->site_url;?>assets/css/color-1.css" media="screen">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/responsive.css">
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/bootstrap.css">
</head>
<?php if($update && $TaskPointer->SuccessMsg){?>
    <div class="alert alert-success dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-up"></i>
        <p> <?php echo $TaskPointer->SuccessMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<?php if($TaskPointer->ErrorMsg !=''){?>
    <div class="alert alert-danger dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-down"></i>
        <p> <?php echo $TaskPointer->ErrorMsg;?></p>
        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php }?>
<div class="modal-body">
                <form method="POST" id="projecttask" action="<?php echo base()?>edit_project_task/<?php echo $Route[1]?>/<?php echo $Route[2]?>">
                    <div class="row"> 

                        <div class="col-sm-12 mt-2">
                                <div class="form-group">
                                    <label class="w-100 d-flex justify-content-start" >Task Title</label>
                                    <input type="text" name="task_title" value="<?php echo $data[0]['task_title'];?>" class="form-control" id="task_title" required>
                                </div>
                        </div>

                        <div class="col-sm-6">
                             <div class="form-group">
                                    <label class="w-100 d-flex justify-content-start" >Modules</label>
                                    <select name="module_id" id="module_id" class="form-control" required>
                                        <option value="">Select Module</option>
                                        <?php 
                                        $Modules = $TaskPointer->getModule(); 
                                        foreach($Modules as $module){?>
                                            <option <?php if($data[0]['module_id'] == $module['module_id']){ echo "selected"; }?> value="<?php echo $module['module_id']?>"><?php echo $module['module_name']?></option>
                                        <?php }?>
                                    </select>
                                </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                                    <label class="w-100 d-flex justify-content-start" >Phase</label>
                                    <select name="phase_id" id="phase_id" class="form-control" required>
                                        <option value="">Select Phase</option>
                                        <?php
                                        $Phases = $TaskPointer->getPhase(); 
                                            foreach($Phases as $phase){?>
                                            <option <?php if($data[0]['phase_id'] == $phase['phase_id']){ echo "selected"; }?> value="<?php echo $phase['phase_id']?>"><?php echo $phase['phase_type']?></option>
                                        <?php }?>
                                    </select>
                                </div>
                        </div>

                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Resource</label>
                                <select name="resource_id" id="resource_id" class="form-control" required>
                                    <option value="">Select Resource</option>
                                    <?php 
                                    $Users = $TaskPointer->getProjectResource(); 
                                    foreach($Users as $user){?>
                                        <option <?php if($data[0]['resource_id'] == $user['user_id']){ echo "selected"; }?> value="<?php echo $user['user_id']?>"><?php echo $user['first_name']." ".$user['last_name']?></option>
                                    <?php }?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Estimated Hours</label>
                                <input type="number" min="1" name="estimated_hours" value="<?php echo $data[0]['estimated_hours'];?>" class="form-control" id="estimated_hours" required>
                            </div>
                        </div>

                        <div class="col-sm-12 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Due Date</label>
                                <input class="form-control" type="date" name="due_date" id="due_date" value="<?php echo $data[0]['due_date'];?>" required>
                            </div>
                        </div>

                        <div class="col-sm-12 mt-3">
                            <div class="from-group">
                                <label class="w-100 d-flex justify-content-start" >Task Description</label>
                                <textarea name="task_description" id="task_description" class="form-control" placeholder="Task Description"><?php echo $data[0]['task_description'];?></textarea>
                            </div>
                            <div class="from-group mt-3 justify-content-right">
                            <button type="button" <?php if($update){?>onClick="window.parent.closeModal('#editModal',1)"<?php }else{?>onClick="window.parent.closeModal('#editModal',0)"<?php }?> class="btn btn-warning">Close</button>
                            <button type="submit" name="updatetask" id="updatetask" value="UpdateTask" class="btn btn-primary">Update Task</button>
                            </div>                        
                        </div>
                    </div>
                </form>
            </div>
<script src="<?php echo $conf->site_url;?>assets/js/jquery-3.5.1.min.js"></script>
<!-- Bootstrap js-->
<script src="<?php echo $conf->site_url;?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
<!-- date time picker js -->
<script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.js"></script>
<script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.en.js"></script>

<!-- js form validator -->
<script src="<?php echo $conf->site_url;?>assets/js/validate/jquery.validate.min.js"></script>
<script>
$(document).ready(function(){

$('form[id="projecttask"]').validate({
        rules: {
            task_title: {
              required: true,
              minlength: 3
            },
            module_id: {
              required: true
            },
            phase_id: {
              required: true
            },
            resource_id:{
               required: true
            },
            estimated_hours:{
              required: true
            },
            due_date:{
              required: true
            },
            task_description: {
              required: true
            }
        },
        messages: {
            task_title: {
              required: "Please enter task title.",
              minlength: "Please enter at least 3 charachters"
            },
            module_id: {
              required: "Please Select Module."
            },
            phase_id: {
              required: "Please select phase."
            },
            resource_id: {
              required: "Please select resource."
            },
            estimated_hours: {
              required: "Please enter estimated hours."
            },
            due_date: {
              required: "Please choose due date."
            },
            task_description: {
              required: "Please enter task description."
            }
        },
        //onsubmit: false,
        submitHandler: function(form) {
          form.submit();
        }
        
});

});

// $(function(){
//     var dtToday = new Date();
//     var month = dtToday.getMonth() + 1;
//     var day = dtToday.getDate();
//     var year = dtToday.getFullYear();
//     if(month < 10)
//         month = '0' + month.toString();
//     if(day < 10)
//         day = '0' + day.toString();
//     var maxDate = year + '-' + month + '-' + day;
//     //alert(maxDate);
//     $('#due_date').attr('min', maxDate);
// });
</script>
</html>