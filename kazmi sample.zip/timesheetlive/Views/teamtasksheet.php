<?php include_once("header.php");
//insert funtion
if(isset($_POST)){
    $EmployeePointer->CreateProjectTask();
    unset($_POST['module_id'],$_POST['phase_id'],$_POST['resource_id'],$_POST['estimated_hours'],$_POST['due_date'],$_POST['task_description']);
}

$data = $EmployeePointer->getAllProjectTasksList();
 
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Project <?php //echo $EmployeePointer->getSelectedProjectName();?> Tasks</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>dashboard"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Project</li>
                    <li class="breadcrumb-item active">Task list</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                  
                        <div class="col-md-6">
                            <div class="text-end">
                                <div class="form-group mb-0 me-0">

                                </div>
                                <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-original-title="" title=""> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="12" y1="8" x2="12" y2="16"></line>
                                <line x1="8" y1="12" x2="16" y2="12"></line></svg>Create New Task</a>                    
                            </div>
                        </div>
                  
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>Project</th>
                                    <th>Task Title</th>
                                    <th>Phase</th>
                                    <th>Module</th>
                                    <th>Task</th>
                                    <th>Estimated Hours</th>
                                    <th>Hours Spent</th>
                                    <th>Resource Name</th>
                                    <th>Created Date</th>
                                    <th>Due Date</th>
                                    
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php 
                                    foreach($data as $row){ $_GET['id'] = $row['project_id'];
                                        if($Rights = $EmployeePointer->getUserRightsByProject()){
                                               $done =1;
                                            }else{
                                              $done=0;  
                                            }
                                            

                                        $x = $EmployeePointer->getTaskActivityDetail($data[0]['task_id']);
                                        if($row['task_status']=="Completed"){ $class= "bg-success";}
                                        else if($row['task_status']=="Pending"){ $class= "bg-primary";}
                                        else if($row['task_status']=="Inprogress"){ $class= "bg-warning";}
                                        else if($row['task_status']=="On Hold"){ $class= "bg-danger";}
                                        else{
                                            $class="bg-info";
                                        }
                                ?>
                                    <tr>
                                        <td><?php echo $row['project_name']?></td>
                                        <td><?php echo $row['task_title']?></td>
                                        <td><?php echo $row['phase_type']?></td>
                                        <td><?php echo $row['module_name']?></td>
                                        <td><?php echo $row['task_description']?></td>
                                        <td><?php echo $row['estimated_hours']?></td>
                                        <td><?php echo $EmployeePointer->getTotalSpendHours($row['task_id']);?></td>
                                        <td><?php echo $row['first_name']." ".$row['last_name']?></td>
                                        <td><?php echo $row['created_at']?></td>
                                        <td><?php echo $row['due_date']?></td>
                                        
                                        <td><?php $x = $EmployeePointer->getTaskActivityDetail($row['task_id']); echo $x[0]['start_date']?></td>
                                        <td><?php $x = $EmployeePointer->getTaskActivityDetail($row['task_id']); echo $x[0]['end_Date']?></td>
                                        <td class="<?php echo $class;?>"><?php echo $row['task_status']?></td>

                                        <td>
                                        <?php if($Rights[0]['edit_record'] == 1 && $done ){?> <a href="javascript:void(0);" onClick="openModal('<?php echo base()?>edit_project_task/<?php echo $row['task_id']?>/<?php echo $row['project_id']?>','#editModal','ifEdit')" title="Edit"><i class="fa fa-wrench"></i></a> | <?php }?>
                                        <a href="javascript:void(0);" onClick="openModal('<?php echo base()?>view_task_progress/<?php echo $row['project_id']?>/<?php echo $row['task_id']?>','#viewModal','ifView')" title="View"><i class="fa fa-eye"></i></a> 
                                        <?php if($Rights[0]['approve_record'] == 1 && $done ){?><?php if($row['task_status'] == 'Lead Approval' && $done ){?>| <a href="javascript:void(0);" class="approve" id="<?php echo $row['task_id']?>" title="Approve"><i class="fa fa-check"></i>  </a><?php }?> <?php }?>
                                        </td>
                                    </tr>
                                <?php }//end foreach.
                                ?>
                                </tbody>
                            </table>
                            </div>
                         
                            <!-- <div class="text-center mt-5 mb-5">
                                    <nav>
                                        <ul class="pagination justify-content-center pagination-primary">
                                            <?php //echo($EmployeePointer->getPageMenu($total_pages, $current_page, $thispage, $params));?>
                                        </ul>
                                    </nav>
                            </div> -->
                          
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>
    <!-- JS Start -->
    <?php include_once("js.php");?>
        <!-- JS End  -->
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
<script> 
//start static modal jquery
$(document).ready(function () {
    $('#add-modal-data').modal({
           backdrop: 'static',
           keyboard: false
    })
   });
   $(document).ready(function () {
    $('#editModal').modal({
           backdrop: 'static',
           keyboard: false
    })
   });
   $(document).ready(function () {
    $('#viewModal').modal({
           backdrop: 'static',
           keyboard: false
    })
   });
   //end static modal jquery
function openModal(frameSrc,modalID,SrcID)
{ 
    document.getElementById(SrcID).src = frameSrc;
    $(modalID).modal('show');
}

function closeModal(modalID,pgref)
{
    $(modalID).modal('hide');
    if(pgref == 1){
    if(window.top==window) {
        // you're not in a frame so you reload the site
        //window.setTimeout('location.reload()', 1000); //reloads after 3 seconds
        window.location="<?php echo base()?>teamtasksheet/<?php echo $Route[1];?>";
    }
    }
} 

$('a.approve').click(function() {
    var id = $(this).attr('id');
    var formData = {
        'task_id': id,
        'task_status': "Completed"
    }
    bootbox.confirm({
        message: "<p class='text-semibold text-main'>Approve Task Status</p><p>Are you sure you want to approve?</p>",
        buttons: {
            confirm: {
                label: "Yes"
            }
        },
        callback: function(result) {
            //Callback function here
            if (result) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base()?>update_task_status",
                    data: formData,
                    cache: false,
                    success: function(response) {
                        
                        //var cartsummary = JSON.parse(JSON.stringify(response));
                          
                            swal({
                                title: "Success!",
                                text: "Task approved successfully",
                                type: "success"
                                }, function() {
                                window.location = "<?php echo base()?>teamtasksheet/<?php echo $Route[1];?>";
                            });
                            
                        
                        setTimeout(function() {
                            bootbox.hideAll();
                        }, 2000);
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        setTimeout(function() {
                            bootbox.hideAll();
                        }, 2000);
                        swal({
                                title: "Error!",
                                text: textStatus + '! ' + errorThrown,
                                type: "error"
                                });
                    }
                });
            }

        }
    });
});
</script>  


<!--model start-->
<!--model start-->
<div class="modal fade bd-example-modal-lg" id="add-modal-data" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Create New Task</h4>
            </div>
            <div class="modal-body">
                <form method="POST" id="teamtasksheet" action="<?php echo base()?>teamtasksheet/<?php echo $Route[1]?>">
                    <div class="row">                             
                        <div class="col-sm-6">
                             <div class="form-group">
                                    <label class="w-100 d-flex justify-content-start" >Modules</label>
                                    <select name="module_id" id="module_id" class="form-control" required>
                                        <option value="">Select Module</option>
                                        <?php 
                                        $Modules = $EmployeePointer->getModule(); 
                                        foreach($Modules as $module){?>
                                            <option value="<?php echo $module['module_id']?>"><?php echo $module['module_name']?></option>
                                        <?php }?>
                                    </select>
                                </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group">
                                    <label class="w-100 d-flex justify-content-start" >Phase</label>
                                    <select name="phase_id" id="phase_id" class="form-control" required>
                                        <option value="">Select Phase</option>
                                        <?php
                                        $Phases = $EmployeePointer->getPhase(); 
                                            foreach($Phases as $phase){?>
                                            <option value="<?php echo $phase['phase_id']?>"><?php echo $phase['phase_type']?></option>
                                        <?php }?>
                                    </select>
                                </div>
                        </div>

                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Resource</label>
                                <select name="resource_id" id="resource_id" class="form-control" required>
                                    <option value="">Select Resource</option>
                                    <?php 
                                    $Users = $EmployeePointer->getProjectResource(); 
                                    foreach($Users as $user){?>
                                        <option value="<?php echo $user['user_id']?>"><?php echo $user['first_name']." ".$user['last_name']?></option>
                                    <?php }?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Estimated Hours</label>
                                <input type="number" min="1" name="estimated_hours" class="form-control" id="estimated_hours" required>
                            </div>
                        </div>

                        <div class="col-sm-12 mt-2">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Due Date</label>
                                <input class="datepicker-here form-control" type="text" name="due_date" id="due_date" data-language="en" required>
                            </div>
                        </div>


                        <div class="col-sm-12 mt-3">
                            <div class="from-group">
                                <label class="w-100 d-flex justify-content-start" >Task Description</label>
                                <textarea name="task_description" id="task_description" class="form-control" placeholder="Task Description" required></textarea>
                            </div>
                            <div class="from-group mt-3 justify-content-right">
                                <button type="button" data-bs-dismiss="modal" class="btn btn-warning">Close</button>
                                <button type="submit" name="createTask" id="createTask" value="CreateTask" class="btn btn-primary">Create Task</button>
                            </div>                        
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-lg" id="editModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">Edit Task</h5>
            </div>
            <iframe id="ifEdit" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>

<!--view team model start-->
<div class="modal fade-up bd-example-modal-lg" id="viewModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">View Task Progress</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <iframe id="ifView" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--view team modal-->
<!--model end-->

<!-- date time picker js -->
<script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.js"></script>
<script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.en.js"></script>

<script>
$(document).ready(function(){

$('form[id="teamtasksheet"]').validate({
        rules: {
            module_id: {
              required: true,
            },
            phase_id: {
              required: true,
            },
            resource_id:{
               required: true
            },
            estimated_hours:{
              required: true
            },
            due_date:{
              required: true
            },
            task_description: {
              required: true
            }
        },
        messages: {
            module_id: {
              required: "Please Select Module."
            },
            phase_id: {
              required: "Please select phase."
            },
            resource_id: {
              required: "Please select resource."
            },
            estimated_hours: {
              required: "Please enter estimated hours."
            },
            due_date: {
              required: "Please choose due date."
            },
            task_description: {
              required: "Please enter task description."
            }
        },
        //onsubmit: false,
        submitHandler: function(form) {
          form.submit();
        }
        
});

})
</script>

</body>
</html>