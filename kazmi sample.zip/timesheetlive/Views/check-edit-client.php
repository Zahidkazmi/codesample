<?php
// include_once("../config.php");
// $conf= new config();
include_once($conf->absolute_path . "Controller/SubAdminEmployeeController.php");
$ClientPointer = new SubAdminEmployeeController();
$where = $data = null; 


if((isset($_POST['client_name']) && $_POST['client_name'] !=''))
{
    $where = "client_name ='".$_POST['client_name']."'";
}
if((isset($_POST['client_email']) && $_POST['client_email'] !=''))
{
    $where = "client_email ='".$_POST['client_email']."'";
}
$query="SELECT client_id ,client_name FROM tblclients
WHERE
    ".$where." AND client_id != '".$Route[1]."' AND organization_id = '".$_SESSION['organization_id']."'
ORDER BY
 client_name";
    //echo $query;
if(($data = $ClientPointer->CustomQuery($query))!=null)
{ 
    echo 'false';
}else{
    echo 'true';
}
?>