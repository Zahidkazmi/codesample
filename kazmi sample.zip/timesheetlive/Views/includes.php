<?php
 	//session_start();
	include_once($conf->absolute_path."Controller/LoginController.php");
	include_once($conf->absolute_path."Controller/encryption.php");
	
		include_once($conf->absolute_path."Controller/EmployeeController.php");
		$EmployeePointer = new EmployeeController();
	 
	
	$EncryptionPointer = new rc4crypt();
	$LoginPointer=new LoginController();
	if(($LoginPointer->is_logged_in())== null){
		$redirect = base()."login";
		echo"<meta http-equiv='refresh' content='0; URL=".$redirect."'>"; 
		//echo "<meta http-equiv='refresh' content='0; URL=".$redirect."'>"; 
	}
?>	