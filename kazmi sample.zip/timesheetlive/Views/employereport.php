<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/EmployeeController.php");
    $EmployeeReportPointer = new EmployeeController();
    $data = $EmployeeReportPointer->getEmployeReport();
    
    
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Activity List </h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Reports</li>
                    <li class="breadcrumb-item active">Activity Reports</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="example">
                                <thead>
                                <tr>
                                    <th>Employee Name</th>
                                    <th>Project</th>
                                    <th>Module</th>
                                    <th>Task</th>
                                    <th>Phase</th>
                                    <th>Estimated Time</th>
                                    <th>Created Date</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Spend Time</th>
                                    <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                  <?php foreach($data as $row)
                                  {
                                    $x = $EmployeeReportPointer->getTaskActivityDetail($data[0]['task_id']);

                                    if($row['task_status']=="Completed"){ $class= "bg-success";}
                                    else if($row['task_status']=="Pending"){ $class= "bg-primary";}
                                    else if($row['task_status']=="Inprogress"){ $class= "bg-warning";}
                                    else if($row['task_status']=="On Hold"){ $class= "bg-danger";}
                                    else if($row['task_status']=="Lead Approval"){ $class= "bg-info";}
                                    else{
                                        $class="bg-info";
                                    }   
                                ?>
                                    <tr>
                                        <td><?php echo $row['first_name']." ".$row['last_name']?></td>
                                        <td><?php echo $row['project_name'];?></td>
                                        <td><?php echo $row['module_name'];?></td>
                                        <td><?php echo $row['task_description'];?></td>
                                        <td><?php echo $row['phase_type'];?></td>
                                        <td><?php echo $row['estimated_hours'];?></td>
                                        <td><?php echo $row['created_at'];?></td>
                                        <td><?php $x = $EmployeeReportPointer->getTaskActivityDetail($row['task_id']); echo $x[0]['start_date']?></td>
                                        <td><?php $x = $EmployeeReportPointer->getTaskActivityDetail($row['task_id']); echo $x[0]['end_Date']?></td>
                                        <td><?php $x = $EmployeeReportPointer->getTaskActivityDetail($row['task_id']); echo $x[0]['hour_spend'] ?></td>
                                        
                                        <td class="<?php echo $class;?>"><?php echo $row['task_status'];?></td>
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            </div>
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>

</body>
</html>