<?php 
include_once("header.php");
include_once($conf->absolute_path."Controller/EmployeeController.php");
$EmployeePointer = new EmployeeController();
$done = 0;
if(($data = $EmployeePointer->getassignedProjects())!=null)
{
  $done = 1;
}
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Projects</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>index"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Projects</li>
                    <li class="breadcrumb-item active">Project List </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
          
          <div class="row project-cards">
              <!-- <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                      <ul class="nav nav-tabs border-tab" id="top-tab" role="tablist">
                        <li class="nav-item"><a class="nav-link active" id="top-home-tab" data-bs-toggle="tab" href="#top-home" role="tab" aria-controls="top-home" aria-selected="true"><i data-feather="target"></i>All</a></li>
                        <li class="nav-item"><a class="nav-link" id="profile-top-tab" data-bs-toggle="tab" href="#top-profile" role="tab" aria-controls="top-profile" aria-selected="false"><i data-feather="info"></i>Doing</a></li>
                        <li class="nav-item"><a class="nav-link" id="contact-top-tab" data-bs-toggle="tab" href="#top-contact" role="tab" aria-controls="top-contact" aria-selected="false"><i data-feather="check-circle"></i>Done</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div> -->
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-body">
                    <div class="tab-content" id="top-tabContent">
                      <div class="tab-pane fade show active" id="top-home" role="tabpanel" aria-labelledby="top-home-tab">
                        <div class="row">
                        <?php if($done){ 
                          foreach($data as $row){
                        ?>
                          <div class="col-xxl-4 col-lg-6">
                            <a href=" <?php echo base() ?>projectlist/<?php echo $row['project_id']?>" style="color:black;">
                            
                            <div class="project-box"><!-- <span class="badge badge-primary">Doing</span> -->
                              <h6><?php echo $row['project_name']." (".$row['project_code'].")" ?></h6>
                              <div class="media">
                                <div class="media-body">
                                  <p><?php echo $row['client_name'].",". $row['client_address']?></p>
                                </div>
                              </div>
                              <p><?php echo $row['project_description']?></p>
                              <div class="row details">
                                <div class="col-6"><span>Tasks </span></div>
                                <div class="col-6 text-primary"><?php echo $EmployeePointer->getCountOfTasksBYProject($row['project_id']);?> </div>
                                <div class="col-6"> <span>Done</span></div>
                                <div class="col-6 text-primary"><?php echo $EmployeePointer->getCountOfProgressTasks('Completed',$row['project_id']);?></div>
                                <div class="col-6"> <span>Pending</span></div>
                                <div class="col-6 text-primary"><?php echo $EmployeePointer->getCountOfProgressTasks('Pending',$row['project_id']);?></div>
                              </div>
                              <?php if($Team = $EmployeePointer->getProjectTeam($row['team_id'])){?>
                              <div class="customers">
                                <ul>
                                <?php foreach($Team as $arr){?>
                                  <li class="d-inline-block"><img class="img-30 rounded-circle" src="<?php echo $conf->site_url?>assets/images/user/<?php echo $arr['image'];?>" alt="" data-original-title="" title=""></li>
                                <?php }?>  
                                  <!-- <li class="d-inline-block ms-2">
                                    <p class="f-12">+10 More</p>
                                  </li> -->
                                </ul>
                              </div>
                              <?php }?>
                              <!-- <div class="project-status mt-4">
                                <div class="media mb-0">
                                  <p>70% </p>
                                  <div class="media-body text-end"><span>Done</span></div>
                                </div>
                                <div class="progress" style="height: 5px">
                                  <div class="progress-bar-animated bg-primary progress-bar-striped" role="progressbar" style="width: 70%" aria-valuenow="<? echo '20';?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                              </div> -->
                            </div>

                             </a>
                          </div>
                         <?php }//end for.
                        }?> 
                        </div>
                      </div>
                      
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
          <!-- Container-fluid Ends-->
        </div>
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
  </body>
</html>