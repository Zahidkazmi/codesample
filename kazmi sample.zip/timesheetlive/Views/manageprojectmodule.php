<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/SubAdminModuleController.php");
    $ModulePointer = new SubAdminModuleController();
    $update = 0;
    if($ModulePointer->AddModule())
    {
        unset($_POST['project_id'],$_POST['module_name']);
        $update = 1;
    }
    $data = $ModulePointer->getModuleLists();
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("adminsidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Project Module List</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>dashboard"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Project</li>
                    <li class="breadcrumb-item active">Project module</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6">
                        <div class="text-end">
                            <div class="form-group mb-0 me-0">

                            </div>
                            <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-bs-original-title="" title="" href="javascript:void(0)" data-bs-original-title="" title=""> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line></svg>Create New Module</a>

                    
                        </div>
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>Project</th>
                                    <th>Module</th>
                                    <th>Action</th>
                                    
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($data as $row){?>
                                    <tr>
                                        <td><?php echo $row['project_name']." (".$row['project_code'].")";?></td>
                                        <td><?php echo $row['module_name'];?></td>
                                        <td><a href="javascript:void(0);" onClick="openModal('<?php echo base()?>edit_module/<?php echo $row['module_id']?>','#editModal','ifEdit')"> Edit</a></td>
                                       
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            </div>
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
<script> 
   //start static modal jquery
   $(document).ready(function () {
    $('#add-modal-data').modal({
           backdrop: 'static',
           keyboard: false
    })
   });
   $(document).ready(function () {
    $('#editModal').modal({
           backdrop: 'static',
           keyboard: false
    })
   });
   //end static modal jquery
function openModal(frameSrc,modalID,SrcID)
{ 
    document.getElementById(SrcID).src = frameSrc;
    $(modalID).modal('show');
}

function closeModal(modalID,pgref)
{
    $('#editModal').modal('hide');
    if(pgref == 1){
    if(window.top==window) {
        // you're not in a frame so you reload the site
        window.location="<?php echo base()?>manageprojectmodule";
    }
    }
} 



$(document).ready(function(){

<?php if($update && $ModulePointer->SuccessMsg){?>
    swal({
        title: "Success!",
        text: "<?php echo $ModulePointer->SuccessMsg;?>",
        type: "success"
    }, function() {
        window.location = "<?php echo base()?>manageprojectmodule";
    });
<?php }?>
<?php if(!$update && $ModulePointer->ErrorMsg){?>
    swal({
        title: "Error!",
        text: "<?php echo $ModulePointer->ErrorMsg;?>",
        type: "error"
    });
<?php }?>    

});
</script>  


<!--model start-->
<div class="modal fade bd-example-modal-lg" id="add-modal-data" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Add New Module</h4>
                <!-- <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button> -->
            </div>
            <div class="modal-body">
                <form method="POST" id="phases" action = "<?php echo base()?>manageprojectmodule">
                    <div class="row">                             
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" >Project</label>
                                <select name="project_id" id="project_id" class="form-control" required>
                                    <option value="">Select Project *</option>
                                    <?php $Organization = NULL;
                                    $Projects = $ModulePointer->getProjects();
                                    if($Projects){ foreach($Projects as $arr){?>
                                        <option value="<?php echo $arr['project_id']?>"><?php echo $arr['project_name']?></option>
                                    <?php }}?>
                                </select>    
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="w-100 d-flex justify-content-start" > &nbsp;&nbsp;Module Name</label>
                                <input type="text" id="module_name" class="form-control" placeholder="Enter Module Name" name="module_name" required >
                            </div>
                        </div>
                        <div class="col-sm-12 mt-3">
                            <div class="from-group mt-3 justify-content-right">
                                <button type="button" data-bs-dismiss="modal" class="btn btn-warning">Close</button>
                                <button type="submit" name="Create" id="Create" value="Create Module" class="btn btn-primary">Create</button>
                            </div>                        
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade " id="editModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">Edit Project Module</h5>
                <!-- <button type="button" class="btn-close" data-bs-dismiss="modal"></button> -->
            </div>
            <iframe id="ifEdit" frameborder="0" height="280px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--model end-->

<script>
  $(document).ready(function(){
    $('form[id="phases"]').validate({
        rules: {
          
            project_id: {
                      required: true
                    },

                    module_name:{
                        required:true,
                        minlength: 3
                    }
        },
        messages: {
    
            project_id: {
                      required: "Please select project."
                      
                    },

                    module_name:{
                        required: "Please enter module name.",
                        minlength: "Please enter at least 3 characters."
                    }

        },
        //onsubmit: false,
        submitHandler: function(form) {
          form.submit();
        }
        
});

})
</script>
</body>
</html>