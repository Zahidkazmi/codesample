<?php
// include_once("../config.php");
// $conf= new config();
include_once($conf->absolute_path . "Controller/SubAdminEmployeeController.php");
$PhasePointer = new SubAdminEmployeeController();
$where = $data = null; 


if((isset($_POST['phase_type']) && $_POST['phase_type'] !=''))
{
    $where = "phase_type ='".$_POST['phase_type']."'";
}

$query="SELECT phase_id ,phase_type FROM tblphases
WHERE
    ".$where." AND phase_id != '".$Route[1]."' AND organization_id = '".$_SESSION['organization_id']."'
ORDER BY
phase_type";
    //echo $query;
if(($data = $PhasePointer->CustomQuery($query))!=null)
{ 
    echo 'false';
}else{
    echo 'true';
}
?>