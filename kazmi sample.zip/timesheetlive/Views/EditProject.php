<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/SubAdminProjectController.php");
    $ProjectPointer = new SubAdminProjectController();
    $done = 0;
    if(isset($Route[1]) && $Route[1] !='')
    {
        $_GET['project_id'] = $Route[1]; 
    }
    if($ProjectPointer->updateSelectedProject())
    {
      $done = 1;
      unset($_POST['project_code'],$_POST['project_name'],$_POST['client_id'],$_POST['project_description'],$_POST['project_priority'],$_POST['project_size'],$_POST['project_value'],$_POST['project_type'],$_POST['starting_date'],$_POST['ending_date'],$_POST['phase_status']);
    }
    $data = $ProjectPointer->getSelectedProject();
?>
<link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/date-picker.css">
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("adminsidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Update Project</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>index"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Projects</li>
                    <li class="breadcrumb-item"><a href="<?php echo base()?>manageProject">Manage Projects</a></li>
                    <li class="breadcrumb-item active">Update Project</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-body">
                    <div class="form theme-form">
                      <form method="POST" id="projects" action="<?php echo base()?>EditProject/<?php echo $Route[1]."/".$Route[2]?>">
                        <div class="row">
                          <div class="col-sm-6">
                            <div class="mb-3">
                              <label>Client name</label>
                              <select name="client_id" id="client_id" class="form-control" required>
                                <option value="">Select Client</option>
                                <?php $Clients = NULL;
                                  $Clients = $ProjectPointer->getClient();
                                  if($Clients){ foreach($Clients as $arr){?>
                                    <option <?php if($data[0]['client_id'] == $arr['client_id']) { echo "selected";}?> value="<?php echo $arr['client_id']?>"><?php echo $arr['client_name']?></option>
                                <?php }}?>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Code</label>
                              <input class="form-control" type="text" name="project_code" id="project_code" value="<?php echo $data[0]['project_code']?>" readonly required>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Title</label>
                              <input class="form-control" type="text" name="project_name" id="project_name" value="<?php echo $data[0]['project_name']?>" placeholder="Project name *" required>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Phase</label>
                              <select name="phase_status" id="phase_status" class="form-control" required>
                                <option value="">Select Project Phase *</option>
                              <?php $Phase = NULL;
                              $Phase = $ProjectPointer->getPhases();
                              if($Phase){ foreach($Phase as $arr){?>
                                <option <?php if($data[0]['phase_status'] == $arr['phase_type']) { echo "selected";}?> value="<?php echo $arr['phase_type']?>"><?php echo $arr['phase_type']?></option>
                              <?php }}?>
                              </select>
                            </div>
                          </div>
                        </div>
                        
                        <div class="row">
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Rate</label>
                              <input class="form-control" type="number" min="0" name="project_value" id="project_value" value="<?php echo $data[0]['project_value']?>" placeholder="Enter project Rate">
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Type</label>
                              <select class="form-select" name="project_type" id="project_type">
                                <option value="">Select Type</option>
                                <option <?php if($data[0]['project_type'] == "T&M") { echo "selected";}?> value="T&M">T&M</option>
                                <option <?php if($data[0]['project_type'] == "Fixed Cost") { echo "selected";}?> value="Fixed Cost">Fixed Cost</option>
                                <option <?php if($data[0]['project_type'] == "Services") { echo "selected";}?> value="Services">Services</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Priority</label>
                              <select class="form-select" name="project_priority" id="project_priority" required>
                                <option value="">Select Priority</option>
                                <option <?php if($data[0]['project_priority'] == "Low") { echo "selected";}?> value="Low">Low</option>
                                <option <?php if($data[0]['project_priority'] == "Medium") { echo "selected";}?> value="Medium">Medium</option>
                                <option <?php if($data[0]['project_priority'] == "High") { echo "selected";}?> value="High">High</option>
                                <option <?php if($data[0]['project_priority'] == "Urgent") { echo "selected";}?> value="Urgent">Urgent</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Project Size</label>
                              <select class="form-select" name="project_size" id="project_size" required>
                                <option value="">Select Size</option>
                                <option <?php if($data[0]['project_size'] == "Small") { echo "selected";}?> value="Small">Small</option>
                                <option <?php if($data[0]['project_size'] == "Medium") { echo "selected";}?> value="Medium">Medium</option>
                                <option <?php if($data[0]['project_size'] == "Big") { echo "selected";}?> value="Big">Big</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Starting date</label>
                              <input class="datepicker-here form-control" type="text" name="starting_date" id="starting_date" value="<?php echo AppDateFormat($data[0]['starting_date']);?>" data-language="en" required>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="mb-3">
                              <label>Ending date</label>
                              <input class="datepicker-here form-control" type="text" name="ending_date" id="ending_date" value="<?php echo AppDateFormat($data[0]['ending_date']);?>" data-language="en" required>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="mb-3">
                              <label>Enter some Details</label>
                              <textarea class="form-control" id="project_description" name="project_description" rows="3" required><?php echo $data[0]['project_description']?></textarea>
                            </div>
                          </div>
                        </div>
                        <div class="row justify-content-right">
                          <div class="col">
                            <a href="<?php echo base()?>manageProject" class="btn btn-warning">Cancel</a>
                            <button type="submit" name="update" id="update" value="UpdateProject" class="btn btn-primary">Update</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
    <script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.js"></script>
    <script src="<?php echo $conf->site_url;?>assets/js/datepicker/date-picker/datepicker.en.js"></script>
    <script>
    
    function GetAjaxClients(id)
    {
     $(document).ready(function() {
            var formData = {
                'organization_id': id
            };
            $.ajax({
                type: "POST",
                url: "<?php echo base()?>get_ajax_clients",
                data: formData
            }).done(function(clients) {
                $("#client_id").html('');
                $("#client_id").html(clients);
            });
        });
    }

    $(document).ready(function(){
      <?php if($ProjectPointer->SuccessMsg){?>
      swal({
              title: "Success!",
              text: "<?php echo $ProjectPointer->SuccessMsg;?>",
              type: "success"
            }, function() {
                window.location = "<?php echo base()?>manageProject/<?php echo $Route[2]?>";
      });
    
      <?php }?>
      <?php if($ProjectPointer->ErrorMsg){?>
      swal({
              title: "Error!",
              text: "<?php echo $ProjectPointer->ErrorMsg;?>",
              type: "error"
          });
      
      <?php }?>  
    });

    $(document).ready(function(){
    
      jQuery.validator.addMethod("greaterThan", 
        function(value, element, params) {

            if (!/Invalid|NaN/.test(new Date(value))) {
                return new Date(value) > new Date($(params).val());
            }

            return isNaN(value) && isNaN($(params).val()) 
                || (Number(value) > Number($(params).val())); 
        },'Must be greater than Starting Date');

    $('form[id="projects"]').validate({
        rules: {
          client_id: {
              required: true,
            },
            project_code: {
              required: true,
            },
            project_name:{
               required: true
            },
            phase_status:{
              required: true
            },
            project_value:{
              required: true
            },
            project_type: {
              required: true
            },
            project_priority: {
              required: true
            },
            project_size:{
              required: true
            },
            starting_date:{
              required: true
            },
            ending_date:{
              required:true,
              greaterThan: "#starting_date"
            },
            project_description:{
              required:true
            }
        },
        messages: {
          client_id: {
              required: "Please Select client."
            },
            project_code: {
              required: "Please enter project code."
            },
            project_name: {
              required: "Please enter project name."
            },
            phase_status: {
              required: "Please select project phase."
            },
            project_value: {
              required: "Please enter project rate."
            },
            project_type: {
              required: "Please select project type."
            },
            project_priority: {
              required: "Please select project priority."
            },
            project_size:{
              required: "Please select project size."
            },
            starting_date:{
              required: "Please choose starting date."
            },
            ending_date:{
              required: "please choose project ending date."
            },
            project_description:{
              required: "Please enter project description"
            },
        },
        //onsubmit: false,
        submitHandler: function(form) {
          form.submit();
        }
        
});

})

</script>  
  </body>
</html>