<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/SubAdminReportController.php");
    $ProgressReportPointer = new SubAdminReportController();
    if(isset($Route[1]) && $Route[1] == 'explore'){unset($_SESSION['admin_query']);}
    $Employees = $Projects = NULL;
    $Employees = $ProgressReportPointer->getOrganizationEmployees();
    $Projects = $ProgressReportPointer->getOrganizationProjects();
    $data = $ProgressReportPointer->getProgressReport();
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("adminsidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Progress Report </h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>dashboard"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Reports</li>
                    <li class="breadcrumb-item active">Progress Reports</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                <div class="row">
                    <div class="col-md-12" id="AdvSearch">
                        <form role="form" action="<?php echo base()?>progressreport" class="px-4 py-3" name="SearchItem" method="post">
                            <div class="row d-flex align-items-center">
                                <div class="col-md-12 text-left mb-3">
                                    <b>Advanced Search Filters</b>
                                </div>
                                
                                <div class="col-md-3 text-left pr-lg-0 mt-1">
                                    <div class="form-group m-0">
                                        <input class="form-control" type="text" name="daterange" value="">
                                    </div>
                                </div>
                                <div class="col-md-3 text-left mt-1">
                                    <div class="form-group m-0">
                                    <select class="form-control" id="project_id" name="project_id">
                                              <option value="">Select Project</option>
                                              <option value="All">All</option>
                                            <?php if($Projects){ foreach($Projects as $arr){ ?>       
                                              <option value="<?php echo $arr['project_id']; ?>"><?php echo $arr['project_name']; ?></option>
                                          <?php }} ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 text-right">
                                    <button type="submit" name="search_record" value="Search" class="btn btn-primary btn-sm"><i class="fa fa-search pr-2"></i>Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-12 f-right">
                      <a href="#" data-toggle="collapse" id="show_hide" data-target="#AdvSearch" class="btn btn-primary btn-sm mr-2"><i class="fa fa-sliders"></i> Show / Hide Advanced Search</a>
                      <a href="<?php echo base()?>progressreport/explore" class="btn btn-primary btn-sm mr-2"><i class="fa fa-refresh"></i> Reload</a>
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                        <?php if(isset($_POST['daterange']) && $_POST['daterange'] !=''){?>
                            <div class="row">
                                <div class="col-xl-12 text-bold">Date Range: <?php echo $_POST['daterange'];?></div>
                            </div>
                        <?php }?>
                            <table class="display" id="example">
                        
                                <thead>
                                <tr class="text-center">
                                    <th>Employee Name</th>
                                    <th>Task Completed</th>
                                    <th>Task On Hold</th>
                                    <th>Task Pending</th>
                                    <th>Estimated Hours</th>
                                    <th>Spent Hours</th>
                                </tr>
                                </thead>
                                <tbody>
                                  <?php foreach($data as $row){?>
                                    <tr class="text-center">
                                        <td><?php echo $row['employee_name']?></td>
                                        <td><?php $ProgressReportPointer->getProgressTaskStatus($row['user_id'],'Completed');?></td>
                                        <td><?php $ProgressReportPointer->getProgressTaskStatus($row['user_id'],'On Hold');?></td>
                                        <td><?php $ProgressReportPointer->getProgressTaskStatus($row['user_id'],'Pending');?></td>
                                        <td><?php echo $row['estimated_hours'];?></td>
                                        <td><?php $ProgressReportPointer->getProgressHourSpend($row['user_id']); ?></td>
                                        
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
    <script>
      // slide search div.
    $(document).ready(function(){

        $('#basic-1').DataTable({
            "order": [[ 1, "asc" ]],
            "paging": false
        });
        $('input[name="daterange"]').daterangepicker();
        $("#AdvSearch").hide();
        $("#show_hide").show();

        $('#show_hide').click(function(){
            $("#AdvSearch").slideToggle();
        });
    });

    function GetUserProject(id)
    {
     $(document).ready(function() {
            var formData = {
                'user_id': id
            };
            $.ajax({
                type: "POST",
                url: "<?php echo base()?>getuser_ajax_projects",
                data: formData
            }).done(function(projects) {
                $("#project_id").html('');
                $("#project_id").html(projects);
            });
        });
    }
    </script>
</body>
</html>