<style>

.footer{
  position:fixed;
  width:92%;
  left:0;
  bottom:0;
  text-align:center;
}
</style>
<br/><br/>
<footer class="footer">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 footer-copyright text-center">
        <p class="mb-0">Copyright <?php echo date('Y');?> © Viltco Technology </p>
      </div>
    </div>
  </div>
</footer>