<?php
  include_once("config.php");
  $conf = new config();
  include_once($conf->absolute_path."Controller/LoginController.php");
  $LoginPointer = new LoginController();
  $accessFile = basename($_SERVER['REQUEST_URI']);
  if(($LoginPointer->is_logged_in())!= null)
{	
    ob_end_clean();
    $route = base()."dashboard";
      //header("Refresh: 1; URL=".$route);
    echo"<meta http-equiv='refresh' content='0; URL=".$route."'>";
      exit;	
}
$done=0;
if(($url=$LoginPointer->SecurityLogin())!= null)
  {
      $done = 1;
      $route = base().$url."/RP";
      // $route = base().$url.urlencode($EncryptionPointer->encrypt("programerparadise","RP",1));
      //header("Refresh: 1; URL=".$route);
      echo "<meta http-equiv='refresh' content='0; URL=".$route."'>";
      exit;
     // echo"<meta http-equiv='refresh' content='0; URL=".$route."'>";
  }
if(($LoginPointer->verfiy_login_info())!= null)
{  
      $route = base()."dashboard";
      //header("Refresh: 1; URL=".$route);
      echo "<meta http-equiv='refresh' content='0; URL=".$route."'>";  
      exit;
    //header("Refresh: 1; URL=$route");
}  


$security = 0;
if(($Question=$LoginPointer->GetSecurityQuestion())!= null){
    $security=1;
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Timesheet Management.">
    <meta name="keywords" content="timesheet management, web app">
    <meta name="author" content="Viltco Technology">
    <link rel="icon" href="<?php echo $conf->site_url;?>assets/images/favicon.png" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo $conf->site_url;?>assets/images/favicon.png" type="image/x-icon">
    <title>Timesheet Management</title>
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/fontawesome.css">
    <!-- ico-font-->
    <link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/icofont.css">
    <!-- Themify icon-->
    <link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/themify.css">
    <!-- Flag icon-->
    <link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/flag-icon.css">
    <!-- Feather icon-->
    <link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/feather-icon.css">
    <!-- Plugins css start-->
    <!-- Plugins css Ends-->
    <!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/vendors/bootstrap.css">
    <!-- App css-->
    <link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/style.css">
    <link id="color" rel="stylesheet" href="<?php echo $conf->site_url;?>assets/css/color-1.css" media="screen">
    <!-- Responsive css-->
    <link rel="stylesheet" type="text/css" href="<?php echo $conf->site_url;?>assets/css/responsive.css">
  </head>
  <body>
    <!-- login page start-->
    <div class="container-fluid">
      <div class="row">
        <div class="col-xl-7"><img class="bg-img-cover bg-center" src="<?php echo $conf->site_url;?>assets/images/login/2.jpg" alt="looginpage"></div>
        <div class="col-xl-5 p-0">
          <div class="login-card">
            <div>
              <div><a class="logo text-start" href="javascript:void(0);"><img class="img-fluid for-light" src="<?php echo $conf->site_url;?>assets/images/logo/login.png" alt="looginpage"><img class="img-fluid for-dark" src="<?php echo $conf->site_url;?>assets/images/logo/logo_dark.png" alt="looginpage"></a></div>
              <div class="login-main"> 
              <?php if($LoginPointer->ErrorMsg !=''){?>
                  <div class="alert alert-danger dark alert-dismissible fade show" role="alert"><i data-feather="thumbs-down"></i>
                      <p> <?php echo $LoginPointer->ErrorMsg;?></p>
                      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
              <?php }?>
                <form class="theme-form" autocomplete="off" action="<?php echo base()."login";?>" method="post">
                  <h4>Sign in</h4>
                  <p>Enter your (email or username) & password to login</p>
                  <div class="form-group">
                    <label class="col-form-label">Login</label>
                    <input class="form-control" type="text" required="" id="Email" name="Email" placeholder="Email OR Username">
                  </div>
                  <div class="form-group">
                    <label class="col-form-label">Password</label>
                    <input class="form-control" type="password" id="pass" name="pass" required="">
                  </div>
                  <div class="form-group mb-0">
                    <!-- <div class="checkbox p-0">
                      <input id="checkbox1" type="checkbox">
                      <label class="text-muted" for="checkbox1">Remember password</label>
                    </div> -->
                    <button class="btn btn-primary btn-block" type="submit" value="Log In" name="Login" id="Login">Sign in</button>
                    <!-- password forgot modal botton start -->
                    <p class="text-start">Forgot your pasword 
                            <a data-bs-target=".bd-example-modal-lg" data-bs-toggle="modal" data-bs-original-title="" title="" href="javascript:void(0)" data-bs-original-title="" title=""> <svg xmlns="http://www.w3.org/2000/svg" width="10" height="5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" >
                             </svg>Click here</a>
                    </p>
                 </div>
                    <!-- password forgot modal botton end-->
                    <!-- <h6 class="text-muted mt-4 or">Sign in as Admin</h6>
                    <div class="social mt-4">
                    <div class="btn-showcase"><a class="btn btn-light" href="<?php // echo $conf->site_url;?>admin/">Login as admin</a></div>
                  </div>
                  <p class="mt-4 mb-0">Don't have account?<a class="ms-2" href="sign-up.html">Create Account</a></p> -->
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- latest jquery-->
      <script src="<?php echo $conf->site_url;?>assets/js/jquery-3.5.1.min.js"></script>
      <!-- Bootstrap js-->
      <script src="<?php echo $conf->site_url;?>assets/js/bootstrap/bootstrap.bundle.min.js"></script>
      <!-- feather icon js-->
      <script src="<?php echo $conf->site_url;?>assets/js/icons/feather-icon/feather.min.js"></script>
      <script src="<?php echo $conf->site_url;?>assets/js/icons/feather-icon/feather-icon.js"></script>
      <!-- scrollbar js-->
      <!-- Sidebar jquery-->
      <script src="<?php echo $conf->site_url;?>assets/js/config.js"></script>
      <!-- Plugins JS start-->
      <!-- Plugins JS Ends-->
      <!-- Theme js-->
      <script src="<?php echo $conf->site_url;?>assets/js/script.js"></script>
      <!-- login js-->
      <!-- Plugin used-->
    </div>
 

<!-- Start recovery email modal -->
<div class="modal fade bd-example-modal-lg" id="add-modal-data" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
                <h4 class="modal-title text-center my-2" id="myLargeModalLabel">Recover Your Account</h4>
                <button class="btn-close text-end" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
 
        </div>
            <div class="modal-body">
            
            <form method="POST"class="theme-form" id="" action="<?php echo base()."login";?>" method="post">
              <?php if($security==0){?>
                <div class="form-group">
                    <label class="col-form-label">Email</label>
                    <input class="form-control" type="email" required="" id="RegisteredEmail" name="RegisteredEmail" placeholder="enter registered email">
                </div>
                <div class="from-group mt-3 justify-content-right">
                  <button type="button" data-bs-dismiss="modal" class="btn btn-warning">Cancel</button>
                  <button class="btn btn-primary" type="submit" value="Question" name="Question" id="Question">Send Email</button>
                </div>
              <?php }else{?>
                <div class="form-group">
                    <label class="col-form-label">Question</label>
                    <p> <?php echo $Question;?></p>
                </div>
                <div class="form-group">
                    <label class="col-form-label">Answer</label>
                    <input class="form-control" type="text" required id="SecurityAnswer" name="SecurityAnswer" placeholder="Enter your answer">
                    <input class="form-control" type="hidden" id="RegisteredEmail" name="RegisteredEmail" value="<?php echo $_POST['RegisteredEmail']?>">
                </div>
                <div class="from-group mt-3 justify-content-right">
                  <button type="button" data-bs-dismiss="modal" class="btn btn-warning">Cancel</button>
                  <button class="btn btn-primary" type="submit" value="Answer" name="SecAnswer" id="SecAnswer">Submit</button>
                </div>
              <?php }?> 
            </form>
            </div>
        </div>
    </div>
</div>

<script> 

function openModal(frameSrc,modalID,SrcID)
{ 
  document.getElementById(SrcID).src = frameSrc;
  $(modalID).modal('show');
}

<?php if($security){?>
  $(document).ready(function(){
    $(".bd-example-modal-lg").modal('show');
  });
<?php }?>
</script> 
  </body>
</html>