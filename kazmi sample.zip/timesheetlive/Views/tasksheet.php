<?php include_once("header.php");

$done = 0;

if(isset($Route[1]))
{
    $_GET['page']=$Route[1] ;
    $current_page=$Route[1];
}
else{
    $current_page = 1;
    $_GET['page']=1;
}

if(($data = $EmployeePointer->getAssignedTasksList())!=null)
{
  $done = 1;
} 

$params='';
$thispage= base()."tasksheet";
$total_pages = $EmployeePointer->total_pages;


?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("sidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Project Tasks</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>dashboard"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Project</li>
                    <li class="breadcrumb-item active">Task list</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>Project</th>
                                    <th>Phase</th>
                                    <th>Module</th>
                                    <th>Task Title</th>
                                    <th>Estimated Hours</th>
                                    <th>Hours Spent</th>
                                    <th>Due Date</th>
                                    <th>Created Date</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if($done){
                                    foreach($data as $row){
                                      $x = $EmployeePointer->getTaskActivityDetail($data[0]['task_id']);

                                ?>
                                    <tr>
                                        <td><?php echo $row['project_name']?></td>
                                        <td><?php echo $row['phase_type']?></td>
                                        <td><?php echo $row['module_name']?></td>
                                        <td><?php echo $row['task_title']?></td>
                                        <td><?php echo $row['estimated_hours']?></td>
                                        <td><?php echo $EmployeePointer->getTotalSpendHours($row['task_id']);?></td>
                                        <td><?php echo $row['due_date']?></td>
                                        <td><?php echo $row['created_at']?></td>
                                        <td><?php $x = $EmployeePointer->getTaskActivityDetail($row['task_id']); echo $x[0]['start_date']?></td>
                                        <td><?php $x = $EmployeePointer->getTaskActivityDetail($row['task_id']); echo $x[0]['end_Date']?></td>
                                        <td><?php echo $row['task_status']?></td>
                                        <td>
                                            <?php if($row['task_status'] == 'Pending' || $row['task_status'] == 'Inprogress' || $row['task_status'] == 'On Hold'){?> 
                                                <a href="javascript:void(0);" onClick="openModal('<?php echo base()?>edit_task_progress/<?php echo $row['project_id']?>/<?php echo $row['task_id']?>/<?php echo $row['module_id']?>/<?php echo $row['phase_id']?>/<?php echo $row['estimated_hours']?>','#editModal','ifEdit')"> Update </a>
                                            <?php }?>
                                        </td>
                                    </tr>
                                <?php }//end foreach.
                                }?>
                                </tbody>
                            </table>
                            </div>
                    </div>
                    <div class="text-center mt-5 mb-5">
                                    <nav>
                                        <ul class="pagination justify-content-center pagination-primary">
                                            <?php echo($EmployeePointer->getPageMenu($total_pages, $current_page, $thispage, $params));?>
                                        </ul>
                                    </nav>
                                
                            </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
<script> 
   $(document).ready(function () {
    $('#basic-1').DataTable({
        "order": [[ 1, "desc" ]],
        "paging": false
    });

    $('#editModal').modal({
           backdrop: 'static',
           keyboard: false
    })
   });
function openModal(frameSrc,modalID,SrcID)
{ 
    document.getElementById(SrcID).src = frameSrc;
    $(modalID).modal('show');
}

function closeModal(modalID,pgref)
{
    $('#editModal').modal('hide');
    if(pgref == 1){
    if(window.top==window) {
        // you're not in a frame so you reload the site
        window.location="<?php echo base()?>tasksheet";
        //window.setTimeout('location.reload()', 1000); //reloads after 3 seconds
    }
    }
} 

</script>  


<!--model start-->

<div class="modal fade bd-example-modal-lg" id="editModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">Update Progress</h5>
            </div>
            <iframe id="ifEdit" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--model end-->
</body>
</html>