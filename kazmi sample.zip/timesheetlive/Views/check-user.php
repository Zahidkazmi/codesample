<?php
// include_once("../config.php");
// $conf= new config();
include_once($conf->absolute_path . "Controller/SubAdminEmployeeController.php");
$EmployeePointer = new SubAdminEmployeeController();
$where = $data = null; 


if((isset($_POST['username']) && $_POST['username'] !=''))
{
    $where = "username ='".$_POST['username']."'";
}
$query="SELECT user_id,first_name,last_name FROM tblusers
WHERE
    ".$where."
ORDER BY
    first_name";
    //echo $query;
if(($data = $EmployeePointer->CustomQuery($query))!=null)
{ 
    echo 'false';
}else{
    echo 'true';
}
?>