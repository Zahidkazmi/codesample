<?php
include_once($conf->absolute_path . "Controller/SubAdminReportController.php");
$ReportPointer = new SubAdminReportController();
$data = null; 

if(($data = $ReportPointer->getEmployeeProjects())!=null)
{ ?>
<option value="">Select Project</option>
<?php
    foreach ($data as $arr){
        ?>
        <option value="<?php echo $arr['project_id'];?>"><?php echo $arr['project_name'];?></option>
        <?php
    }
}
$ReportPointer->destroy_SubAdminReportController();
?>