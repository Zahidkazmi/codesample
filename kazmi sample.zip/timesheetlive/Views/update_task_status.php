<?php 
include_once($conf->absolute_path."Controller/EmployeeController.php");
$EmployeePointer = new EmployeeController();
$done = 0;
if($EmployeePointer->UpdateTaskStatus())
{
    echo "Task Status Updated";
    $done=1;
}
?>