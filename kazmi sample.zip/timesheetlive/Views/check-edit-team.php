<?php
// include_once("../config.php");
// $conf= new config();
include_once($conf->absolute_path . "Controller/SubAdminEmployeeController.php");
$TeamPointer = new SubAdminEmployeeController();
$where = $data = null; 


if((isset($_POST['team_name']) && $_POST['team_name'] !=''))
{
    $where = "team_name ='".$_POST['team_name']."'";
}

$query="SELECT team_id  ,team_name  FROM tblteam
WHERE
    ".$where." AND team_id != '".$Route[1]."'
ORDER BY
team_name";
    //echo $query;
if(($data = $TeamPointer->CustomQuery($query))!=null)
{ 
    echo 'false';
}else{
    echo 'true';
}
?>