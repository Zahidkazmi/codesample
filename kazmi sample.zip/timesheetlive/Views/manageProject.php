<?php include_once("header.php");
    include_once($conf->absolute_path."Controller/SubAdminProjectController.php");
    $ProjectPointer = new SubAdminProjectController();
    if(isset($Route[1]))
    {
        $_GET['page']=$Route[1] ;
        $current_page=$Route[1];
    }
    else{
        $current_page = 1;
        $_GET['page']=1;
    }
    if(isset($_POST)){
        $ProjectPointer->AssignProjectToTeam();
        unset($_POST['project_id'],$_POST['team_id'],$_POST['submit']);
    }
    $data = $ProjectPointer->getProjectLists();
    $params='';
    $thispage= base()."manageProject";
    $total_pages = $ProjectPointer->total_pages;    
    
?>
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-sidebar" id="pageWrapper">
      <!-- Page Header Start-->
      <?php include_once("topmenu.php");?>
      <!-- Page Header Ends -->
      <!-- Page Body Start-->
      <div class="page-body-wrapper compact-wrapper box-layout">
        <!-- Page Sidebar Start-->
        <?php include_once("adminsidebar.php");?>
        <!-- Page Sidebar Ends-->
        <div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-6">
                  <h3>Manage Projects</h3>
                </div>
                <div class="col-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base()?>dashboard"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Projects</li>
                    <li class="breadcrumb-item active">Manage Projects</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
            <div class="col-md-12 project-list">
                <div class="card">
                  <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6">
                        <div class="text-end">
                            <div class="form-group mb-0 me-0">

                            </div>
                            <a class="btn btn-primary" data-bs-original-title="" title="" href="<?php echo base()?>CreateNewProject" data-bs-original-title="" title=""> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-square">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line></svg>Create New Project</a>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
                <div class="col-sm-12">
                    <div class="card-body">
                            <div class="card-scroll">
                            <table class="display" id="basic-1">
                                <thead>
                                <tr>
                                    <th>P.Code</th>                                    
                                    <th>Project</th>
                                    <th>Phase</th>
                                    <th>Type</th>
                                    <th>Value</th>
                                    <th>Priority</th>
                                    <th>Size</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Client</th>
                                    <th>Description</th>
                                    <th>Created at</th>
                                    <th>Starting Date</th>
                                    <th>Ending Date</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($data as $row){?>
                                    <tr>
                                        <td><?php echo $row['project_code'];?></td>
                                        <td><?php echo $row['project_name'];?></td>
                                        <td><?php echo $row['phase_status'];?></td>
                                        <td><?php echo $row['project_type'];?></td>
                                        <td><?php echo $row['project_value'];?></td>
                                        <td><?php echo $row['project_priority'];?></td>
                                        <td><?php echo $row['project_size'];?></td>
                                        <td><?php echo $row['starting_date'];?></td>
                                        <td><?php echo $row['ending_date'];?></td>
                                        <td><?php echo $row['client_name'];?></td>
                                        <td> <a title="<?php echo $row['project_description'] ?>"> <?php echo substr($row['project_description'], 0, 10);?></a>...</td>
                                        <td><?php echo $row['created_at'];?></td>
                                        <td><?php echo $row['starting_date'];?></td>
                                        <td><?php echo $row['ending_date'];?></td>
                                        <td>
                                            <a href="<?php echo base()?>EditProject/<?php echo $row['project_id']?>/<?php echo $current_page;?>" title="Edit Project"> <i class="fa fa-wrench"></i></a> |
                                            <a href="<?php echo base()?>manageProjectTasks/<?php echo $row['project_id']?>" title="View Project Tasks"> <i class="fa fa-eye"></i></a> 
                                            <?php if(!$ProjectPointer->IsProjectAssigned($row['project_id'])){?> |
                                                <a data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg" data-id="<?php echo $row['project_id'].",".$row['organization_id'];?>" class="edit" href="javascript:void(0);" title="Assign Project To Team"> <i class="fa fa-arrow-right"></i></a> 
                                            <?php }?>
                                        </td>
                                    </tr>
                                <?php }?>
                                </tbody>
                            </table>
                            </div>
                            <div class="text-center mt-5 mb-5">
                                    <nav>
                                        <ul class="pagination justify-content-center pagination-primary">
                                            <?php echo($ProjectPointer->getPageMenu($total_pages, $current_page, $thispage, $params));?>
                                        </ul>
                                    </nav>
                                
                            </div>
                    </div>                    
                </div>
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>

        
        <!-- footer start-->
        <?php include_once("footer.php");?>
         <!-- footer end-->
      </div>
    </div>
    <?php include_once("js.php");?>
<script> 

function openModal(frameSrc,modalID,SrcID)
{ 
    document.getElementById(SrcID).src = frameSrc;
    $(modalID).modal('show');
}

function closeModal(modalID,pgref)
{
    $('#editModal').modal('hide');
    if(pgref == 1){
    if(window.top==window) {
        // you're not in a frame so you reload the site
        window.setTimeout('location.reload()', 1000); //reloads after 3 seconds
    }
    }
} 
$(document).ready(function() {
    $('#basic-1').DataTable({
        "order": [[ 1, "desc" ]],
        "paging": false
    });
$('.edit').click(function(){
    //get cover id
    var id=$(this).data('id').split(",");
    
    $('#project_id').val(id[0]);
    var formData = {
            'organization_id': id[1]
    };
    $.ajax({
        type: "POST",
        url: "<?php echo base()?>get_ajax_teams",
        data: formData
    }).done(function(users) {
        $("#team_id").html('');
        $("#team_id").html(users);
    });
})


<?php if($ProjectPointer->SuccessMsg){?>
    swal({
            title: "Success!",
            text: "<?php echo $ProjectPointer->SuccessMsg?>",
            type: "success"
    }, function() {
        window.location = "<?php echo base()?>manageProject";
    }); 
<?php }?>
<?php if($ProjectPointer->ErrorMsg){?>
    swal({
            title: "Error!",
            text: "<?php echo $ProjectPointer->ErrorMsg?>",
            type: "error"
    }); 
<?php }?>

});

</script>  


<!--model start-->
<div class="modal fade bd-example-modal-lg" id="add-modal-data" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Assign Project To Team</h4>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" id="project_assign" action="<?php echo base()?>manageProject">
                    <div class="row">                             
                        <div class="form-group">
                            <label class="w-100 d-flex justify-content-start" >Teams</label>
                            <select name="team_id" id="team_id" class="form-control" required>
                                
                            </select>
                            <input type="hidden" name="project_id" id="project_id" value="" class="form-control">
                        </div>                       
                        
                        <div class="col-sm-12 mt-3">                        
                            <div class="from-group mt-3 justify-content-right">
                                <button type="button" data-bs-dismiss="modal" class="btn btn-warning">Close</button>
                                <button type="submit" name="submit" id="submit" value="assignProject" class="btn btn-primary">Submit</button>
                            </div>                        
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bd-example-modal-lg" id="editModal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-left">
                <h5 class="modal-title">Edit Assigned Team</h5>
                    <button type="button" class="btn-close" data-dismiss="modal"><span> <i class="fa fa-times"></i> </span>
                </button>
            </div>
            <iframe id="ifEdit" frameborder="0" height="450px" width="100%"></iframe>
        </div>
    </div>
</div>
<!--model end-->
</body>
</html>