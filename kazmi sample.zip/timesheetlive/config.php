<?php
ini_set('display_errors',0);
class config {
    var $absolute_path="/var/www/html/timesheet/";#include ending /
    var $site_url="http://3.134.115.252/";#include ending /
    var $db_host="localhost";
    var $db_name="timesheet";	
    var $db_user="phpmyadmin";
    var $db_pass="phpmyadmin123";
    var $image_dir = "assets/images/user/";
    var $upload_size_allowed="2097152";
    var $csv_dir = "csvfiles/";
}
?>
