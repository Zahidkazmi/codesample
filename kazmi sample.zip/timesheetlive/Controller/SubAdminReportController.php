<?php
/*********************************************************
 * Name: SubAdminReportController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com, zahid.kazmi@viltco.com
 * Skype: programerparadise
 * Description: Class for managing Subadmin end session controls.
 * Version: 1.2
 * Last edited: 02 jun, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class SubAdminReportController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_SubAdminReportController()
	{
		$this->DBDisconnect();
	} 

    public function getActivityReportLists()
    {
		if(isset($_POST['search_record']) && $_POST['search_record'] = "Search")
		{
			unset($_SESSION['admin_query']);
			if (isset($_POST['user_id']) && $_POST['user_id'] != '') {
				$where = "u.user_id = '" . $_POST['user_id'] . "'";
			}

			if (isset($_POST['project_id']) && $_POST['project_id'] != '') {
				if (isset($where)) {
					$where .= " AND p.project_id = '" . $_POST['project_id'] . "'";
				} else {
					$where = "p.project_id = '" . $_POST['project_id'] . "'";
				}
			}
		}
		if (isset($_POST['search_record']) && isset($where)) {
			$query ="SELECT t.task_id,t.task_status,t.task_description,t.estimated_hours,p.project_name,pp.phase_type,
					 m.module_name,u.first_name,u.last_name
					 FROM tbltask AS t
					 INNER JOIN tblproject AS p ON p.project_id = t.project_id
					 INNER JOIN tblphases AS pp ON pp.phase_id = t.phase_id 
					 INNER JOIN tblmodule AS m ON m.module_id = t.module_id 
					 INNER JOIN tblusers AS u ON u.user_id = t.resource_id
					 WHERE " . $where . " AND u.organization_id = '".$_SESSION['organization_id']."'";
			$_SESSION['admin_query'] = urlencode(rc4crypt::encrypt("programerparadise", $where, 1));
		}
		else if (isset($_SESSION['admin_query'])) {
			$where = rc4crypt::decrypt("programerparadise", urldecode($_SESSION['admin_query']), 1);
			$query ="SELECT t.task_id,t.task_status,t.task_description,t.estimated_hours,p.project_name,pp.phase_type,
					 m.module_name,u.first_name,u.last_name
					 FROM tbltask AS t
					 INNER JOIN tblproject AS p ON p.project_id = t.project_id
					 INNER JOIN tblphases AS pp ON pp.phase_id = t.phase_id 
					 INNER JOIN tblmodule AS m ON m.module_id = t.module_id 
					 INNER JOIN tblusers AS u ON u.user_id = t.resource_id
					 WHERE " . $where . " AND u.organization_id = '".$_SESSION['organization_id']."'";
		}
        else{
			$query ="SELECT t.task_id,t.task_status,t.task_description,t.estimated_hours,p.project_name,pp.phase_type,
					 m.module_name,u.first_name,u.last_name
					 FROM tbltask AS t
					 INNER JOIN tblproject AS p ON p.project_id = t.project_id
					 INNER JOIN tblphases AS pp ON pp.phase_id = t.phase_id 
					 INNER JOIN tblmodule AS m ON m.module_id = t.module_id 
					 INNER JOIN tblusers AS u ON u.user_id = t.resource_id
					 WHERE u.organization_id = '".$_SESSION['organization_id']."'";
		}
		if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getProgressReport()
    {
		if(isset($_POST['search_record']) && $_POST['search_record'] = "Search")
		{
			unset($_SESSION['admin_query']);
			if (isset($_POST['daterange']) && $_POST['daterange'] != '') {
				$date = explode(" - ",$_POST['daterange']);
				$where = "t.created_at >='".dbDateFormat($date[0])."' AND t.created_at <='".dbDateFormat($date[1])."'";
			}

			if (isset($_POST['project_id']) && $_POST['project_id'] != '' && $_POST['project_id'] != 'All') {
				if (isset($where)) {
					$where .= " AND t.project_id = '" . $_POST['project_id'] . "'";
				} else {
					$where = "t.project_id = '" . $_POST['project_id'] . "'";
				}
			}
		}
		if (isset($_POST['search_record']) && isset($where)) {
			$query ="SELECT u.user_id,CONCAT(u.first_name,' ',u.last_name) AS employee_name,SUM(t.estimated_hours) as estimated_hours
					 FROM tbltask AS t
					 INNER JOIN tblproject AS p ON p.project_id = t.project_id
					 INNER JOIN tblusers AS u ON u.user_id = t.resource_id
					 WHERE " . $where . " AND u.organization_id = '".$_SESSION['organization_id']."'
					 GROUP BY u.user_id,u.first_name,u.last_name
					 ORDER BY u.first_name";
			$_SESSION['admin_query'] = urlencode(rc4crypt::encrypt("programerparadise", $where, 1));
		}
		else if (isset($_SESSION['admin_query'])) {
			$where = rc4crypt::decrypt("programerparadise", urldecode($_SESSION['admin_query']), 1);
			$query ="SELECT u.user_id,CONCAT(u.first_name,' ',u.last_name) AS employee_name,SUM(t.estimated_hours) as estimated_hours
					 FROM tbltask AS t
					 INNER JOIN tblproject AS p ON p.project_id = t.project_id
					 INNER JOIN tblusers AS u ON u.user_id = t.resource_id
					 WHERE " . $where . " AND u.organization_id = '".$_SESSION['organization_id']."'
					 GROUP BY u.user_id,u.first_name,u.last_name
					 ORDER BY u.first_name";
		}
        else{
			$query ="SELECT u.user_id,CONCAT(u.first_name,' ',u.last_name) AS employee_name,SUM(t.estimated_hours) as estimated_hours
					 FROM tbltask AS t
					 INNER JOIN tblproject AS p ON p.project_id = t.project_id
					 INNER JOIN tblusers AS u ON u.user_id = t.resource_id
					 WHERE u.organization_id = '".$_SESSION['organization_id']."'
					 GROUP BY u.user_id,u.first_name,u.last_name
					 ORDER BY u.first_name";
		}
		
		if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getProgressTaskStatus($user_id,$task_status)
	{
		$clause = NULL;
		if (isset($_POST['daterange']) && $_POST['daterange'] != '') {
			$date = explode(" - ",$_POST['daterange']);
			$clause = "t.created_at >='".dbDateFormat($date[0])."' AND t.created_at <='".dbDateFormat($date[1])."'";
		}
		if (isset($_POST['project_id']) && $_POST['project_id'] != '' && $_POST['project_id'] != 'All') {
			if (isset($clause)) {
				$clause .= " AND t.project_id = '" . $_POST['project_id'] . "'";
			} else {
				$clause = "t.project_id = '" . $_POST['project_id'] . "'";
			}
		}
		if($clause){			
			$query = "SELECT COUNT(t.task_status) as task_status
			FROM tbltask AS t
			INNER JOIN tblproject AS p ON p.project_id = t.project_id
			INNER JOIN tblusers AS u ON u.user_id = t.resource_id 
			WHERE " . $clause . " AND u.organization_id = '".$_SESSION['organization_id']."' AND u.user_id = '".$user_id."' AND t.task_status='".$task_status."'";
		}else{
		$query = "SELECT COUNT(t.task_status) as task_status
					FROM tbltask AS t
					INNER JOIN tblproject AS p ON p.project_id = t.project_id
					INNER JOIN tblusers AS u ON u.user_id = t.resource_id  
					WHERE u.organization_id = '".$_SESSION['organization_id']."' AND u.user_id = '".$user_id."' AND t.task_status='".$task_status."'";
		}
		
		if(($data=$this->CustomQuery($query))!=NULL)
        {
            echo $data[0]['task_status'];
        }else{
		echo "0";
		}
	}

	public function getProgressHourSpend($user_id)
	{
		$clause = NULL;
		if (isset($_POST['daterange']) && $_POST['daterange'] != '') {
			$date = explode(" - ",$_POST['daterange']);
			$clause = "ta.start_date >='".dbDateFormat($date[0])."' AND ta.end_date <='".dbDateFormat($date[1])."'";
		}
		if (isset($_POST['project_id']) && $_POST['project_id'] != '' && $_POST['project_id'] != 'All') {
			if (isset($clause)) {
				$clause .= " AND ta.project_id = '" . $_POST['project_id'] . "'";
			} else {
				$clause = "ta.project_id = '" . $_POST['project_id'] . "'";
			}
		}
		if($clause){			
			$query = "SELECT SUM(ta.hour_spend) as hour_spend
			FROM tblproject_activity AS ta
			INNER JOIN tbltask AS t ON t.task_id = ta.task_id
			INNER JOIN tblusers AS u ON u.user_id = t.resource_id 
			WHERE " . $clause . " AND u.organization_id = '".$_SESSION['organization_id']."' AND u.user_id = '".$user_id."'";
		}else{
		$query = "SELECT SUM(ta.hour_spend) as hour_spend
					FROM tblproject_activity AS ta
					INNER JOIN tbltask AS t ON t.task_id = ta.task_id
					INNER JOIN tblusers AS u ON u.user_id = t.resource_id  
					WHERE u.organization_id = '".$_SESSION['organization_id']."' AND u.user_id = '".$user_id."'";
		}
		
		if(($data=$this->CustomQuery($query))!=NULL)
        {
			if($data[0]['hour_spend'] !='' && $data[0]['hour_spend'] > 0)
            {
				echo $data[0]['hour_spend'];
			}
			else{
				echo "0";
			}
        }
	}

	public function getTaskActivityDetail($task_id)
	{

		$query="SELECT MIN(start_date) AS `start_date`, MAX(end_date) AS `end_Date`, SUM(pa.hour_spend) AS `hour_spend` FROM tbltask AS t
				INNER JOIN tblproject_activity AS pa ON t.task_id = pa.task_id
				WHERE pa.task_id = '$task_id'";
				
		if(($data = $this->CustomQuery($query))!=NULL)
		{
			//$array = array($data[0]['hour_spend'], $data[0]['start_date'], $data[0]['end_date']);
			return $data;
		}
	}

	public function getOrganizationEmployees()
	{
		$query="SELECT user_id,first_name,last_name FROM tblusers WHERE organization_id = '".$_SESSION['organization_id']."' ORDER BY first_name ASC";
		if(($data=$this->CustomQuery($query))!=null)
		{
			return $data;
		}
	}

	public function getOrganizationProjects()
	{
		$query="SELECT project_id,project_name FROM tblproject WHERE organization_id = '".$_SESSION['organization_id']."' ORDER BY project_name ASC";
		if(($data=$this->CustomQuery($query))!=null)
		{
			return $data;
		}
	}

	public function getEmployeeProjects()
    {
        $query ="SELECT project.project_id,project.project_name 
                 FROM `tblproject` AS project 
                 INNER JOIN tblproject_vs_team AS pvt ON project.project_id = pvt.project_id 
                 INNER JOIN tblteam_members AS tm ON tm.team_id = pvt.team_id
                 WHERE tm.resource_id='".$_POST['user_id']."' ORDER BY project.project_name";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }
	
}//end class.
?>