<?php
/*********************************************************
 * Name: SubAdminProjectController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com, zahid.kazmi@viltco.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 1st June, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class SubAdminProjectController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_SubAdminProjectController()
	{
		$this->DBDisconnect();
	}

	function getPageMenu($total_pages, $current_page, $thispage, $params)
	{
		$Html='';
		if($total_pages>1)
		{
			if (($total_pages<=1) || ($current_page<=1)){
				$prev=$thispage.$params."/1";
			}else{
				$prev=$thispage.$params."/".($current_page-1);
			}
			if (($total_pages<=1) || ($current_page==$total_pages)){
				$next=$thispage.$params."/".($total_pages);
			}else{
				$next=$thispage.$params."/".($current_page+1);
			}
			
			
			$link_limit=5;
			$start=1;
			$end=$link_limit;
			if($current_page>$link_limit){
				$start=$current_page+1;	
				$end=$start+$link_limit;
			}
			if($end > $total_pages){
				$end=$total_pages;
			}
			$pages='';
			for ($i=$start;$i<=$end;$i++){
				if($i==$current_page){
					$pages.='<li class="page-item active"><a class="page-link" href="javascript:void()">'.$i.'</a></li>';
				}else{
					$pages.='<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/'.$i.'">'.$i.'</a></li>';
				}
				
				/*if($i<$end){
					$pages.=' | ';
				}*/
			}
			
			if($current_page == 1){
	
				$Html.='<!--Page Area-->
						<li class="page-item"><a class="page-link" href="javascript:void(0)">Start</a></li>
						<li class="page-item page-indicator"><a class="page-link" href="javascript:void(0)"><i class="fa fa-angle-double-left"></i> Prev</a></li>
						'.$pages.'
						<li class="page-item page-indicator"><a class="page-link" href="'.$next.'">Next<i class="fa fa-angle-double-right"></i></a></li>
						<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/'.$total_pages.'">End</a></li>
						';	
			}else if($current_page == $total_pages){
				
				$Html.='<!--Page Area-->
						<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/1">Start</a></li>
						<li class="page-item page-indicator"><a class="page-link" href="'.$prev.'"><i class="fa fa-angle-double-left"></i> Prev</a></li>
						'.$pages.'
						<li class="page-item page-indicator"><a class="page-link" href="javascript:void(0)">Next<i class="fa fa-angle-double-right"></i></a></li>
						<li class="page-item"><a class="page-link" href="javascript:void(0)">End</a></li>
						';	
			}else{
				$Html.='<!--Page Area-->
						<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/1">Start</a></li>
						<li class="page-item page-indicator"><a class="page-link" href="'.$prev.'"><i class="fa fa-angle-double-left"></i>Prev</a></li>
						'.$pages.'
						<li class="page-item page-indicator"><a class="page-link" href="'.$next.'">Next<i class="fa fa-angle-double-right"></i></a></li>
						<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/'.$total_pages.'">End</a></li>
						';
			}
					
		}
		return $Html;
    }

	public function IsProjectAssigned($project_id)
	{
		if($this->GetSingleField("tblproject_vs_team","project_id",$project_id,"project_id"))
		{
			return 1;
		}
		return 0;
	}

	function prePreprocessor()
	{
		
		if(empty($_POST['project_code']))
		{
			$this->ErrorMsg="Please enter project code.";
			return 0;
		}

		if(empty($_POST['project_name']))
		{
			$this->ErrorMsg="Please enter project name.";
			return 0;
		}
		
		
		

		if(empty($_POST['client_id']))
		{
			$this->ErrorMsg="Please select project client.";
			return 0;
		}

        if($_POST['project_value'] < 0)
		{
			$this->ErrorMsg="Please entert project cost.";
			return 0;
		}

        if($_POST['project_type'] =='' || $_POST['project_type'] == 'Select Type')
		{
			$this->ErrorMsg="Please select project type.";
			return 0;
		}

        if($_POST['project_priority'] =='' || $_POST['project_priority'] == 'Select Priority')
		{
			$this->ErrorMsg="Please select project priority.";
			return 0;
		}

        if($_POST['project_size'] =='' || $_POST['project_size'] == 'Select Size')
		{
			$this->ErrorMsg="Please select project size.";
			return 0;
		}

        if($_POST['starting_date'] =='')
		{
			$this->ErrorMsg="Please select project starting date.";
			return 0;
		}
		return 1;
	}

	public function getPhases()
    {
        $query ="SELECT phase_id,phase_type  FROM tblphases";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="Phases not defined.";
        return 0;
    }

	public function getClient()
    {
        $query ="SELECT client_id , client_name FROM tblclients where organization_id = '".$_SESSION['organization_id']."' AND client_status ='Active'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="Clients not defined.";
        return 0;
    }

    public function getProjectClient()
    {
        $query ="SELECT client_id , client_name FROM tblclients where organization_id = '".$_SESSION['organization_id']."' AND client_status ='Active'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="Clients not defined.";
        return 0;
    }

	public function getOrganization()
    {
        $query ="SELECT organization_id,organization_name FROM tblorgnization where organization_status ='Active'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="Organizations not defined.";
        return 0;
    }

    public function getProjectLists()
    {
		$query ="SELECT p.project_id,p.project_code,p.project_name,p.project_description,p.project_type,p.phase_status,
		p.project_value,p.project_priority,p.project_size,p.starting_date,p.ending_date,c.client_name,o.organization_id,
		o.organization_name, p.created_at, p.starting_date,p.ending_date
		FROM tblproject AS p INNER JOIN tblclients AS c ON c.client_id = p.client_id 
		INNER JOIN tblorgnization AS o ON o.organization_id = p.organization_id 
		WHERE o.organization_id = '".$_SESSION['organization_id']."' ORDER BY p.project_name";
		if($_GET['page'] !=''){
			$page = $_GET['page']; 
		}else{
			$page = 1;
		} 
        $limit = 5; 
		$total = $this->RecordsInQuery($query);
		// work out the pager values  
		$pager  = Pager::getPagerData($total, $limit, $page);  
		$offset = $pager->offset;  
		$limit  = $pager->limit;  
		$page   = $pager->page;
		$this->total_pages=$pager->numPages;
		
		$query=$query." limit $offset, $limit ";
		
		if($offset >= 0){
			if(($data=$this->CustomQuery($query))!=null)
			{
				return $data;
			}
		}
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getProjectCreationDetail($project_id,$field)
	{
		$query="SELECT first_name, last_name FROM tblusers 
				INNER JOIN tblproject ON tblusers.user_id = tblproject.$field
				WHERE tblproject.project_id = '$project_id'";
		if(($data = $this->CustomQuery($query))!=NULL)
		{
			return $data[0]['first_name']." ".$data[0]['last_name'];
		}
	}

	public function getTaskCreationDetail($task_id,$field)
	{
		$query="SELECT first_name, last_name FROM tblusers 
				INNER JOIN tbltask ON tblusers.user_id = tbltask.$field
				WHERE tbltask.task_id = '$task_id'";
		if(($data = $this->CustomQuery($query))!=NULL)
		{
			return $data[0]['first_name']." ".$data[0]['last_name'];
		}
	}

	//get project task start and end dates

	public function getTaskActivityDetail($task_id)
	{

		$query="SELECT MIN(start_date) AS `start_date`, MAX(end_date) AS `end_Date` FROM tbltask AS t
				INNER JOIN tblproject_activity AS pa ON t.task_id = pa.task_id
				WHERE pa.task_id = '$task_id'";
				
		if(($data = $this->CustomQuery($query))!=NULL)
		{
			//$array = array($data[0]['hour_spend'], $data[0]['start_date'], $data[0]['end_date']);
			return $data;
		}
	}

	public function generateProjectCode()
	{
		$query = "SELECT project_code FROM tblproject ORDER BY project_id DESC LIMIT 1";

		if(($data=$this->CustomQuery($query))!=null)
		{
			$last_recent_code = explode("-", $data[0]['project_code']);
			$ex_code = substr($last_recent_code[1], 0) + 1;
			$str = $_SESSION['organization_name'];
			$x = (explode(" ",$str));
			if($ex_code < 10)
			{
			  $ex_code = "000".$ex_code;
			}
			else if($ex_code <= 99)
			{
			  $ex_code = "00".$ex_code;
			}
			else if($ex_code <= 999)
			{
			  $ex_code = "0".$ex_code;
			}
			$y=substr($x[0],0,1).substr($x[1], 0, 1);
			$project_code =  strtoupper($y)."-".$ex_code;
			return $project_code;
		}
		 return 0;
	}

	public function AddNewProject()
    {
        if (isset($_POST) && $_POST['submit'] == 'New Project') {
            if ($this->prePreprocessor()) {

                $project_code=test_input($_POST['project_code']);
                $_POST['project_code']='';
                unset($_POST['project_code']);

                $project_name=test_input($_POST['project_name']);
                $_POST['project_name']='';
                unset($_POST['project_name']);


                $client_id=test_input($_POST['client_id']);
                $_POST['client_id']='';
                unset($_POST['client_id']);

                $project_description=$_POST['project_description'];
                $_POST['project_description']='';
                unset($_POST['project_description']);

                $project_priority=$_POST['project_priority'];
                $_POST['project_priority']='';
                unset($_POST['project_priority']);

                $project_size=$_POST['project_size'];
                $_POST['project_size']='';
                unset($_POST['project_size']);

                $project_value=$_POST['project_value'];
                $_POST['project_value']='';
                unset($_POST['project_value']);

                $project_type=$_POST['project_type'];
                $_POST['project_type']='';
                unset($_POST['project_type']);

                $starting_date=dbDateFormat($_POST['starting_date']);
                $_POST['starting_date']='';
                unset($_POST['starting_date']);
				if(isset($_POST['ending_date']) && $_POST['ending_date'] !=''){
					$ending_date=dbDateFormat($_POST['ending_date']);
                	$_POST['ending_date']='';
                	unset($_POST['ending_date']);
				}else{
					$ending_date = NULL;
				}

				$phase_status=$_POST['phase_status'];
                $_POST['phase_status']='';
                unset($_POST['phase_status']);
				
                $query="SELECT project_name,client_id,organization_id FROM tblproject WHERE project_name = '$project_name' AND project_code='$project_code' AND client_id='$client_id' AND organization_id='".$_SESSION['organization_id']."'";

                if (($data = $this->CustomQuery($query))==null) {
                    $insert = "project_code,project_name,organization_id,client_id,project_description,project_priority,project_size,project_value,project_type,starting_date,ending_date,phase_status, created_by";
                    $vals = "'".$project_code."','".$project_name."','".$_SESSION['organization_id']."','".$client_id."','".mysqli_real_escape_string($this->DBlink, $project_description)."','".$project_priority."','".$project_size."','".$project_value."','".$project_type."','".$starting_date."','".$ending_date."','".$phase_status."', '".$_SESSION['user_id']."'";
                    //echo "INSERT INTO `tblproject` ($insert) VALUES ($vals)"; exit;
					//if ($this->GetSingleField("tblproject", "project_name", $project_name, "project_name") != $project_name) {
                        if ($this->InsertRecord("tblproject", $insert, $vals)) {
                            $this->SuccessMsg="Project has been added successfully.";
                            return 1;
                        }
                        return 0;
                    //}
                    // $this->ErrorMsg="Duplicate entries not allowed, Project detail already exist";
                    // return 0;
                }
				$this->ErrorMsg="Duplicate entries not allowed, Project detail already exist";
				return 0;
            }
            return 0;
        }
    }

	public function getSelectedProject()
	{
		if(isset($_GET) && is_numeric($_GET['project_id']))
		{
			$query="SELECT project_id, project_code,organization_id,project_name,project_description,client_id,project_type,project_value,project_priority,project_size,starting_date,ending_date,phase_status
					FROM tblproject WHERE project_id = '".$_GET['project_id']."' AND organization_id = '".$_SESSION['organization_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}

	public function updateSelectedProject()
	{
		if(empty($_GET['project_id']) || !is_numeric($_GET['project_id']) ||  
		$_GET['project_id'] <= 0)
		{
            $this->ErrorMsg="Invalid project selection";
            return false;
        }
		
		if(isset($_POST) && isset($_POST['update'] ) && $_POST['update'] == "UpdateProject")
		{	
			if($this->prePreprocessor())
			{ 
				$project_code=test_input($_POST['project_code']);
                $_POST['project_code']='';
                unset($_POST['project_code']);

                $project_name=test_input($_POST['project_name']);
                $_POST['project_name']='';
                unset($_POST['project_name']);

                $client_id=test_input($_POST['client_id']);
                $_POST['client_id']='';
                unset($_POST['client_id']);

                $project_description=$_POST['project_description'];
                $_POST['project_description']='';
                unset($_POST['project_description']);

                $project_priority=$_POST['project_priority'];
                $_POST['project_priority']='';
                unset($_POST['project_priority']);

                $project_size=$_POST['project_size'];
                $_POST['project_size']='';
                unset($_POST['project_size']);

                $project_value=$_POST['project_value'];
                $_POST['project_value']='';
                unset($_POST['project_value']);

                $project_type=$_POST['project_type'];
                $_POST['project_type']='';
                unset($_POST['project_type']);

                $starting_date=dbDateFormat($_POST['starting_date']);
                $_POST['starting_date']='';
                unset($_POST['starting_date']);
				if(isset($_POST['ending_date']) && $_POST['ending_date'] !=''){
					$ending_date=dbDateFormat($_POST['ending_date']);
                	$_POST['ending_date']='';
                	unset($_POST['ending_date']);
				}else{
					$ending_date = NULL;
				}

				$phase_status=$_POST['phase_status'];
                $_POST['phase_status']='';
                unset($_POST['phase_status']);
				date_default_timezone_set("Asia/Karachi");

				$query="UPDATE tblproject SET 
						project_code = '".$project_code."',
						client_id = '".$client_id."',
						project_name = '".$project_name."',
						project_type = '".$project_type."',
						project_value = '".$project_value."',
						project_priority = '".$project_priority."',
						project_size = '".$project_size."',
						starting_date = '".$starting_date."',
						ending_date = '".$ending_date."',
						phase_status = '".$phase_status."',
						project_description = '".mysqli_real_escape_string($this->DBlink,$project_description)."',
						updated_by = '".$_SESSION['user_id']."', 
						updated_at = '".date('Y-m-d H:i:s')."' 
						WHERE project_id = '".$_GET['project_id']."' AND organization_id = '".$_SESSION['organization_id']."'";
						//echo $query;
						//exit;
					
				if($this->CustomModify($query))
				{
					$this->SuccessMsg="Record has been updated successfully.";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again later.";
				return 0;
			}
			return 0;
		}
		return 0;
	}

	public function getTeamDropDown()
    {
        $query ="SELECT team_id,team_name FROM tblteam WHERE team_status = '1'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function AssignProjectToTeam()
	{
		if(isset($_POST) && $_POST['submit'] =="assignProject")
		{
			$project_id=$_POST['project_id'];
            $_POST['project_id']='';
            unset($_POST['project_id']);

			$team_id=$_POST['team_id'];
            $_POST['team_id']='';
            unset($_POST['team_id']);

			$insert="project_id,team_id";
			$vals="'".$project_id."','".$team_id."'";
			if(!$this->GetPrexistance("tblproject_vs_team", "project_id", $project_id, "team_id", $team_id))
			{
				if($this->InsertRecord("tblproject_vs_team",$insert,$vals))
				{
					$query="SELECT * FROM tblteam_members WHERE team_id = $team_id";
					$Team = $this->CustomQuery($query);
					{

					}
					$this->SuccessMsg="Project has been assign to selected team";
					return 1;
				}
			}
			$this->ErrorMsg="Unable to assign project to selected team, Try again later!";
			return 0;
		}
		return 0;
	}

	public function getSelectedProjectName()
	{
		return $this->GetSingleField("tblproject","project_id",$_GET['project_id'],"project_name");
	}

	public function getProjectTaskList()
	{
		$query="SELECT task.*,module.module_name,phase.phase_type,users.first_name,users.last_name 
				FROM `tbltask` AS task 
				INNER JOIN tblmodule AS module ON module.module_id = task.module_id
				INNER JOIN tblphases AS phase ON phase.phase_id = task.phase_id
				INNER JOIN tblusers AS users ON users.user_id = task.resource_id 
				WHERE task.project_id = '".$_GET['project_id']."' ORDER BY task.task_title DESC";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
	}

	public function getPhase()
	{
		$query="SELECT * FROM `tblphases`";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
	}

	public function getModule()
	{
		$query="SELECT * FROM `tblmodule` WHERE project_id = '".$_GET['project_id']."'";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
	}

	public function getProjectResource()
	{
		$query="SELECT users.first_name,users.last_name,users.user_id
				FROM tblusers as users
				INNER JOIN tblproject_vs_team as pvt ON pvt.project_id = '".$_GET['project_id']."'
				INNER JOIN tblteam_members as tm ON tm.team_id = pvt.team_id
				WHERE users.user_id = tm.resource_id";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
	}

	public function CreateProjectTask()
	{
		if(isset($_POST) && $_POST['createTask'] == "CreateTask")
		{
			$project_id = $_GET['project_id'];
			$module_id = $_POST['module_id'];
			$phase_id = $_POST['phase_id'];
			$task_title = $_POST['task_title'];
			$resource_id = $_POST['resource_id'];
			$estimated_hours = $_POST['estimated_hours'];
			$due_date = $_POST['due_date'];
			$task_description = $_POST['task_description'];

			date_default_timezone_set("Asia/Karachi");

			$insert="project_id,module_id,phase_id,task_title,task_description,estimated_hours,due_date,resource_id,task_status, created_by";
			$vals="'".$project_id."','".$module_id."','".$phase_id."','".mysqli_real_escape_string($this->DBlink,$task_title)."','".mysqli_real_escape_string($this->DBlink,$task_description)."','".$estimated_hours."', '".$due_date."', '".$resource_id."','Pending', '".$_SESSION['user_id']."'";
			//echo "INSERT INTO `tbltask` ($insert) VALUES ($vals)"; exit;
			if($this->InsertRecord("tbltask",$insert,$vals))
			{
				$this->SuccessMsg="Project Task has been added.";
				return 1;
			}
			$this->ErrorMsg="Unable to create task, Try again later!";
			return 0;
		}
	}

	public function getSelectedTask()
	{
		if(isset($_GET['task_id']) && $_GET['task_id']!='')
		{
			$query="SELECT * FROM `tbltask` WHERE task_id = '".$_GET['task_id']."'";
				
			if(($data=$this->CustomQuery($query))!=NULL)
				{
					return $data;
				}
				return 0;
					
				}
	}

	public function updateSelectedTask()
	{
		if(isset($_POST))
		{
			$project_id = $_GET['project_id'];
			$module_id = $_POST['module_id'];
			$phase_id = $_POST['phase_id'];
			$task_title = mysqli_real_escape_string($this->DBlink,$_POST['task_title']);
			$resource_id = $_POST['resource_id'];
			$estimated_hours = $_POST['estimated_hours'];
			$due_date = $_POST['due_date'];
			$task_description = $_POST['task_description'];

			date_default_timezone_set("Asia/Karachi");

			$query = "UPDATE tbltask set module_id = '$module_id', phase_id='$phase_id', '".$task_title."', resource_id = '$resource_id',
						estimated_hours = '$estimated_hours', due_date = '".$due_date."', task_description = '$task_description',
						updated_by = '".$_SESSION['user_id']."', 
						updated_at = '".date('Y-m-d H:i:s')."'  
						WHERE task_id = '".$_GET['task_id']."'";
						if ($this->CustomModify($query)) 
						{
							$this->SuccessMsg = "Record Updated Successfully!";
							return 1;
						}
						$this->ErrorMsg = "Fail to update the record";
						return 0;
			
		}
	}

	public function getSelectedTaskDetail()
    {
        if(isset($_GET))
        {
            $query="SELECT * FROM tblproject_activity WHERE project_id = '".$_GET['project_id']."' AND task_id = '".$_GET['task_id']."' ORDER BY date DESC";
            if(($data = $this->CustomQuery($query))!=NULL)
            {
                return $data;
            }
            $this->ErrorMsg="Task progress detail not found.";
            return 0;
        }
    }

    public function UpdateTaskStatus()
    {
        if(isset($_POST))
        {
            $query="UPDATE tbltask SET task_status = '".$_POST['task_status']."' WHERE task_id = '".$_POST['task_id']."'";
            if($this->CustomModify($query))
            {
                return 1;
            }
            return 0;
        }
        return 0;
    }

	public function getTotalSpendHours($task_id)
	{
		$query="SELECT SUM(hour_spend) AS hour_spend FROM `tblproject_activity` WHERE task_id = ".$task_id;
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data[0]['hour_spend'];
		}
		return "0";
	}

	public function getProjectTeams()
	{
		$query="SELECT o.organization_name,p.project_id,p.project_name,p.project_code,t.team_id,t.team_name 
				FROM tblproject AS p 
				INNER JOIN tblproject_vs_team AS pvt ON pvt.project_id = p.project_id 
				INNER JOIN tblteam AS t ON t.team_id = pvt.team_id 
				INNER JOIN tblorgnization AS o ON o.organization_id = p.organization_id 
				WHERE o.organization_id = t.organization_id";
		if($_GET['page'] !=''){
			$page = $_GET['page']; 
		}else{
			$page = 1;
		} 
        $limit = 10; 
		$total = $this->RecordsInQuery($query);
		// work out the pager values  
		$pager  = Pager::getPagerData($total, $limit, $page);  
		$offset = $pager->offset;  
		$limit  = $pager->limit;  
		$page   = $pager->page;
		$this->total_pages=$pager->numPages;
		
		$query=$query." limit $offset, $limit ";
		
		if($offset >= 0){
			if(($data=$this->CustomQuery($query))!=null)
			{
				return $data;
			}
		}
		return 0;
	}

	public function getTeamRights()
	{
		$query ="SELECT  tm.tmember_id,t.team_name,u.user_id,u.first_name,u.last_name,u.username,tm.member_roll
			FROM tblteam_members AS tm
			INNER JOIN tblteam AS t ON t.team_id = tm.team_id  
			INNER JOIN tblusers AS u ON u.user_id = tm.resource_id WHERE tm.team_id = '".$_GET['team_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
	}

	public function getUserRights($user_id,$project_id)
	{
		$query="SELECT * FROM tblrights WHERE user_id = '$user_id' AND project_id = '$project_id'";
		{
			if(($data = $this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
	}

	public function assignTeamRights()
	{
		if(isset($_POST) && $_POST['submit'] == "Assign Rights")
		{
			
			$Rights = [];
			$i=0;
			foreach($_POST['user_id'] as $user_id){
				$Rights[$i]['user_id'] = $user_id;
				$i++;
			}
			$i=0;
			foreach($Rights as $row)
			{
				if(isset($_POST['add_record_'.$row['user_id']]) && $_POST['add_record_'.$row['user_id']] == '1')
				{
					$Rights[$i]['add_record'] = "1";
				}
				else{
					$Rights[$i]['add_record'] = "0";
				}
				if(isset($_POST['edit_record_'.$row['user_id']]) && $_POST['edit_record_'.$row['user_id']] == '1')
				{
					$Rights[$i]['edit_record'] = "1";
				}
				else{
					$Rights[$i]['edit_record'] = "0";
				}
				if(isset($_POST['delete_record_'.$row['user_id']]) && $_POST['delete_record_'.$row['user_id']] == '1')
				{
					$Rights[$i]['delete_record'] = "1";
				}
				else{
					$Rights[$i]['delete_record'] = "0";
				}
				if(isset($_POST['approve_record_'.$row['user_id']]) && $_POST['approve_record_'.$row['user_id']] == '1')
				{
					$Rights[$i]['approve_record'] = "1";
				}
				else{
					$Rights[$i]['approve_record'] = "0";
				}
				$i++;
			}
			
			
			
			foreach($Rights as $row){
				if($this->getUserRights($row['user_id'],$_GET['project_id']))
				{
					$query="UPDATE tblrights SET 
							add_record = '".$row['add_record']."',
							edit_record = '".$row['edit_record']."',
							delete_record = '".$row['delete_record']."',
							approve_record = '".$row['approve_record']."'
							WHERE project_id = '".$_GET['project_id']."' AND user_id = '".$row['user_id']."'";
					$this->CustomModify($query);
				}else{
					$insert="user_id,project_id,add_record,edit_record,delete_record,approve_record";
					$vals= "'".$row['user_id']."','".$_GET['project_id']."','".$row['add_record']."','".$row['edit_record']."','".$row['delete_record']."','".$row['approve_record']."'";
					$this->InsertRecord("tblrights",$insert,$vals);
				}
			}
			return 1;
			
		}
		return 0;
	}
	
}//end class.
?>