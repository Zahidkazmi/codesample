<?php
/*********************************************************
 * Name: EmployeeProfileController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing user's sessions.
 * Version: 1.0
 * Last edited: 09th jun, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class EmployeeProfileController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_EmployeeProfileController()
	{
		$this->DBDisconnect();
	}

	

	function getSecurityQuestions()
	{
		$query="SELECT security_id, question FROM tblsecurityquestion ORDER BY security_id";
			if(($data=$this->CustomQuery($query))!=null)
			{
				return $data;
			}
			$this->Alert="No security question found for account recovery";
			return 0;
	}
	

	function ValidProfile()
	{
		if(isset($_POST))
		{
			if(empty($_POST['first_name']))
			{
				$this->ErrorMsg="Please enter first name.";
				return 0;
            }
            
            if(empty($_POST['last_name']))
			{
				$this->ErrorMsg="Please enter last name.";
				return 0;
            }
            
            if(empty($_POST['mobile']))
			{
				$this->ErrorMsg="Please provide your mobile number.";
				return 0;
            }
            
            if(empty($_POST['gender']))
			{
				$this->ErrorMsg="Please select your gender.";
				return 0;
            }
        	if(empty($_POST['description']))
			{
				$this->ErrorMsg="Please provide some information about you.";
				return 0;
			}
			
			
			return 1;
		}
		return 0;
	}
	
	function UpdateMyProfile()
	{
		//echo"i am here";
		if($this->ValidProfile())
		{
            $first_name=test_input($_POST['first_name']);
            $last_name=test_input($_POST['last_name']);
			$mobile=test_input($_POST['mobile']);
			$gender=test_input($_POST['gender']);
            $bio=test_input($_POST['description']);    
            $city_id=test_input($_POST['city_id']);
            $country_id=test_input($_POST['country_id']);
			{
				$query = "UPDATE tblusers set 
						  first_name = '".$first_name."',
                          last_name = '".$last_name."',
						  mobile =  '".$mobile."',
						  gender =  '".$gender."',
                          city_id=  '".$city_id."',
						  country_id =  '".$country_id."',
						  Description = '".mysqli_real_escape_string($this->DBlink,$bio)."'						  
						  WHERE user_id ='".$_SESSION['user_id']."'";
						 
					 
				if($this->CustomModify($query)!=null)
				{
					$_SESSION['mobile']=$mobile;
					$_SESSION['gender']=$gender;
					$_SESSION['username']=$first_name." ".$last_name;
					
					$this->SuccessMsg = 'Personal Information updated successfully.';
					return 1;
				}
				$this->ErrorMsg = 'Unable to update personal information.';
				return 0;
			}
			return 0;

		}
		return 0;

    }

    //change password.
	function change_password()
	{	
		//checking for required params
		$password=md5(test_input($_POST['password']));
		$new_pass=md5(test_input($_POST['new_pass']));
		$new_pass2=md5(test_input($_POST['new_pass2']));
		if(!empty($password) && !empty($new_pass) && !empty($new_pass2) )
		{
			//match both pass
			$cur_pass=$this->GetSingleField("tblusers","user_id",$_SESSION['user_id'],"password");
			if($cur_pass!=$password)
			{
				$this->ErrorMsg="Your password is incorrect";
				return false;
			}
			if($new_pass!=$new_pass2)
			{
				$this->ErrorMsg="New passwords mismatch.";
				return false;
			}
			if($new_pass==$cur_pass)
			{
				$this->ErrorMsg="New password should be different than old password.";
				return false;
			}
			//update pass
			if($this->ModifyRecord("tblusers","user_id",$_SESSION['user_id'],"password",$new_pass))
			{
				
				$this->SuccessMsg = "Your login password updated successfully.";
				return true;
			}
			$this->ErrorMsg="Unable to update login password.";
			return false;
		} 
		return false;
	}

	function UploadMyPicture()
	{
		if($_POST['ChangePicture'] == 'ChangePicture'){
			
			if((nowUpload("image",$this->site_url.$this->image_dir,$this->upload_size_allowed,0))<='0')
				{//error 
					$this->ErrorMsg="File not supported or File size increased the maximum size allowed.";
					return 0;				
				}
					
			//upload the image file if there
			$imageFile=nowUpload("image","assets/images/user/",$this->upload_size_allowed);
			
			$query= "update tblusers set image = '".$imageFile."'where user_id='".$_SESSION['user_id']."'";
			if($this->CustomModify($query)){
				$_SESSION['user_image']= $imageFile;
				$this->SuccessMsg = "Profile picture has been updated.";
				return 1;
			}
			$this->ErrorMsg="File not uploaded, Please try some other time.";
			return 0;
		}
	}
    
	public function ShowEmployeePersonal()
   
	{

	$query="SELECT username,email, first_name, last_name,mobile,gender,security_id,image,address_Line1,description, country_name, 
			 city_name,designation FROM tblusers
			 INNER JOIN tbldesignation ON tbldesignation.designation_id  = tblusers.designation_id 
			 INNER JOIN tblcountry ON tblcountry.country_ID = tblusers.country_id 
			 INNER JOIN tblcity ON tblusers.city_id = tblcity.city_ID
			 WHERE tblusers.user_id = '".$_SESSION['user_id']."'";
			 if(($data=$this->CustomQuery($query))!=NULL)
				 {
					 return $data;
				 }

				 $this->ErrorMsg = "No Record Found";

		 }
		 
		 public function getCompanies()
    {
        $query="SELECT organization_id, organization_name FROM tblorgnization WHERE organization_status = 'Active'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }
	// public function getDesignations()
    // {
    //     $query="SELECT  designation_id, designation FROM tbldesignation Where desig_status='Active' AND organization_id = '1'";
		
    //     if(($data=$this->CustomQuery($query))!=null)
    //     {
    //         return $data;
    //     }
    //     return 0;
    // }


	public function ShowEmployeeProfile()
    {
		$query="SELECT username,first_name,last_name,email,mobile,address_Line1,image,status,description,gender from tblusers where user_id = '".$_SESSION['user_id']."'";
		if(($data=$this->CustomQuery($query))!=null)
		{
			return $data;
		}
		return 0;

	}
	public function getCountries()
    {
        $query="SELECT country_ID,country_name FROM tblcountry";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }

	public function getCities()
    {
        $query="SELECT city_ID, country_ID, city_name FROM tblcity";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }
	function IsecurityEnabled()
	{
		if($this->GetSingleField("tblusers","user_id",$_SESSION['user_id'],"security_id")!=NULL)
		{
			return 1;
		}
		return 0;
	}


	function SetSecurityQuestion()
	{
		
		if(isset($_POST) && isset($_POST['ChangeSecurity']) == 'ChangeSecurity' && isset($_POST['security_answer']) && isset($_POST['security_id'])  && is_numeric($_POST['security_id']))
		{
			$security_answer=test_input($_POST['security_answer']);
			$security_id=test_input($_POST['security_id']);
			$query="UPDATE tblusers SET security_answer = '".md5($security_answer)."',Security_id = '".$security_id."' WHERE user_id = '".$_SESSION['user_id']."'" ;
			if($this->CustomModify($query))
			{
				$this->SuccessMsg='Successfully set account secret.';
				return 1;
			}
			$this->ErrorMsg='Secret question not set, please try again!';
			return 0;
		}
		return 0;
	}
		
		
	
}//end class.
?>
