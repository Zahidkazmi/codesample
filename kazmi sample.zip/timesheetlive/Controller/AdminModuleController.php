<?php
/*********************************************************
 * Name: AdminModuleController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.0
 * Last edited: 19th May, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class AdminModuleController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminModuleController()
	{
		$this->DBDisconnect();
	}

    public function getProjects()
    {
        $query="SELECT project_name,project_id FROm tblproject";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        return 0;
    }
	function prePreprocessor()
	{
		
		if(empty($_POST['project_id']) && $_POST['project_id'] == '')
		{
			$this->ErrorMsg="Please select project.";
			return 0;
		}

        if(empty($_POST['module_name']))
		{
			$this->ErrorMsg="Please enter module name.";
			return 0;
		}
		return 1;
	}

	//
    public function getModuleLists()
    {
        $query ="SELECT m.module_id , m.module_name,p.project_name,p.project_code 
                 FROM tblmodule as m
                 INNER JOIN tblproject as p ON p.project_id = m.project_id 
                 ORDER BY m.project_id ASC";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getSelectedModule()
	{
		if(isset($_GET) && is_numeric($_GET['module_id']))
		{
			$query="SELECT module_id ,module_name,project_id FROM tblmodule WHERE module_id  = '".$_GET['module_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}

    public function AddModule()
    {
        if (isset($_POST) && $_POST['Create'] == "Create Module") {
            if ($this->prePreprocessor()) {
                $module_name=test_input($_POST['module_name']);
                $_POST['module_name']='';
                unset($_POST['module_name']);

                $project_id=test_input($_POST['project_id']);
                $_POST['project_id']='';
                unset($_POST['project_id']);

                $insert = "project_id,module_name";
                $vals = "'".$project_id."','".$module_name."'";
                if (!$this->CheckPreExist("tblmodule", "module_name", $module_name, "project_id", $project_id)) {
                    if ($this->InsertRecord("tblmodule", $insert, $vals)) {
                        $this->SuccessMsg="Module has been added successfully.";
                        return 1;
                    }
                    return 0;
                }
                $this->ErrorMsg="Module already exist, duplicate values not allowed.";
                return 0;
            }
        
            return 0;
        }
    }
	
	public function updateSelectedModule()
	{
		if(empty($_GET['module_id']) || !is_numeric($_GET['module_id']) || 
		$_GET['module_id'] <= 0)
		{
			$this->LastMsg="Invalid module selection";
			return false;
		}

		if(isset($_POST) && isset($_POST['update'] ) && $_POST['update'] == "UPDATE")
		{	
			if($this->prePreprocessor())
			{
				$module_name=test_input($_POST['module_name']);
                $_POST['module_name']='';
                unset($_POST['module_name']);

                $project_id=test_input($_POST['project_id']);
                $_POST['project_id']='';
                unset($_POST['project_id']);
				
				$_POST['update'] = '';
				unset($_POST['update']);
				$query="UPDATE tblmodule SET 
						module_name = '".$module_name."',
                        project_id = '".$project_id."'
						WHERE module_id = '".$_GET['module_id']."'";
				if($this->CustomModify($query))
				{
					$this->SuccessMsg="Record has been updated successfully.";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again later.";
				return 0;
			}
			return 0;
		}
		return 0;
	}
}//end class.
?>