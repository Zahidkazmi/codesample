<?php
/*********************************************************
 * Name: AdminLoginController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 24th March, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class AdminDesignationController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminDesignationController()
	{
		$this->DBDisconnect();
	}
	function prePreprocessor()
	{
		
		if(empty($_POST['designation']))
		{
			$this->ErrorMsg="Please enter designation.";
			return 0;
		}
		return 1;
	}

	//
    public function getDesignationLists()
    {
        $query ="SELECT designation_id,designation,desig_status, organization_name FROM tbldesignation INNER JOIN tblorgnization ON tbldesignation.organization_id = tblorgnization.organization_id ORDER BY designation_id DESC
		";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getCompanies()
    {
        $query="SELECT organization_id, organization_name FROM tblorgnization WHERE organization_status = 'Active'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }

	public function getSelectedOrganization()
    {
        $query="SELECT tblorgnization.organization_id, organization_name from tbldesignation INNER JOIN tblorgnization ON tbldesignation.organization_id = tblorgnization.organization_id";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }

    public function getSelectedDesignation()
	{
		if(isset($_GET) && is_numeric($_GET['designation_id']))
		{
			$query="SELECT organization_id,designation_id ,designation,desig_status FROM tbldesignation WHERE designation_id  ='".$_GET['designation_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}

    public function AddDesignation()
    {
        if(isset($_POST['create']) && $_POST['create'] == 'Create Designation')
        {
		
			if($this->prePreprocessor()){

				$organization_id = test_input($_POST['organization_id']);
				$_POST['organization_id']='';
				unset($_POST['organization_id']);

				$designation=test_input($_POST['designation']);
				$_POST['designation']='';
				unset($_POST['designation']);

				$insert = "organization_id, designation,desig_status";
				$vals = "'".$organization_id."','".$designation."','Active'";
				$query = "SELECT organization_id, designation FROM tbldesignation WHERE organization_id = '".$organization_id."' AND designation = '".$designation."'";
                if (($data=$this->CustomQuery($query))!=null) 
				{
					$this->ErrorMsg="Desgination already exist, duplicate entries not allowed.";
				    return 0;
                }
				else{

					if ($this->InsertRecord("tbldesignation", $insert, $vals)) {
                        $this->SuccessMsg="designation has been added successfully.";
                        return 1;
                    }
                    return 0;
				}
				
			}
        }
        return 0;
    }
	
	public function updateSelectedDesignation()
	{
		if(empty($_GET['designation_id']) || !is_numeric($_GET['designation_id']) || 
		$_GET['designation_id'] <= 0)
		{
			$this->LastMsg="Invalid Designation selection";
			return false;
		}

		if(isset($_POST) && isset($_POST['update'] ) && $_POST['update'] == "UPDATE")
		{	
			if($this->prePreprocessor())
			{
				$organization_id = test_input($_POST['organization_id']);
				$_POST['organization_id']='';
				unset($_POST['organization_id']);
				$designation=test_input($_POST['designation']);
				$_POST['designation']='';
				unset($_POST['designation']);
				$desig_status=test_input($_POST['desig_status']);
				$_POST['desig_status']='';
				unset($_POST['desig_status']);
				$_POST['update'] = '';
				unset($_POST['update']);
				$query="UPDATE tbldesignation SET
						organization_id = '".$organization_id."',
						designation = '".$designation."',
                        desig_status = '".$desig_status."'
						WHERE designation_id = '".$_GET['designation_id']."'";
					
				if($this->CustomModify($query))
				{
					$this->SuccessMsg="Record has been updated successfully.";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again later.";
				return 0;
			}
			return 0;
		}
		return 0;
	}
}//end class.
?>