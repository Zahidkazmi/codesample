<?php
/*********************************************************
 * Name: AdminLoginController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 24th March, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class EmployeeController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_EmployeeController()
	{
		$this->DBDisconnect();
	}

    function getPageMenu($total_pages, $current_page, $thispage, $params)
	{
		$Html='';
		if($total_pages>1)
		{
			if (($total_pages<=1) || ($current_page<=1)){
				$prev=$thispage.$params."/1";
			}else{
				$prev=$thispage.$params."/".($current_page-1);
			}
			if (($total_pages<=1) || ($current_page==$total_pages)){
				$next=$thispage.$params."/".($total_pages);
			}else{
				$next=$thispage.$params."/".($current_page+1);
			}
			
			
			$link_limit=5;
			$start=1;
			$end=$link_limit;
			if($current_page>$link_limit){
				$start=$current_page+1;	
				$end=$start+$link_limit;
			}
			if($end > $total_pages){
				$end=$total_pages;
			}
			$pages='';
			for ($i=$start;$i<=$end;$i++){
				if($i==$current_page){
					$pages.='<li class="page-item active"><a class="page-link" href="javascript:void()">'.$i.'</a></li>';
				}else{
					$pages.='<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/'.$i.'">'.$i.'</a></li>';
				}
				
				/*if($i<$end){
					$pages.=' | ';
				}*/
			}
			
			if($current_page == 1){
	
				$Html.='<!--Page Area-->
						<li class="page-item"><a class="page-link" href="javascript:void(0)">Start</a></li>
						<li class="page-item page-indicator"><a class="page-link" href="javascript:void(0)"><i class="fa fa-angle-double-left"></i> Prev</a></li>
						'.$pages.'
						<li class="page-item page-indicator"><a class="page-link" href="'.$next.'">Next<i class="fa fa-angle-double-right"></i></a></li>
						<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/'.$total_pages.'">End</a></li>
						';	
			}else if($current_page == $total_pages){
				
				$Html.='<!--Page Area-->
						<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/1">Start</a></li>
						<li class="page-item page-indicator"><a class="page-link" href="'.$prev.'"><i class="fa fa-angle-double-left"></i> Prev</a></li>
						'.$pages.'
						<li class="page-item page-indicator"><a class="page-link" href="javascript:void(0)">Next<i class="fa fa-angle-double-right"></i></a></li>
						<li class="page-item"><a class="page-link" href="javascript:void(0)">End</a></li>
						';	
			}else{
				$Html.='<!--Page Area-->
						<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/1">Start</a></li>
						<li class="page-item page-indicator"><a class="page-link" href="'.$prev.'"><i class="fa fa-angle-double-left"></i>Prev</a></li>
						'.$pages.'
						<li class="page-item page-indicator"><a class="page-link" href="'.$next.'">Next<i class="fa fa-angle-double-right"></i></a></li>
						<li class="page-item"><a class="page-link" href="'.$thispage.$params.'/'.$total_pages.'">End</a></li>
						';
			}
					
		}
		return $Html;
    }

	
    public function getCountOfAllocatedTasks()
    {
        $query="SELECT COUNT(*) as cnt FROM tbltask WHERE resource_id = '".$_SESSION['user_id']."'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

    public function getCountOfProgressTasks($task_status,$project_id)
    {
        $query="SELECT COUNT(*) as cnt FROM tbltask WHERE resource_id = '".$_SESSION['user_id']."' AND task_status = '$task_status' AND project_id = '$project_id'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

	public function getCountOfMemberProgressTasks($task_status)
    {
        $query="SELECT COUNT(*) as cnt FROM tbltask WHERE resource_id = '".$_SESSION['user_id']."' AND task_status = '$task_status'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

    public function getCountOfTasksBYProject($project_id)
    {
        $query="SELECT COUNT(*) as cnt FROM tbltask WHERE resource_id = '".$_SESSION['user_id']."' AND project_id = '$project_id'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

    public function getCountOfProgressTasksBYProject($task_status,$project_id)
    {
        $query="SELECT COUNT(*) as cnt FROM tbltask WHERE resource_id = '".$_SESSION['user_id']."' AND task_status = '$task_status' AND project_id = '$project_id'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

    public function getassignedProjects()
    {
        $query ="SELECT project.project_id,project.project_code,project.project_name,project.project_description,client.client_name,client.client_address,tm.team_id 
                 FROM `tblproject` AS project 
                 INNER JOIN tblproject_vs_team AS pvt ON project.project_id = pvt.project_id 
                 INNER JOIN tblteam_members AS tm ON tm.team_id = pvt.team_id
                 INNER JOIN tblclients AS client ON client.client_id = project.client_id 
                 WHERE tm.resource_id='".$_SESSION['user_id']."'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

    public function getProjectTeam($team_id)
    {
        $query="SELECT users.first_name,users.last_name,users.image 
                FROM tblusers AS users
                INNER JOIN tblteam_members AS tm ON tm.resource_id = users.user_id
                WHERE tm.team_id = '$team_id'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        return 0;
    }

    public function IsProjectLead()
	{
        $query="SELECT member.member_roll 
                FROM `tblteam_members` AS member 
                INNER JOIN tblproject_vs_team AS pvt ON pvt.team_id = member.team_id
                INNER JOIN tblusers AS users ON users.user_id = member.resource_id
                WHERE pvt.project_id='".$_GET['id']."' AND member.resource_id = '".$_SESSION['user_id']."'";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			if($data[0]['member_roll'] == 'Lead')
            {
                return 1;
            }
            return 0;
		}
		return 0;
	}


	//check team lead

	public function GetProjectLead()
	{
        $query="SELECT member_roll FROM tblteam_members WHERE member_roll = 'Lead' AND resource_id= '".$_SESSION['user_id']."'";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			if($data[0]['member_roll'] == 'Lead')
            {
                return 1;
            }
            return 0;
		}
		return 0;
	}


	//get employee report

	public function getEmployeReport()
    {
        $query ="SELECT t.*,p.project_name, u.first_name, u.last_name, m.module_name, ph.phase_type
		FROM tbltask AS t
		INNER JOIN tblproject AS p ON p.project_id = t.project_id
		INNER JOIN tblusers AS u ON u.user_id = t.resource_id
		INNER JOIN tblproject_vs_team AS pt ON pt.project_id = t.project_id
		INNER JOIN tblteam_members AS tm ON tm.team_id = pt.team_id
        INNER JOIN tblmodule as m ON m.module_id = t.module_id
        INNER JOIN tblphases as ph ON ph.phase_id = t.phase_id
		WHERE tm.resource_id = '".$_SESSION['user_id']."' AND tm.member_roll='Lead' AND p.organization_id='".$_SESSION['organization_id']."'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getTaskActivityDetail($task_id)
	{

		$query="SELECT MIN(start_date) AS `start_date`, MAX(end_date) AS `end_Date`, SUM(pa.hour_spend) AS `hour_spend` FROM tbltask AS t
				INNER JOIN tblproject_activity AS pa ON t.task_id = pa.task_id
				WHERE pa.task_id = '$task_id'";
				
		if(($data = $this->CustomQuery($query))!=NULL)
		{
			//$array = array($data[0]['hour_spend'], $data[0]['start_date'], $data[0]['end_date']);
			return $data;
		}
	}

    //return selected fileds.
    public function getPhases()
    {
        $query ="SELECT phase_id,phase_type  FROM tblphases";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="Phases not defined.";
        return 0;
    }

    //return all fileds.
    public function getPhase()
	{
		$query="SELECT * FROM `tblphases`";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
	}

	public function getModule()
	{
		$query="SELECT * FROM `tblmodule` WHERE project_id = '".$_GET['id']."'";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
	}

    public function getProjectResource()
	{
		$query="SELECT users.first_name,users.last_name,users.user_id
				FROM tblusers as users
				INNER JOIN tblproject_vs_team as pvt ON pvt.project_id = '".$_GET['id']."'
				INNER JOIN tblteam_members as tm ON tm.team_id = pvt.team_id
				WHERE users.user_id = tm.resource_id";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
	}

    public function getSelectedProjectName()
	{
		return $this->GetSingleField("tblproject","project_id",$_GET['id'],"project_name");
	}

	public function CreateProjectTask()
	{
		if(isset($_POST) && $_POST['createTask'] == "CreateTask")
		{
			$project_id = $_GET['id'];
			$task_title = $_POST['task_title'];
			$module_id = $_POST['module_id'];
			$phase_id = $_POST['phase_id'];
			$resource_id = $_POST['resource_id'];
			$estimated_hours = $_POST['estimated_hours'];
			$due_date = $_POST['due_date'];
			$task_description = $_POST['task_description'];
			
			date_default_timezone_set("Asia/Karachi");

			$insert="project_id,module_id,phase_id,task_title,task_description,estimated_hours,due_date,resource_id,task_status, created_by";
			$vals="'".$project_id."','".$module_id."','".$phase_id."','".mysqli_real_escape_string($this->DBlink,$task_title)."','".mysqli_real_escape_string($this->DBlink,$task_description)."','".$estimated_hours."', '".$due_date."', '".$resource_id."','Pending', '".$_SESSION['user_id']."'";
			//echo "INSERT INTO `tbltask` ($insert) VALUES ($vals)"; exit;
			if($this->InsertRecord("tbltask",$insert,$vals))
			{
				$this->SuccessMsg="Project Task has been added.";
				return 1;
			}
			$this->ErrorMsg="Unable to create task, Try again later!";
			return 0;
		}
	}

    public function getMemberProjectTasksList()
    {
        $query="SELECT task.*,module.module_name,phase.phase_type,users.first_name,users.last_name 
                FROM `tbltask` AS task 
                INNER JOIN tblmodule AS module ON module.module_id = task.module_id
                INNER JOIN tblphases AS phase ON phase.phase_id = task.phase_id
                INNER JOIN tblusers AS users ON users.user_id = task.resource_id
                WHERE task.project_id='".$_GET['id']."' AND task.resource_id = '".$_SESSION['user_id']."'
                ORDER BY task.task_id DESC";
        if($_GET['page'] !=''){
			$page = $_GET['page']; 
		}else{
			$page = 1;
		} 
        $limit = 10; 
		$total = $this->RecordsInQuery($query);
		// work out the pager values  
		$pager  = Pager::getPagerData($total, $limit, $page);  
		$offset = $pager->offset;  
		$limit  = $pager->limit;  
		$page   = $pager->page;
		$this->total_pages=$pager->numPages;
		
		$query=$query." limit $offset, $limit ";
		
		if($offset >= 0){
			if(($data=$this->CustomQuery($query))!=null)
			{
				return $data;
			}
		}
        $this->ErrorMsg="No tasks list found.";
        return 0;
    }

    public function getOverallProjectTasksList()
    {
        $query="SELECT task.*,module.module_name,phase.phase_type,users.first_name,users.last_name 
                FROM `tbltask` AS task 
                INNER JOIN tblmodule AS module ON module.module_id = task.module_id
                INNER JOIN tblphases AS phase ON phase.phase_id = task.phase_id
                INNER JOIN tblusers AS users ON users.user_id = task.resource_id
                WHERE task.project_id='".$_GET['id']."' ORDER BY task.task_id DESC"; 
        if($_GET['page'] !=''){
			$page = $_GET['page']; 
		}else{
			$page = 1;
		} 
        $limit = 10; 
		$total = $this->RecordsInQuery($query);
		// work out the pager values  
		$pager  = Pager::getPagerData($total, $limit, $page);  
		$offset = $pager->offset;  
		$limit  = $pager->limit;  
		$page   = $pager->page;
		$this->total_pages=$pager->numPages;
		
		$query=$query." limit $offset, $limit ";
		
		if($offset >= 0){
			if(($data=$this->CustomQuery($query))!=null)
			{
				return $data;
			}
		}
        $this->ErrorMsg="No tasks list found.";
        return 0;
    }


	public function getAllProjectTasksList()
    {
        $query="SELECT t.*,p.project_id,p.project_name, u.first_name, u.last_name, m.module_name, ph.phase_type
		FROM tbltask AS t
		INNER JOIN tblproject AS p ON p.project_id = t.project_id
		INNER JOIN tblusers AS u ON u.user_id = t.resource_id
		INNER JOIN tblproject_vs_team AS pt ON pt.project_id = t.project_id
		INNER JOIN tblteam_members AS tm ON tm.team_id = pt.team_id
        INNER JOIN tblmodule as m ON m.module_id = t.module_id
        INNER JOIN tblphases as ph ON ph.phase_id = t.phase_id
		WHERE tm.resource_id = '".$_SESSION['user_id']."' AND p.organization_id='".$_SESSION['organization_id']."'"; 
       
			if(($data=$this->CustomQuery($query))!=null)
			{
				return $data;
			}
        $this->ErrorMsg="No tasks list found.";
        return 0;
    }

    public function getAssignedTasksList()
    {
        $query="SELECT task.*,module.module_name,phase.phase_type,project.project_name 
                FROM `tbltask` AS task 
                INNER JOIN tblmodule AS module ON module.module_id = task.module_id
                INNER JOIN tblphases AS phase ON phase.phase_id = task.phase_id
                INNER JOIN tblusers AS users ON users.user_id = task.resource_id
                INNER JOIN tblproject AS project ON project.project_id = task.project_id
                WHERE task.resource_id = '".$_SESSION['user_id']."' ORDER BY task.task_id DESC";
        // if(($data=$this->CustomQuery($query))!=NULL)
        // {
        //     return $data;
        // }

		if($_GET['page'] !=''){
			$page = $_GET['page']; 
		}else{
			$page = 1;
		} 
        $limit = 15; 
		$total = $this->RecordsInQuery($query);
		// work out the pager values  
		$pager  = Pager::getPagerData($total, $limit, $page);  
		$offset = $pager->offset;  
		$limit  = $pager->limit;  
		$page   = $pager->page;
		$this->total_pages=$pager->numPages;
		
		$query=$query." limit $offset, $limit ";
		
		if($offset >= 0){
			if(($data=$this->CustomQuery($query))!=null)
			{
				return $data;
			}
		}
		
        $this->ErrorMsg="No tasks list found.";
        return 0;
    }

    public function UpdateTaskProgress()
    {
        if(isset($_POST) && isset($_POST['update']) && $_POST['update'] == "UPDATE")
        {
            $insert="project_id,task_id,phase_id,module_id,start_date,end_date,hour_spend,description,task_status,date";
            $vals="'".$_GET['project_id']."','".$_GET['task_id']."','".$_GET['phase_id']."','".$_GET['module_id']."','".dbDateFormat($_POST['start_date'])."','".dbDateFormat($_POST['end_date'])."','".$_POST['hour_spend']."','".mysqli_real_escape_string($this->DBlink,$_POST['description'])."','".$_POST['task_status']."',NOW()";
            //echo "INSERT INTO `tblproject_activity` ($insert) VALUES ($vals)"; exit;
            if($this->InsertRecord("tblproject_activity",$insert,$vals))
            {
                $this->CustomQuery("UPDATE tbltask SET task_status = '".$_POST['task_status']."' 
                                    WHERE task_id = '".$_GET['task_id']."'");
                // Check for on hold.
                if($_POST['task_status'] == "Inprogress")
                {
                    $this->CustomQuery("UPDATE tbltask SET task_status = 'On Hold' 
                    WHERE task_id != '".$_GET['task_id']."' AND resource_id = '".$_SESSION['user_id']."' AND task_status ='Inprogress'");
                }
                $this->SuccessMsg="Task progress has been submitted.";
                return 1;
            }
            $this->ErrorMsg="Unable to submit task progress, Please try again!";
            return 0;
        }
        return 0;
    }

    public function getSelectedTaskDetail()
    {
        if(isset($_GET))
        {
            $query="SELECT * FROM tblproject_activity WHERE project_id = '".$_GET['project_id']."' AND task_id = '".$_GET['task_id']."' ORDER BY date DESC";
            if(($data = $this->CustomQuery($query))!=NULL)
            {
                return $data;
            }
            $this->ErrorMsg="Task progress detail not found.";
            return 0;
        }
    }

    public function UpdateTaskStatus()
    {
        if(isset($_POST))
        {
            $query="UPDATE tbltask SET task_status = '".$_POST['task_status']."' WHERE task_id = '".$_POST['task_id']."'";
            if($this->CustomModify($query))
            {
                return 1;
            }
            return 0;
        }
        return 0;
    }

    public function getSelectedTask()
	{
		if(isset($_GET['task_id']) && $_GET['task_id']!='')
		{
			$query="SELECT * FROM `tbltask` WHERE task_id = '".$_GET['task_id']."'";
				
			if(($data=$this->CustomQuery($query))!=NULL)
				{
					return $data;
				}
				return 0;
					
				}
	}

	public function updateSelectedTask()
	{
		if(isset($_POST))
		{
			$project_id = $_GET['project_id'];
			$module_id = $_POST['module_id'];
			$phase_id = $_POST['phase_id'];
			$task_title = mysqli_real_escape_string($this->DBlink,$_POST['task_title']);
			$resource_id = $_POST['resource_id'];
			$estimated_hours = $_POST['estimated_hours'];
			$due_date = $_POST['due_date'];
			$task_description = $_POST['task_description'];

			date_default_timezone_set("Asia/Karachi");

			$query = "UPDATE tbltask set module_id = '$module_id', 
						phase_id='$phase_id', 
						task_title = '$task_title',
						resource_id = '$resource_id',
						estimated_hours = '$estimated_hours', 
						due_date = '$due_date', 
						task_description = '$task_description',  
						updated_by = '".$_SESSION['user_id']."', 
						updated_at = '".date('Y-m-d H:i:s')."' 
						WHERE task_id = '".$_GET['task_id']."'";
						//echo $query;
						//exit;
						if ($this->CustomModify($query)) 
						{
							$this->SuccessMsg = "Record Updated Successfully!";
							return 1;
						}
						$this->ErrorMsg = "Fail to update the record";
						return 0;
			
		}
	}

    public function getTotalSpendHours($task_id)
	{
		$query="SELECT SUM(hour_spend) AS hour_spend FROM `tblproject_activity` WHERE task_id = ".$task_id;
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data[0]['hour_spend'];
		}
		return "0";
	}

    public function getUserRightsByProject()
    {
        $query="SELECT add_record,edit_record,approve_record,delete_record 
                FROM tblrights 
                WHERE user_id = '".$_SESSION['user_id']."' 
                AND project_id = '".$_GET['id']."'";
		if(($data = $this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
		
    }
	
}//end class.
?>