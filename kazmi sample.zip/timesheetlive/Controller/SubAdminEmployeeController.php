<?php
/*********************************************************
 * Name: SubAdminEmployeeController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing sub admin end organization based employee controls.
 * Version: 1.2
 * Last edited: 1st June, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class SubAdminEmployeeController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminClientController()
	{
		$this->DBDisconnect();
	}

	
	function isUsernameAndEmailTaken()
	{
		if (isset($_POST)) 
		{
			$username = $_POST['username'];
			$email = $_POST['email'];
			
			$query="SELECT username, email FROM tblusers WHERE  username='".$username."' AND email = '".$email."'";

			if(($this->CustomQuery($query))!=null){
	
				return 0;
	
			}
	
			return 1;	
		}

	}

	// function prePreprocessor()
	// {
		
	// 	if(empty($_POST['client_name']))
	// 	{
	// 		$this->ErrorMsg="Please enter client name.";
	// 		return 0;
	// 	}

	// 	if(empty($_POST['client_email']))
	// 	{
	// 		$this->ErrorMsg="Please enter client Email.";
	// 		return 0;
	// 	}
		
	// 	if(!emailsyntax_is_valid($_POST['client_email']))
	// 	{
	// 		$this->ErrorMsg="Please enter valid email address.";
	// 		return 0;
	// 	}
		
	// 	if(empty($_POST['contact_person']))
	// 	{
	// 		$this->ErrorMsg="Please enter your client contact.";
	// 		return 0;
	// 	}
	// 	return 1;
	// }


	public function getDesignations()
    {
        $query="SELECT  designation_id, designation FROM tbldesignation Where desig_status='Active' AND organization_id = '1'";
		
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }

	public function getCompanies()
    {
		$organization_id = $_SESSION['organization_id'];
        $query="SELECT organization_id, organization_name FROM tblorgnization WHERE organization_status = 'Active' AND organization_id='1'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }



    public function getCountries()
    {
        $query="SELECT country_id,country_name FROM tblcountry";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }

	public function getCities()
    {
        $query="SELECT city_ID, country_ID, city_name FROM tblcity";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }
     
    public function getEmployeeLists()
    {
          
        $query="SELECT * FROM tblusers WHERE organization_id = '".$_SESSION['organization_id']."'";
        if(($data=$this->CustomQuery($query))!=NULL)
         {
             return $data;
         }
         $this->ErrorMsg = "No Record Found";

           
   }

    public function getEmployeeProfileData()
     {
           if(isset($_GET))
            {
                $query="SELECT organization_name, tblusers.*,
				designation, desig_status, country_name, city_name FROM tblorgnization
				INNER JOIN tblusers ON tblorgnization.organization_id = tblusers.organization_id
				INNER JOIN tbldesignation ON tblusers.designation_id = tbldesignation.designation_id
				INNER JOIN tblcountry ON tblcountry.country_ID = tblusers.country_id 
				INNER JOIN tblcity ON tblusers.city_id = tblcity.city_ID
				WHERE tblusers.user_id = '".$_GET['id']."'";
				
                if(($data=$this->CustomQuery($query))!=NULL)
                    {
                        return $data;
                    }

                    $this->ErrorMsg = "No Record Found";

            }
    }


    
    //image upload function

    function UploadEmployeePicture()
	{
		if($_POST['ChangePicture'] == 'ChangePicture'){
			 if((nowUpload("image",$this->site_url.$this->image_dir,$this->upload_size_allowed,0))<='0')
			 {//error 
			 	$this->ErrorMsg="File not supported or File size increased the maximum size allowed.";
			 	return 0;				
			 }
					
			//upload the image file if there
			$imageFile=nowUpload("image","assets/images/user/",$this->upload_size_allowed);			
			$query= "UPDATE tblusers SET image = '".$imageFile."' WHERE user_id='".$_GET['id']."'";
			if($this->CustomModify($query)){
				$this->SuccessMsg = "Profile picture has been updated.";
				return 1;
			}
			$this->ErrorMsg="File not uploaded, Please try some other time.";
			return 0;
		}
	}

	function updateEmployeeProfile()
	{
		$organization_id = test_input($_POST['organization_id']);
		$username = test_input($_POST['username']);
		$email = test_input($_POST['email']);
		$status = test_input($_POST['status']);
		$first_name = test_input($_POST['first_name']);
		$last_name = test_input($_POST['last_name']);
		$mobile = test_input($_POST['mobile']);
		$gender = test_input($_POST['gender']);
		$address = $_POST['address_Line1'];
		$Paddress = $_POST['address_Line2'];
		$country_id = test_input($_POST['country']);
		$city_id = test_input($_POST['city']);
		$zipcode = test_input($_POST['zipCode']);
		$bio = $_POST['description'];
		$employment_status = test_input($_POST['employment_status']);
		$designation_id = test_input($_POST['designation_id']);
		$salary = test_input($_POST['salary']);
		$rate_per_hour = test_input($_POST['rate_per_hour']);
		$over_heads = test_input($_POST['over_heads']);

		  $query = "UPDATE tblusers SET 
		  			username = '".$username."', 
					email = '".$email."', 
					status = '".$status."', 
					first_name = '".$first_name."',
					last_name = '".$last_name."', 
					mobile = '".$mobile."',
					gender = '".$gender."',
					address_Line1 = '".$address."',
					address_Line2 = '".$Paddress."', 
					country_id = '".$country_id."', 
					city_id = '".$city_id."', 
					zipCode = '".$zipcode."', 
					description = '".mysqli_real_escape_string($this->DBlink,$bio)."', 
					organization_id = '".$organization_id."',
					salary = '".$salary."',
					rate_per_hour = '".$rate_per_hour."',
					over_heads = '".$over_heads."', 
					employment_status = '".$employment_status."', 
					designation_id = '".$designation_id."' 
					where user_id = '".$_GET['id']."'";  
					
				if ($this->CustomModify($query)) 
				{
					$this->SuccessMsg = "Record has been updated successfully";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again.";
				return 0;
	}

	function addEmployee()
	{
		if((nowUpload("image",$this->site_url.$this->image_dir,$this->upload_size_allowed,0))<='0')

			{//error 
				$this->ErrorMsg="File not supported or File size increased the maximum size allowed.";
				return 0;				
			}
					
			//upload the image file if there
		$imageFile=nowUpload("image","assets/images/user/",$this->upload_size_allowed);

		
		$organization_id = test_input($_POST['company']);
		$username = test_input($_POST['username']);
		$email = test_input($_POST['email']);
		$password = hash('md5', $_POST['password']);
		$status = test_input($_POST['status']);
		$first_name = test_input($_POST['first_name']);
		$last_name = test_input($_POST['last_name']);
		$mobile = test_input($_POST['mobile']);
		$gender = test_input($_POST['gender']);
		$address = test_input($_POST['address_line1']);
		$Paddress = test_input($_POST['address_line2']);
		$country_id = test_input($_POST['country']);
		$city_id = test_input($_POST['city']);
		$zipcode = test_input($_POST['zipcode']);
		$bio = test_input($_POST['description']);
		$created_on = date('y/m/d');
		$employment_status = test_input($_POST['employment_status']);
		$designation_id = test_input($_POST['designation_id']);
		$salary = test_input($_POST['salary']);
		$rate_per_hour = test_input($_POST['rate_per_hour']);
		$over_heads = test_input($_POST['over_heads']);
		
        $insert = "username,email,first_name,last_name,password,status,gender,image,address_line1,address_line2,city_id,zipCode,country_id,mobile,description,created_on,organization_id,designation_id, salary, rate_per_hour, over_heads, employment_status";
	    $vals="'".$username."','".$email."','".$first_name."','".$last_name."','".$password."','".$status."','".$gender."','".$imageFile."','".$address."','".$Paddress."','".$city_id."','".$zipcode."','".$country_id."','".$mobile."','".$bio."','".$created_on."','".$organization_id."','".$designation_id."', '".$salary."', '".$rate_per_hour."', '".$over_heads."', '".$employment_status."'";
		if(!$this->CheckPreExist("tblusers", "username", $username, "email", $email)){
			if ($user_id = $this->InsertRecord("tblusers",$insert,$vals)) 
			{
					$this->SuccessMsg = "User has been added successfully.";
					return 1;
			}
			$this->ErrorMsg="Unable to insert new user, Please try again later!";
			return 0;
		}
				
	}
	
} //end class.
?>