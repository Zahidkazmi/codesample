<?php
/*********************************************************
 * Name: LoginController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing user's sessions.
 * Version: 1.0
 * Last edited: 31th March, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class LoginController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_LoginController()
	{
		$this->DBDisconnect();
	}

	public function makeSlug(String $string){
        $string = strtolower($string);
        $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', $string);
        return $slug;
    }

	function LoginPreprocessor()
	{
		
		if(empty($_POST['Email']))
		{
			$this->ErrorMsg="Please enter your Email.";
			return 0;
		}
		
		if(empty($_POST['pass']))
		{
			$this->ErrorMsg="Please enter your login password.";
			return 0;
		}

		if($_POST['Email'] == '1' && $_POST['pass'] == '1')
		{
			$this->ErrorMsg="Invalid email and password.";
			return 0;
		}

		if($_POST['Email'] == '1=1' && $_POST['pass'] == '1=1')
		{
			$this->ErrorMsg="Invalid email and password.";
			return 0;
		}
		
		
		return 1;


	}
	//login the user
	function verfiy_login_info()
	{ 
		if(isset($_POST) && isset($_POST['Login']) && $_POST['Login'] == "Log In")
		{
			if($this->LoginPreprocessor())
			{
				
				$Email = $_POST['Email'];
				$Pass = md5($_POST['pass']);
					
				if($this->CheckUser("tblusers", "Email", $Email, "password", $Pass) || $this->CheckUser("tblusers", "username", $Email, "password", $Pass) )
				{
					//all verified
					if( ($this->GetSingleField("tblusers","email",$Email,"status") == 'Active') || ($this->GetSingleField("tblusers","username",$Email,"status") == 'Active') )
					{
						$query="SELECT u.user_id,u.email,u.username,u.first_name,u.last_name,u.gender,u.image,u.employment_status,u.organization_id,d.designation,o.organization_name
								FROM `tblusers` AS u, `tbldesignation` AS d, `tblorgnization` AS o
								WHERE '".$Email."' IN (u.username,u.email)
								AND u.designation_id = d.designation_id
								AND u.organization_id = o.organization_id
								AND u.status = 'Active'";
								if(($data=$this->CustomQuery($query))!=null)
								{
									$_SESSION['user_id']=$data[0]['user_id'];
									$_SESSION['email']=$data[0]['email'];
									$_SESSION['username']=$data[0]['username'];
									$_SESSION['user_image']=$data[0]['image'];
									$_SESSION['gender']=$data[0]['gender'];
									$_SESSION['FullName']=$data[0]['first_name']." ".$data[0]['last_name'];
									$_SESSION['organization_id']=$data[0]['organization_id'];
									$_SESSION['organization_name'] = $data[0]['organization_name'];
									$_SESSION['employment_status']=$data[0]['employment_status'];	
									$_SESSION['designation'] = $data[0]['designation'];
									$_SESSION['user_role'] = $data[0]['user_role'];
									return true;
								}
								else
								{
									$this->ErrorMsg="Account is not active";
									return 0;
								}	
					
							
					}
					$this->ErrorMsg="Wrong email or username and password";
					return false;
				}
				else if($this->GetSingleField("tblusers","Email",$Email,"Email") == NULL || $this->GetSingleField("tblusers","username",$Email,"username") == NULL)
				{
					$this->ErrorMsg="Invalid Login Information";
					return false;
				}
				else if($this->GetSingleField("tblusers","Email",$Email,"password") != $Pass)
				{
					$this->ErrorMsg="Wrong password";
					return false;
				}
				else
				{
					$this->ErrorMsg="Invalid login information";
					return false;
				}			
			}	
			return false;
		}
		return false;
	}

	//validate users is logged in 
	function is_logged_in()
	{
		if((isset($_SESSION['user_id'])) && (!empty($_SESSION['user_id'])))
		{
			if(($this->GetRecord("tblusers", "user_id", $_SESSION['user_id']))==null)
			{
				$this->ErrorMsg="User not in database.";
				return false;
			}
			return true;
		}
		
		return false;
	}

	function isEmailTaken($Email)
	{
		$query="SELECT Email from tblusers where  Email='".$Email."'";
		if(($this->CustomQuery($query))!=null){
			return 0;
		}
		return 1;
	}

	



	function GetSecurityQuestion()
	{
		if(isset($_POST) && isset($_POST['Question']) == 'Question' && isset($_POST['RegisteredEmail']) )
		{
			if(!emailsyntax_is_valid($_POST['RegisteredEmail'])) 
			{
				$this->ErrorMsg="Please enter a valid email address.";
				return 0;
			}
			$Email=test_input($_POST['RegisteredEmail']);
			if(($this->GetSingleField("tblusers","email",$Email,"status") == 'Active') && ($this->GetSingleField("tblusers","email",$Email,"email"))){
				$query="SELECT question FROM tblsecurityquestion as a, tblusers as b WHERE b.email='".$Email."' AND b.status = 'Active' AND a.security_id = b.security_id";
				if(($data=$this->CustomQuery($query))!=null)
				{
					return $data[0]['question'];
				}
				$this->ErrorMsg="Account Secret is not enable for given email.";
				return 0;
			}
			$this->ErrorMsg="Please enter registered email.";
			return 0;
		}
		return 0;
	}

	function SecurityLogin()
	{
		if(isset($_POST) && isset($_POST['SecAnswer'])){
			if($_POST != NULL && isset($_POST['SecAnswer']) && $_POST['SecAnswer']!= '' && $_POST['SecAnswer'] == 'Answer' && $_POST['RegisteredEmail'] != NULL && emailsyntax_is_valid($_POST['RegisteredEmail']))
			{
				$Email = $_POST['RegisteredEmail'];
				$SecurityAnswer = test_input($_POST['SecurityAnswer']);
				$query="SELECT security_answer FROM tblusers WHERE email='".$Email."' AND security_answer = '".md5($SecurityAnswer)."' AND status = 'Active'";
				
				if(($data=$this->CustomQuery($query))!=null)
				{					
					$query="SELECT u.user_id,u.email,u.username,u.first_name,u.last_name,u.gender,u.image,u.employment_status,u.organization_id,d.designation,o.organization_name
							FROM `tblusers` AS u, `tbldesignation` AS d, `tblorgnization` AS o
							WHERE '".$Email."' IN (u.username,u.email)
							AND u.designation_id = d.designation_id
							AND u.organization_id = o.organization_id
							AND u.status = 'Active'";
					if(($data=$this->CustomQuery($query))!=null)
					{
						$Pass = md5("Password@123");
						$query="UPDATE tblusers SET password = '".$Pass."' WHERE user_id = '".$data[0]['user_id']."'";
						$this->CustomModify($query);

						$_SESSION['user_id']=$data[0]['user_id'];
						$_SESSION['email']=$data[0]['email'];
						$_SESSION['username']=$data[0]['username'];
						$_SESSION['user_image']=$data[0]['image'];
						$_SESSION['gender']=$data[0]['gender'];
						$_SESSION['FullName']=$data[0]['first_name']." ".$data[0]['last_name'];
						$_SESSION['organization_id']=$data[0]['organization_id'];
						$_SESSION['organization_name'] = $data[0]['organization_name'];
						$_SESSION['employment_status']=$data[0]['employment_status'];	
						$_SESSION['designation'] = $data[0]['designation'];
						$_SESSION['user_role'] = $data[0]['user_role']; 
						$_SESSION['reset_code'] = "Password@123";// 
						return 'userprofile';
					}
					else
					{
							$this->ErrorMsg="Your account is blocked.";
							return 0;
					}	
				}
				$this->ErrorMsg='Security answer mismatched, please try again.';
				return 0;
			}
		}
		return 0;
		
	}

	function getPass()
	{
		return $this->GetSingleField("tblusers","user_id",$_SESSION['user_id'],"password");
	}

	function getSecurity()
	{
		return $this->GetSingleField("tblusers","user_id",$_SESSION['user_id'],"security_id");
	}
		
	
}//end class.
?>