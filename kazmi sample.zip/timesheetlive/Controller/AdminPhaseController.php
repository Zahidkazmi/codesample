<?php
/*********************************************************
 * Name: AdminLoginController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 24th March, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class AdminPhaseController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminPhaseController()
	{
		$this->DBDisconnect();
	}
	function prePreprocessor()
	{
		
		if(empty($_POST['phase_type']))
		{
			$this->ErrorMsg="Please enter phase type name.";
			return 0;
		}
		return 1;
	}

	//
    public function getPhaseLists()
    {
        $query ="SELECT phase_id ,phase_type FROM tblphases ORDER BY phase_id  DESC";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getCompanies()
    {
        $query="SELECT organization_id, organization_name FROM tblorgnization WHERE organization_status = 'Active'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }

	public function getSelectedOrganization()
    {
        $query="SELECT tblorgnization.organization_id, organization_name from tbldesignation INNER JOIN tblorgnization ON tbldesignation.organization_id = tblorgnization.organization_id";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return 0;
    }

	public function getSelectedPhase()
	{
		if(isset($_GET) && is_numeric($_GET['phase_id']))
		{
			$query="SELECT phase_id ,phase_type,organization_id FROM tblphases WHERE phase_id  = '".$_GET['phase_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}

    public function AddPhase()
    {
        if (isset($_POST) && $_POST['Create'] == "Create Phase") {
            if ($this->prePreprocessor()) {
                $phase_type=test_input($_POST['phase_type']);
                $_POST['phase_type']='';
                unset($_POST['phase_type']);

				$organization_id=test_input($_POST['organization_id']);
                $_POST['organization_id']='';
                unset($_POST['organization_id']);

                $insert = "phase_type, organization_id";
                $vals = "'".$phase_type."', '".$organization_id."'";
                if (!$this->CheckPreExist("tblphases", "phase_type", $phase_type, "organization_id", $organization_id)) {
                    if ($this->InsertRecord("tblphases", $insert, $vals)) {
                        $this->SuccessMsg="phase has been added successfully.";
                        return 1;
                    }
                    return 0;
                }
                $this->ErrorMsg="Phase already exist, duplicate values not allowed.";
                return 0;
            }
        
            return 0;
        }
    }
	
	public function updateSelectedPhase()
	{
		if(empty($_GET['phase_id']) || !is_numeric($_GET['phase_id']) || 
		$_GET['phase_id'] <= 0)
		{
			$this->LastMsg="Invalid phase selection";
			return false;
		}

		if(isset($_POST) && isset($_POST['update'] ) && $_POST['update'] == "UPDATE")
		{	
			if($this->prePreprocessor())
			{
				$phase_type=test_input($_POST['phase_type']);
				$_POST['phase_type']='';
				unset($_POST['phase_type']);

				$organization_id=test_input($_POST['organization_id']);
                $_POST['organization_id']='';
                unset($_POST['organization_id']);

				$_POST['update'] = '';
				unset($_POST['update']);
				$query="UPDATE tblphases SET 
						phase_type = '".$phase_type."', organization_id = '".$organization_id."'
						WHERE phase_id = '".$_GET['phase_id']."'";
				if($this->CustomModify($query))
				{
					$this->SuccessMsg="Record has been updated successfully.";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again later.";
				return 0;
			}
			return 0;
		}
		return 0;
	}
}//end class.
?>