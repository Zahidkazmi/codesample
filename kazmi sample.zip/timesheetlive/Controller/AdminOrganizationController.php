<?php
/*********************************************************
 * Name: AdminOrganizationController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com, zahid.kazmi@viltco.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 24th March, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class AdminOrganizationController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminOrganizationController()
	{
		$this->DBDisconnect();
	}

	function prePreprocessor() 
	{
		
		if(empty($_POST['organization_name']))
		{
			$this->ErrorMsg="Please enter Organization name.";
			return 0;
		}
		
		// if(empty($_POST['package_id']))
		// {
		// 	$this->ErrorMsg="please select package.";
		// 	return 0;
		// }
		// if(empty($_POST['organization_status']))
		// {
		// 	$this->ErrorMsg="Please select status.";
		// 	return 0;
		// }
		// if(empty($_POST['added_date']))
		// {
		// 	$this->ErrorMsg="Please select date.";
		// 	return 0;
		// }
		// if(!emailsyntax_is_valid($_POST['organization_name']))
		// {
		// 	$this->ErrorMsg="Please enter valid email address.";
		// 	return 0;
		// }
		
	
		return 1;
	}

    public function getOrganizationLists()
    {
        $query ="SELECT  org.organization_id,org.organization_name,org.organization_status,org.added_date,pkg.package_name,pkg.num_of_users 
		FROM tblorgnization AS org
		INNER JOIN tblpkg AS pkg ON pkg.package_id = org.package_id;";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getSelectedOrganization()
	{
		if(isset($_GET) && is_numeric($_GET['organization_id']))
		{
			$query ="SELECT organization_id,organization_name,package_id,organization_status,added_date FROM tblorgnization WHERE organization_id = '".$_GET['organization_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}

    public function AddOrganization()
    {
        if (isset($_POST)) {
            if ($this->prePreprocessor()) {
                $organization_name=test_input($_POST['organization_name']);
                $_POST['organization_name']='';
                unset($_POST['organization_name']);
                $package_id=test_input($_POST['package_id']);
                $_POST['package_id']='';
                unset($_POST['package_id']);

                $organization_status=test_input($_POST['organization_status']);
                $_POST['organization_status']='';
                unset($_POST['organization_status']);
                
                $insert = "organization_name,package_id,organization_status,added_by,added_date";
                $vals = "'".$organization_name."','".$package_id."','".$organization_status."','".$_SESSION['admin_ID']."',NOW()";
                if ($this->GetSingleField("tblorgnization", "organization_name", $organization_name, "organization_name") != $organization_name) {
                    if ($this->InsertRecord("tblorgnization", $insert, $vals)) {
                        $this->SuccessMsg="Organization has been added successfully.";
                        return 1;
                    }
                    return 0;
                }
                $this->ErrorMsg="organization already exist, duplicate values not allowed.";
                return 0;
            }
            return 0;
        }
    }
	public function getpakage()
    {
        $query ="SELECT package_id , package_name FROM tblpkg WHERE package_status='Active'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }
	

	public function updateSelectedOrganization()
	{
		if(empty($_GET['organization_id']) || !is_numeric($_GET['organization_id']) ||  
		$_GET['organization_id'] <= 0)
		{
			$this->LastMsg="Invalid organization selection";
			return false;
		}

		if(isset($_POST) && isset($_POST['update'] ) && $_POST['update'] == "UPDATE")
		{	
			if($this->prePreprocessor())
			{
				$organization_name=test_input($_POST['organization_name']);
				$_POST['organization_name']='';
				unset($_POST['organization_name']);
				$package_id=test_input($_POST['package_id']);
				$_POST['package_id']='';
				unset($_POST['package_id']);
				$organization_status=test_input($_POST['organization_status']);
				$_POST['organization_status']='';
				unset($_POST['organization_status']);
				$_POST['update'] = '';
				unset($_POST['update']);
				
				$query="UPDATE tblorgnization SET 
						organization_name = '".$organization_name."',
						package_id = '".$package_id."',
						organization_status = '".$organization_status."',
						updated_by = '".$_SESSION['admin_ID']."'
						WHERE organization_id = '".$_GET['organization_id']."'";
						
				if($this->CustomModify($query))
				{
					$this->SuccessMsg="Record has been updated successfully.";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again later.";
				return 0;
			}
			return 0;
		}
		return 0;
	}
	
}//end class.
?>