<?php
/*********************************************************
 * Name: SubAdminDashboardController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing sub admin end dashboard controls.
 * Version: 1.0
 * Last edited: 8th June, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class SubAdminDashboardController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_SubAdminDashboardController()
	{
		$this->DBDisconnect();
	}

    public function getCountOfProjects()
    {
        $query="SELECT COUNT(*) as cnt FROM tblproject WHERE organization_id = '".$_SESSION['organization_id']."'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data[0]['cnt'];
        }
        return 0;
    }
    public function getCountOfUsers()
    {
        $query="SELECT COUNT(*) as cnt FROM tblusers WHERE organization_id = '".$_SESSION['organization_id']."'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

    public function getCountOfTeams()
    {
        $query="SELECT COUNT(*) as cnt FROM tblteam WHERE organization_id = '".$_SESSION['organization_id']."'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

    public function getCountOfClients()
    {
        $query="SELECT COUNT(*) as cnt FROM tblclients WHERE organization_id = '".$_SESSION['organization_id']."'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

    public function getCountOfProgressTasksBYProject($task_status,$project_id)
    {
        $query="SELECT COUNT(*) as cnt FROM tbltask WHERE resource_id = '".$_SESSION['user_id']."' AND task_status = '$task_status' AND project_id = '$project_id'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['cnt'];
        }
        return '0';
    }

    public function getProject()
    {        
        $query="SELECT project_id,project_name,project_code 
        FROM tblproject
        WHERE organization_id = '".$_SESSION['organization_id']."' 
        ORDER BY project_name ASC";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data;
        }
        return '0';
         
    }
    public function getProjectTasksStats($project_id,$status)
    {
        
        $query="SELECT COUNT(*) as Stats 
        FROM tbltask
        WHERE project_id='$project_id' AND task_status = '$status'";
        if(($data=$this->CustomQuery($query))!=null)
        {
            return $data[0]['Stats'];
        }
        return '0';
         
    }
}//end class.
?>