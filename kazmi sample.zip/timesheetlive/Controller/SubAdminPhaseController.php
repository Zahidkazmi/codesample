<?php
/*********************************************************
 * Name: SubAdminPhaseController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing organization admin end session controls for Phase module.
 * Version: 1.2
 * Last edited: 1st June, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class SubAdminPhaseController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_SubAdminPhaseController()
	{
		$this->DBDisconnect();
	}
	function prePreprocessor()
	{
		
		if(empty($_POST['phase_type']))
		{
			$this->ErrorMsg="Please enter phase type name.";
			return 0;
		}
		return 1;
	}

	//
    public function getPhaseLists()
    {
        $query ="SELECT phase_id ,phase_type FROM tblphases WHERE organization_id = '".$_SESSION['organization_id']."' ORDER BY phase_id  ASC";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getSelectedPhase()
	{
		if(isset($_GET) && is_numeric($_GET['phase_id']))
		{
			$query="SELECT phase_id ,phase_type FROM tblphases WHERE phase_id  = '".$_GET['phase_id']."' AND organization_id = '".$_SESSION['organization_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}

    public function AddPhase()
    {
        if (isset($_POST) && $_POST['Create'] == "Create Phase") {
            if ($this->prePreprocessor()) {
                $phase_type=test_input($_POST['phase_type']);
                $_POST['phase_type']='';
                unset($_POST['phase_type']);
                $insert = "organization_id,phase_type";
                $vals = "'".$_SESSION['organization_id']."','".$phase_type."'";
                if ($this->GetSingleField("tblphases", "phase_type", $phase_type, "phase_type") != $phase_type) {
                    if ($this->InsertRecord("tblphases", $insert, $vals)) {
                        $this->SuccessMsg="phase has been added successfully.";
                        return 1;
                    }
                    return 0;
                }
                $this->ErrorMsg="Phase already exist, duplicate values not allowed.";
                return 0;
            }
        
            return 0;
        }
    }
	
	public function updateSelectedPhase()
	{
		if(empty($_GET['phase_id']) || !is_numeric($_GET['phase_id']) || 
		$_GET['phase_id'] <= 0)
		{
			$this->LastMsg="Invalid phase selection";
			return false;
		}

		if(isset($_POST) && isset($_POST['update'] ) && $_POST['update'] == "UPDATE")
		{	
			if($this->prePreprocessor())
			{
				$phase_type=test_input($_POST['phase_type']);
				$_POST['phase_type']='';
				unset($_POST['phase_type']);
				
				$_POST['update'] = '';
				unset($_POST['update']);
				$query="UPDATE tblphases SET 
						phase_type = '".$phase_type."'
						WHERE phase_id = '".$_GET['phase_id']."' AND organization_id = '".$_SESSION['organization_id']."'";
				if($this->CustomModify($query))
				{
					$this->SuccessMsg="Record has been updated successfully.";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again later.";
				return 0;
			}
			return 0;
		}
		return 0;
	}
}//end class.
?>