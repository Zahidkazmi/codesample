<?php
/*********************************************************
 * Name: AdminLoginController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 24th March, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class AdminClientController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminClientController()
	{
		$this->DBDisconnect();
	}
	public function getOrganization()
    {
        $query ="SELECT organization_id,organization_name FROM tblorgnization where organization_status ='Active'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="Organizations not defined.";
        return 0;
    }

	function prePreprocessor()
	{
		if(empty($_POST['organization_id']))
		{
			$this->ErrorMsg="Please select organization.";
			return 0;
		}
		
		if(empty($_POST['client_name']))
		{
			$this->ErrorMsg="Please enter client name.";
			return 0;
		}

		if(empty($_POST['client_email']))
		{
			$this->ErrorMsg="Please enter client Email.";
			return 0;
		}
		
		if(!emailsyntax_is_valid($_POST['client_email']))
		{
			$this->ErrorMsg="Please enter valid email address.";
			return 0;
		}
		
		if(empty($_POST['contact_person']))
		{
			$this->ErrorMsg="Please enter your client contact.";
			return 0;
		}
		return 1;
	}

    public function getClientLists()
    {
        $query ="SELECT c.client_id,c.client_name,c.client_email,c.contact_person,c.client_address,c.client_status,o.organization_name FROM tblclients as c 
				 INNER JOIN tblorgnization as o ON o.organization_id = c.organization_id
				 ORDER BY c.client_id DESC";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getSelectedClient()
	{
		if(isset($_GET) && is_numeric($_GET['client_id']))
		{
			$query="SELECT organization_id,client_id,client_name,client_email,contact_person,client_address,client_status
					FROM tblclients WHERE client_id = '".$_GET['client_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}

    public function AddClient()
    {
        if(isset($_POST) && $_POST['AddClient'] =="Add Client")
        {
		
			if($this->prePreprocessor()){
				$organization_id=test_input($_POST['organization_id']);
				$_POST['organization_id']='';
				unset($_POST['organization_id']);

				$client_name=test_input($_POST['client_name']);
				$_POST['client_name']='';
				unset($_POST['client_name']);
				
				$client_email=test_input($_POST['client_email']);
				$_POST['client_email']='';
				unset($_POST['client_email']);

				$contact_person=test_input($_POST['contact_person']);
				$_POST['contact_person']='';
				unset($_POST['contact_person']);

				$client_address=$_POST['client_address'];
				$_POST['client_address']='';
				unset($_POST['client_address']);
				
				$insert = "organization_id,client_name,client_email,contact_person,client_address,client_status,created_at,added_by";
				$vals = "'".$organization_id."','".$client_name."','".$client_email."','".$contact_person."','".mysqli_real_escape_string($this->DBlink,$client_address)."','Active',NOW(),'".$_SESSION['admin_ID']."'";
				if($this->InsertRecord("tblclients",$insert,$vals))
				{
					$this->SuccessMsg="Client has been added successfully.";
					return 1;
				}
				return 0;
			}
        }
        return 0;
    }

	public function updateSelectedClient()
	{
		if(empty($_GET['client_id']) || !is_numeric($_GET['client_id']) ||  
		$_GET['client_id'] <= 0)
		{
			$this->LastMsg="Invalid client selection";
			return false;
		}

		if(isset($_POST) && isset($_POST['update'] ) && $_POST['update'] == "UPDATE")
		{	
			if($this->prePreprocessor())
			{
				$organization_id=test_input($_POST['organization_id']);
				$_POST['organization_id']='';
				unset($_POST['organization_id']);

				$client_name=test_input($_POST['client_name']);
				$_POST['client_name']='';
				unset($_POST['client_name']);

				$client_email=test_input($_POST['client_email']);
				$_POST['client_email']='';
				unset($_POST['client_email']);

				$contact_person=test_input($_POST['contact_person']);
				$_POST['contact_person']='';
				unset($_POST['contact_person']);

				$client_address=test_input($_POST['client_address']);
				$_POST['client_address']='';
				unset($_POST['client_address']);
				
				$_POST['update'] = '';
				unset($_POST['update']);
				$client_status=test_input($_POST['client_status']);
				$_POST['client_status'] = '';
				unset($_POST['client_status']);
				$query="UPDATE tblclients SET 
						organization_id = '".$organization_id."',
						client_name = '".$client_name."',
						client_email = '".$client_email."',
						contact_person = '".$contact_person."',
						client_status = '".$client_status."',
						client_address = '".mysqli_real_escape_string($this->DBlink,$client_address)."',
						updated_by = '".$_SESSION['admin_ID']."'
						WHERE client_id = '".$_GET['client_id']."'";
				if($this->CustomModify($query))
				{
					$this->SuccessMsg="Record has been updated successfully.";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again later.";
				return 0;
			}
			return 0;
		}
		return 0;
	}
	
}//end class.
?>