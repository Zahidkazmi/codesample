<?php
/*********************************************************
 * Name: AdminTeamController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com, zahid.kazmi@viltco.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 24th March, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class AdminTeamController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminTeamController()
	{
		$this->DBDisconnect();
	}

	function prePreprocessor() 
	{
		
		if(empty($_POST['team_name']))
		{
			$this->ErrorMsg="Please enter team name.";
			return 0;
		}
		
		// if(empty($_POST['package_id']))
		// {
		// 	$this->ErrorMsg="please select package.";
		// 	return 0;
		// }
		// if(empty($_POST['organization_status']))
		// {
		// 	$this->ErrorMsg="Please select status.";
		// 	return 0;
		// }
		// if(empty($_POST['added_date']))
		// {
		// 	$this->ErrorMsg="Please select date.";
		// 	return 0;
		// }
		// if(!emailsyntax_is_valid($_POST['organization_name']))
		// {
		// 	$this->ErrorMsg="Please enter valid email address.";
		// 	return 0;
		// }
		
	
		return 1;
	}

	public function getTeamLists()
    {
        $query ="SELECT * FROM tblteam";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }
	
    public function getSelectedTeamDetail()
    {
        $query ="SELECT * FROM tblteam WHERE team_id = '".$_GET['team_id']."'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }
	
	public function getSelectedTeam()
	{
		if(isset($_GET) && is_numeric($_GET['team_id']))
		{
			$query ="SELECT  tm.tmember_id,t.team_name,u.first_name,u.last_name,u.username,tm.member_roll
			FROM tblteam_members AS tm
			INNER JOIN tblteam AS t ON t.team_id = tm.team_id  
			INNER JOIN tblusers AS u ON u.user_id = tm.resource_id WHERE tm.team_id = '".$_GET['team_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}

	public function GetTeamMember($Roll){
		$query="SELECT u.user_id, u.first_name,u.last_name 
		FROM tblusers AS u
		INNER JOIN tblteam_members as tm ON tm.resource_id = u.user_id
		WHERE tm.member_roll = '$Roll' AND tm.team_id = '".$_GET['team_id']."'";
		if(($data=$this->CustomQuery($query))!=NULL)
		{
			return $data;
		}
		return 0;
	}

	public function IsTeamMember($resource_id){
		if($this->OverloadsGetSingleField("tblteam_members", "resource_id", $resource_id, "team_id", $_GET['team_id'],"member_roll") == 'Member')
		{
			return 1;
		}
		return 0;
	}

	public function getOrganization()
    {
        $query ="SELECT organization_id,organization_name FROM tblorgnization where organization_status ='Active'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="Organizations not defined.";
        return 0;
    }

   
	public function AddTeam()
    {
        if (isset($_POST)) {
            if ($this->prePreprocessor()) {
				$organization_id=test_input($_POST['organization_id']);
				$_POST['organization_id']='';
				unset($_POST['organization_id']);
                $team_name=test_input($_POST['team_name']);
                $_POST['team_name']='';
                unset($_POST['team_name']);
                $team_status=test_input($_POST['team_status']);
                $_POST['team_status']='';
                unset($_POST['team_status']);
				$lead_id=test_input($_POST['lead_id']);
                $_POST['lead_id']='';
                unset($_POST['lead_id']);
                $insert = "organization_id,team_name,team_status,created_at,created_by";
                $vals = "'".$organization_id."','".$team_name."','1',NOW(),'".$_SESSION['admin_ID']."'";
                if ($this->GetSingleField("tblteam", "team_name", $team_name, "team_name") != $team_name) {
                    if ($team_id = $this->InsertRecord("tblteam", $insert, $vals)) {
						$insert = "team_id,resource_id,member_roll,added_by,added_date";
						$vals = "'".$team_id."','".$lead_id."','Lead','".$_SESSION['admin_ID']."',NOW()";
						$this->InsertRecord("tblteam_members", $insert, $vals);
						if(isset($_POST['member_id']) && $_POST['member_id'] !='' && $_POST['member_id'] !='0'){
							foreach($_POST['member_id'] as $member_id)
							{
								$insert = "team_id,resource_id,member_roll,added_by,added_date";
								$vals = "'".$team_id."','".$member_id."','Member','".$_SESSION['admin_ID']."',NOW()";
								$this->InsertRecord("tblteam_members", $insert, $vals);
							}
						}
                        $this->SuccessMsg="Team has been added successfully.";
                        return 1;
                    }
                    return 0;
                }
                $this->ErrorMsg="Team name already exist, duplicate values not allowed.";
                return 0;
            }
            return 0;
        }
    }

	public function getuser()
    {
        $query ="SELECT user_id,first_name,last_name FROM tblusers WHERE status='Active'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getselecteduser($organization_id)
    {
        $query ="SELECT user_id,first_name,last_name FROM tblusers WHERE status='Active' AND organization_id = '$organization_id'";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function updateSelectedTeam()
	{
		if(empty($_GET['team_id']) || !is_numeric($_GET['team_id']) ||  
		$_GET['team_id'] <= 0)
		{
			$this->LastMsg="Invalid team selection";
			return false;
		}

		if(isset($_POST) && isset($_POST['update'] ) && $_POST['update'] == "UPDATE")
		{	
			if($this->prePreprocessor())
			{
				$team_name=test_input($_POST['team_name']);
				$_POST['team_name']='';
				unset($_POST['team_name']);
				$organization_id=test_input($_POST['organization_id']);
				$_POST['organization_id']='';
				unset($_POST['organization_id']);
				$user=test_input($_POST['resource_id']);
				$_POST['resource_id']='';
				unset($_POST['resource_id']);
				$user_id=test_input($_POST['user_id']);
				$_POST['user_id']='';
				unset($_POST['user_id']);
				$lead_id=test_input($_POST['lead_id']);
				$_POST['lead_id']='';
				unset($_POST['lead_id']);
				$member_roll=test_input($_POST['member_roll']);
				$_POST['member_roll']='';
				unset($_POST['member_roll']);
				$team_status=test_input($_POST['team_status']);
				$_POST['team_status']='';
				unset($_POST['team_status']);
				$_POST['update'] = '';
				unset($_POST['update']);

				$query="UPDATE tblteam SET 
						team_name = '".$team_name."',
						organization_id = '".$organization_id."',
						updated_at = NOW(),
						team_status = '".$team_status."',
						updated_by = '".$_SESSION['admin_ID']."'
						WHERE team_id = '".$_GET['team_id']."'";
						
				if($this->CustomModify($query))
				{

					           	$this->DeleteSetOfRecords("tblteam_members", "team_id", $_GET['team_id'] );
								$insert = "team_id,resource_id,member_roll,added_by,added_date";
								$vals = "'".$_GET['team_id']."','".$lead_id."','Lead','".$_SESSION['admin_ID']."',NOW()";
								$this->InsertRecord("tblteam_members", $insert, $vals);
								
								if(isset($_POST['member_id']) && $_POST['member_id'] !='' && $_POST['member_id'] !='0'){
									foreach($_POST['member_id'] as $member_id)
									{
										$insert = "team_id,resource_id,member_roll,added_by,added_date";
										$vals = "'".$_GET['team_id']."','".$member_id."','Member','".$_SESSION['admin_ID']."',NOW()";
										$this->InsertRecord("tblteam_members", $insert, $vals);
									}
								}

					$this->SuccessMsg="Record has been updated successfully.";
					return 1;
				}
				$this->ErrorMsg="Unable to update the record, Please try again later.";
				return 0;
			}
			return 0;
		}
		return 0;
	}
	
}//end class.
?>