<?php
/*********************************************************
 * Name: AdminLoginController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com
 * Skype: programerparadise
 * URL: https://www.110estuio.com
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 24th March, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class AdminLoginController extends DBAccess
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminLoginController()
	{
		$this->DBDisconnect();
	}

	function LoginPreprocessor()
	{
		if(empty($_POST['Email']))
		{
			$this->ErrorMsg="Please enter your Email.";
			return 0;
		}
		
		if(empty($_POST['pass']))
		{
			$this->ErrorMsg="Please enter your login password.";
			return 0;
		}

		if($_POST['Email'] == '1' && $_POST['pass'] == '1')
		{
			$this->ErrorMsg="Invalid Email and password.";
			return 0;
		}

		if($_POST['Email'] == '1=1' && $_POST['pass'] == '1=1')
		{
			$this->ErrorMsg="Invalid email and password.";
			return 0;
		}
		return 1;
	}
	//login the admin
	function verfiy_login_info()
	{ 
		if(isset($_POST) && isset($_POST['Login']) == "Log In")
		{
			if($this->LoginPreprocessor())
			{		
				$Email = $_POST['Email'];
				$Pass = md5($_POST['pass']);
					
				if($this->CheckUser("tbladmin", "Email", $Email, "Password", $Pass) || $this->CheckUser("tbladmin", "username", $Email, "Password", $Pass) )
				{
					//all verified
					if( ($this->GetSingleField("tbladmin","Email",$Email,"Status") == 'Active') || ($this->GetSingleField("tbladmin","username",$Email,"Status") == 'Active') )
					{
						$query="SELECT admin_ID,Email,username,Gender,image,Name,User_Type
								FROM `tbladmin` 
								WHERE '".$Email."' IN (username,Email)
								AND Status = 'Active'";
								
								if(($data=$this->CustomQuery($query))!=null)
								{

									$_SESSION['admin_ID']=$data[0]['admin_ID'];
									$_SESSION['Email']=$data[0]['Email'];
									$_SESSION['username']=$data[0]['username'];
									$_SESSION['user_image']=$data[0]['image'];
									$_SESSION['name']=$data[0]['Name'];
									$_SESSION['Gender']=$data[0]['Gender'];
									$_SESSION['User_Type']=$data[0]['User_Type'];
									
									return true;
								}
								else
								{
									unset($_SESSION['admin_ID']);
									unset($_SESSION['Email']);
									unset($_SESSION['username']);
									unset($_SESSION['user_image']);
									unset($_SESSION['name']);
									unset($_SESSION['User_Type']);
									unset($_SESSION['Gender']);										
									session_destroy();
									$this->ErrorMsg="Blocked From Interface";
									return 0;
								}	
					
							
					}
					$this->ErrorMsg="Wrong email or username and password.";
					return false;
				}
				else if($this->GetSingleField("tbladmin","Email",$Email,"Email") == NULL)
				{
					$this->ErrorMsg="Invalid email.";
					return false;
				}
				else if($this->GetSingleField("tbladmin","Email",$Email,"Password") != $Pass)
				{
					$this->ErrorMsg="Wrong Password.";
					return false;
				}
				else
				{
					$this->ErrorMsg="Invalid login information";
					return false;
				}	
					
			}
			
			return false;
		}
		return false;
	}

	//validate users is logged in 
	function is_logged_in()
	{
		if((isset($_SESSION['admin_ID'])) && (!empty($_SESSION['admin_ID'])))
		{
			if(($this->GetRecord("tbladmin", "admin_ID", $_SESSION['admin_ID']))==null)
			{
				$this->ErrorMsg="User not in database.";
				return false;
			}
			return true;
		}
		
		return false;
	}

	function RegisterPreprocessor()
	{
		
		if(empty($_POST['Email']))
		{
			$this->ErrorMsg="Please enter your email.";
			return 0;
		}


		if(empty($_POST['username']))
		{
			$this->ErrorMsg="Please enter your username.";
			return 0;
		}
		
		if(empty($_POST['pass1']))
		{
			$this->ErrorMsg="Please enter your password.";
			return 0;
		}

		if(empty($_POST['pass2']))
		{
			$this->ErrorMsg="Please enter your confirmation password.";
			return 0;
		}

		if($_POST['Email'] == '1' && $_POST['pass1'] == '1' && $_POST['pass2'] == '1' && $_POST['username'] == '1')
		{
			$this->ErrorMsg="Invalid credentials.";
			return 0;
		}

		if($_POST['Email'] == '1=1' && $_POST['pass1'] == '1=1' && $_POST['pass2'] == '1=1' && $_POST['username'] == '1=1')
		{
			$this->ErrorMsg="Invalid credentials.";
			return 0;
		}

		if(!emailsyntax_is_valid($_POST['Email'])) 
		{
			$this->ErrorMsg="Please enter a valid email address.";
			return 0;
		}

		return 1;


	}


	function GetSecurityQuestion()
	{
		if(isset($_POST) && isset($_POST['Question']) == 'Question' && isset($_POST['Email']) )
		{
			if(!emailsyntax_is_valid($_POST['Email'])) 
			{
				$this->ErrorMsg="Please enter a valid email address.";
				return 0;
			}
			$Email=test_input($_POST['Email']);
			if(($this->GetSingleField("tbladmin","Email",$Email,"Status") == 'Active') && ($this->GetSingleField("tbladmin","Email",$Email,"Email"))){
				$query="SELECT Question FROM securityquestion as a, tbladmin as b WHERE b.Email='".$Email."' AND b.Status = 'Active' AND a.Security_ID = b.Security_ID";
				if(($data=$this->CustomQuery($query))!=null)
				{
					return $data[0]['Question'];
				}
				$this->ErrorMsg="No security question found for given Email";
				return 0;
			}
			$this->ErrorMsg="Please enter registered email.";
			return 0;
		}
		return 0;
	}

	function SecurityLogin()
	{
		if(isset($_POST)&& isset($_POST['SecAnswer'])){
			if($_POST != NULL && isset($_POST['SecAnswer']) && $_POST['SecAnswer']!= '' && $_POST['SecAnswer'] == 'Answer' && $_POST['Email'] != NULL && emailsyntax_is_valid($_POST['Email']))
			{
				$Email = $_POST['Email'];
				$SecurityAnswer = test_input($_POST['SecurityAnswer']);
				$query="SELECT SecurityAnswer FROM tbladmin WHERE Email='".$Email."' AND SecurityAnswer = '".md5($SecurityAnswer)."' AND Status = 'Active'";
				
				if(($data=$this->CustomQuery($query))!=null)
				{ 
					
					$query="SELECT admin_ID,Email,username,image,Name,User_Type
					FROM `tbladmin` 
					WHERE '".$Email."' IN (username,Email)
					AND Status = 'Active'";
			
					//echo $query;

					if(($data=$this->CustomQuery($query))!=null)
					{
						$pass=md5('eteachingaid@123');	
						$this->CustomModify("UPDATE tbladmin SET Password ='".mysqli_real_escape_string($this->DBlink,$pass)."' WHERE admin_ID = '".$data[0]['admin_ID']."'");
						$_SESSION['admin_ID']=$data[0]['admin_ID'];
						$_SESSION['Email']=$data[0]['Email'];
						$_SESSION['username']=$data[0]['username'];
						$_SESSION['user_image']=$data[0]['image'];
						$_SESSION['name']=$data[0]['Name'];
						$_SESSION['User_Type']=$data[0]['User_Type'];
						$_SESSION['path'] = "profile";
						return "profile";
					}
					else
					{
							$this->ErrorMsg="Your account is blocked.";
							return 0;
					}	
				}
				$this->ErrorMsg='Security answer mismatched, please try again.';
				return 0;
			}
		}
		return 0;
		
	}

	function getPass()
	{
		return $this->GetSingleField("tbladmin","admin_ID",$_SESSION['admin_ID'],"Password");
	}

	function getSecurity()
	{
		return $this->GetSingleField("tbladmin","admin_ID",$_SESSION['admin_ID'],"Security_ID");
	}
		
	
}//end class.
?>