<?php
/*********************************************************
 * Name: AdminPackageController.php
 * Author: Zahid Kazmi
 * Contact: programerparadise@gmail.com, programerparadise@hotmail.com, zahid.kazmi@viltco.com
 * Skype: programerparadise
 * Description: Class for managing admin end session controls.
 * Version: 1.2
 * Last edited: 11th April, 2021
 *********************************************************/
/*!!!!!!!!!!!!!!!!! edit below this line at your own risk !!!!!!!!!!!!!!!!!!!!!!!*/ 
//access files
include_once($conf->absolute_path."Controller/encryption.php");
include_once($conf->absolute_path."Model/DBaccess.php");
include_once($conf->absolute_path."Controller/PaggingController.php");
include_once($conf->absolute_path."functions/general.php");
include_once($conf->absolute_path."Controller/ActivityController.php");

class AdminPackageController extends DBAccess 
{
	var $total_pages;
	
	//construcor
	public function __construct()
	{
		//connect to DB
		$this->connectToDB();
	}

	//destructor
	function destroy_AdminPackageController()
	{
		$this->DBDisconnect();
	}

	function prePreprocessor() 
	{
		
		if(empty($_POST['package_name']))
		{
			$this->ErrorMsg="Please enter Package name.";
			return 0;
		}
		return 1;
	}

    public function getPackageLists()
    {
        $query ="SELECT package_id,package_name,pkg_type,pkg_price,num_of_users,package_status FROM tblpkg ORDER BY package_id DESC";
        if(($data=$this->CustomQuery($query))!=NULL)
        {
            return $data;
        }
        $this->ErrorMsg ="No records found.";
        return 0;
    }

	public function getSelectedPackage()
	{
		if(isset($_GET) && is_numeric($_GET['package_id']))
		{
			$query ="SELECT package_id,package_name,pkg_type,pkg_price,num_of_users,package_status FROM tblpkg WHERE package_id = '".$_GET['package_id']."'";
			if(($data=$this->CustomQuery($query))!=NULL)
			{
				return $data;
			}
			return 0;
		}
		$this->ErrorMsg="Invalid record selection.";
		return 0;
	}
// this function not working in db just resolved it.
    public function AddPackage()
    {
        if(isset($_POST))
        {
		
			//if($this->prePreprocessor()){	
				$package_name=test_input($_POST['package_name']);
				$_POST['package_name']='';
				unset($_POST['package_name']); 
				$pkg_type=test_input($_POST['pkg_type']);
				$_POST['pkg_type']='';
				unset($_POST['pkg_type']); 
				$pkg_price=test_input($_POST['pkg_price']);
				$_POST['pkg_price']='';
				unset($_POST['pkg_price']); 
				$num_of_users=test_input($_POST['num_of_users']);
				$_POST['num_of_users']='';
				unset($_POST['num_of_users']);
				$insert = "package_name,pkg_type,pkg_price,num_of_users,package_status";
				$vals = "'".$package_name."','".$pkg_type."','".$pkg_price."','".$num_of_users."','Active'";
                if ($this->GetSingleField("tblpkg", "package_name", $package_name, "package_name") != $package_name) {
                    if ($this->InsertRecord("tblpkg", $insert, $vals)) {
                        $this->SuccessMsg="package has been added successfully.";
                        return 1;
                    }
                    return 0;
                }
				$this->ErrorMsg="Desgination already exist, duplicate values not allowed.";
				return 0;
			
			//}
        }
        return 0;
    }	
}
//end class.
?>
